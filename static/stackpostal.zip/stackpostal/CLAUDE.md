# CLAUDE.md

Este proyecto existe para que una persona **sin conocimientos técnicos** construya,
con tu ayuda, su propia extensión de Chrome: una **postal** que resume su newsletter
de Substack (suscriptores, crecimiento, mejor semana, próximo hito) y la descarga
como imagen para compartir en redes.

Tú escribes todo el código. El lector no va a leerlo ni a tocarlo: solo responde a
tus preguntas, sigue tus instrucciones en Chrome y te cuenta lo que ve.

Lee también, antes de escribir una sola línea:

- `docs/postal.md` — qué hace la extensión y cómo es la postal. Es la especificación
  cerrada: no añadas funciones que no estén ahí.
- `docs/substack-api.md` — las únicas rutas de Substack que puedes usar, con la forma
  real de sus respuestas.

## Cómo hablar con el lector

- Siempre en español, con frases cortas y sin jerga. Si una palabra técnica es
  inevitable ("extensión", "pestaña", "modo de desarrollador"), explícala la primera
  vez en media frase.
- Una instrucción por paso, numerada, diciendo **dónde hacer clic** y **qué debería
  ver** después. Nunca "configura el manifest" ni "abre la consola" sin decir cómo.
- No le pidas que edite archivos, que abra una terminal ni que instale nada.
  Node, npm, git y librerías **no hacen falta** y no los menciones salvo que él
  pregunte.
- Cuando algo falle, la culpa es del código, no del lector. Pide lo que necesites
  para diagnosticar (una captura de pantalla, el texto de un error) explicando
  exactamente dónde encontrarlo.
- No le enseñes código en la conversación salvo que lo pida. Resume lo que has hecho
  en una o dos frases.
- Pregunta solo lo imprescindible (ver Fase 0). Todo lo demás ya está decidido en
  `docs/postal.md`.

## El proceso, por fases

### Fase 0 — Bienvenida y comprobaciones (antes de escribir código)

Preséntate en dos frases y explica el plan: "voy a construir la extensión, te diré
cómo instalarla en Chrome y la probaremos juntos". Luego hazle las preguntas
**con la herramienta de preguntas (`AskUserQuestion`)**, todas en una sola
llamada, para que le aparezca un formulario de opciones en el que solo tiene que
elegir. **No las escribas como texto en el chat**: un lector no técnico responde
mejor eligiendo que redactando. El formulario ya añade solo la opción "Otro" para
escribir una respuesta libre; no la incluyas tú.

Las tres preguntas, con sus opciones (cabecera corta entre corchetes):

1. [Navegador] "¿Qué navegador usas?"
   - **Google Chrome**
   - **Edge, Brave u otro basado en Chrome** — "Funciona igual."
   - **Safari o Firefox** — "Esta extensión no funciona en ellos."
2. [Sesión] "¿Tienes iniciada la sesión en Substack en ese navegador?"
   - **Sí**
   - **No / no lo sé** — "Te diré cómo comprobarlo antes de probar."
3. [Nombre] "¿Cómo quieres llamar a tu extensión?"
   - **Mi postal de Substack (Recomendado)**
   - **Postal de [nombre de su newsletter]** — solo si ya lo conoces; si no,
     "Postal de mi newsletter".
   - (Para otro nombre, el lector usa "Otro" y lo escribe.)

No preguntes por el color: la postal arranca en **tinta** y el lector lo cambia
en el propio configurador.

Según las respuestas:

- Safari o Firefox: explícale con amabilidad que esta extensión solo funciona en
  navegadores basados en Chrome y detente.
- Sin sesión o no lo sabe: dile que abra substack.com en ese navegador y compruebe
  que arriba a la derecha aparece su foto; si no, que pulse **Sign in**. Puedes
  seguir construyendo mientras tanto.
- Si más adelante necesitas preguntarle algo con opciones claras (por ejemplo,
  elegir entre dos arreglos), usa también el formulario.

### Fase 1 — Construir

Construye la extensión completa de una vez en la carpeta `extension/`, siguiendo
`docs/postal.md` y la arquitectura de abajo. Mientras trabajas, avisa al lector con
una frase cada vez que termines una parte ("ya está la conexión con Substack; ahora
el diseño de la postal").

### Fase 2 — Revisar tú mismo

Antes de pedirle nada al lector:

- Comprueba que `extension/manifest.json` es JSON válido (léelo y revísalo; si
  `node` existe en el sistema puedes usar `node -e "JSON.parse(require('fs').readFileSync('extension/manifest.json','utf8'))"`).
- Si `node` existe, ejecuta `node --check` sobre cada `.js`. Si no existe, **no lo
  instales**: relee el código buscando errores de sintaxis y referencias a ids que
  no estén en el HTML.
- Verifica que cada `id` que usa el JavaScript existe en `postal.html`, y que cada
  archivo citado en el manifiesto existe.
- Repasa la lista "Errores que ya sabemos que pasan" de este documento.

### Fase 3 — Instalar (guía paso a paso)

Dale estos pasos, adaptando la ruta a la real de su ordenador (dísela completa,
por ejemplo `C:\Users\ana\stackpostal\extension`):

1. Abre Chrome y escribe en la barra de direcciones `chrome://extensions` y pulsa
   Intro.
2. Arriba a la derecha, activa el interruptor **Modo de desarrollador**.
3. Aparecen tres botones nuevos. Pulsa **Cargar descomprimida**.
4. En la ventana que se abre, busca y selecciona la carpeta **`extension`** que está
   dentro de esta carpeta del proyecto (no la carpeta del proyecto entera) y pulsa
   **Seleccionar carpeta**.
5. Debería aparecer una tarjeta con el nombre de tu extensión. Si sale un recuadro
   rojo de error, cópiame su texto.
6. Pulsa el icono de la pieza de puzle, arriba a la derecha de Chrome, y la
   chincheta junto a tu extensión, para tenerla siempre a mano.
7. Pulsa el icono de tu extensión: se abrirá una pestaña con tu postal.

### Fase 4 — Probar juntos

Pídele que te cuente qué ve: ¿aparecen el nombre de su newsletter, el número de
suscriptores, el logo? Que pruebe a cambiar el periodo, el formato y el color, y a
pulsar **Descargar imagen**. Que abra la imagen descargada y te diga si se ve bien.

Si algo falla, pídele el error así:

- **Errores de la extensión:** en `chrome://extensions`, en la tarjeta de su
  extensión, puede aparecer un botón **Errores**. Que lo pulse y te copie el texto.
- **Errores de la página de la postal:** en la pestaña de la postal, que pulse
  `F12` (o clic derecho → **Inspeccionar**), vaya a la pestaña **Console** y te
  copie las líneas en rojo. O que te pase una captura de pantalla.

### Fase 5 — Corregir y repetir

Cada vez que cambies el código, recuérdale exactamente esto:

> Ve a `chrome://extensions`, pulsa la flecha circular ↻ de la tarjeta de tu
> extensión y vuelve a abrir la postal desde su icono.

Sin ese paso Chrome sigue usando la versión anterior y parecerá que tu arreglo no
funcionó.

Cuando todo funcione, felicítale y dile qué puede pedirte a continuación (cambiar
textos, colores, el nombre). Si pide algo que contradice `docs/postal.md` (por
ejemplo mostrar ingresos), explícale por qué la especificación lo deja fuera y
deja que decida.

## Arquitectura (cerrada)

Extensión de Chrome **Manifest V3**, sin servidor, sin librerías, sin paso de
compilación. Archivos en `extension/`:

```
extension/
  manifest.json      MV3; nombre elegido por el lector; permisos mínimos
  background.js      service worker: abre la postal y hace TODAS las peticiones
  postal.html        la página de la postal y su configurador
  postal.css         estilos de la página (no de la postal: esa se dibuja en canvas)
  postal.js          pide los datos al service worker, calcula y dibuja
```

- **`manifest.json`**: `manifest_version: 3`, `name` y `description` en español,
  `version: "1.0.0"`, `background.service_worker: "background.js"` con
  `"type": "module"`, un `action` con `default_title` y **sin** `default_popup`.
  Permisos: **ninguno** en `permissions`. `host_permissions`:
  `["https://substack.com/*", "https://*.substack.com/*"]`. Nada más. Sin iconos
  (Chrome muestra la inicial); si el lector quiere un icono, hazlo al final.
- **`background.js`**: al pulsar el icono (`chrome.action.onClicked`) abre
  `postal.html` en una pestaña nueva con `chrome.tabs.create`. Escucha
  `chrome.runtime.onMessage` con `{ tipo: "cargar", subdominio, dias }` y responde
  con los datos ya normalizados (ver `docs/postal.md`, "Datos"). Toda petición usa
  `fetch(url, { credentials: "include", cache: "no-store", signal: AbortSignal.timeout(20000) })`:
  así Chrome adjunta la cookie de sesión del propio lector. La publicación no se
  le pregunta al lector: sale del perfil (solo las que administra). **Nunca leas, copies ni
  guardes cookies.** Para responder de forma asíncrona, el listener devuelve `true`.
- **`postal.js`**: al abrir, pide los datos, dibuja la postal en un `<canvas>` y
  engancha los controles **una sola vez**. Cambiar periodo vuelve a pedir datos;
  cambiar formato, color o lo que se muestra solo redibuja.
- **La postal se dibuja en un `<canvas>` de 1080 px de ancho** (1080×1350 vertical,
  1080×1080 cuadrado) con la API Canvas 2D. El mismo canvas es la vista previa
  (escalado por CSS a un ancho cómodo) y la imagen descargada (`canvas.toBlob` →
  enlace `<a download>`). Así lo que se ve es exactamente lo que se descarga, sin
  librerías de captura.

## Reglas que no se rompen

- **Solo las rutas de `docs/substack-api.md`.** No inventes endpoints ni
  parámetros. Si algo no se puede calcular con ellas, la cifra se omite.
- **Solo lectura.** La extensión hace únicamente peticiones `GET`. Nunca publica,
  edita ni borra nada en Substack.
- **Nada de datos personales de suscriptores.** Ninguna de las rutas permitidas los
  devuelve; no añadas ninguna que lo haga.
- **Nada de dinero.** Ni suscriptores de pago, ni ingresos, ni ARR, aunque la API
  los devuelva. La postal es para compartir en público.
- **No se guardan datos de la newsletter.** Se piden cada vez que se abre la postal
  o se pulsa **Actualizar**. Solo la configuración visual se guarda, en
  `localStorage` (ver `docs/postal.md`).
- **Fallo parcial no es cero.** Cada petición va por separado
  (`Promise.allSettled`). Si una falla, la cifra que depende de ella se omite de la
  postal; no se pinta "0" ni "—".
- **Fechas civiles con cuidado.** Una fecha `"2026-06-10"` se convierte con
  `new Date(año, mes - 1, día)`, nunca con `new Date("2026-06-10")`, que es
  medianoche UTC y en América cae en el día anterior.
- **Ningún cociente con denominador cero.** Un porcentaje sin base es `null` y no se
  muestra; nunca `Infinity`, `NaN` ni "+100 %".
- Todo el texto visible, en español. Números con `toLocaleString("es-ES")`.

## Errores que ya sabemos que pasan

- `summary.subscribers` **no** es el total de suscriptores (vale 0 en cuentas con
  cientos). El total está en `summary-v2` → `totalSubscribersEnd`, y como respaldo
  en `summary` → `totalEmail`.
- En el crecimiento diario, las bajas (`num_unsubs`, `num_expirations`) a veces
  llegan **en negativo**. Usa siempre el valor absoluto.
- Las imágenes de Substack (logo y foto) deben pasar por su CDN de imagen y cargarse
  con `img.crossOrigin = "anonymous"`; si no, el canvas queda "contaminado" y
  `toBlob` falla con un `SecurityError`. Ver `docs/substack-api.md`.
- Si una imagen no carga, dibuja la inicial en su lugar. Nunca un hueco ni un icono
  roto.
- Antes de dibujar texto en el canvas, espera a `document.fonts.ready`.
- Un `chrome.runtime.sendMessage` cuya respuesta nunca llega deja la página
  cargando para siempre: pon un plazo en la página también, de **45 s** (más que
  el perfil y el resto juntos, 20 s cada uno), y muestra un error comprensible si
  se agota.
- Un 401 o 403 **en el perfil** significa "no has iniciado sesión en Substack en
  este navegador": estado "sin sesión", con enlace a substack.com. En las rutas de
  la publicación, un fallo es parcial y la cifra se omite (el filtro de
  administrador ya evita el caso típico).
- Con la sesión caducada, Substack puede responder con una página HTML (o una
  redirección) en vez de un 401. Si la respuesta del perfil no es JSON, trátala
  también como "sin sesión", no como error de red.
- El ejemplo de `docs/postal.md` y la curva tienen que cuadrar: el crecimiento, la
  etiqueta izquierda del gráfico y "nuevos suscriptores" salen de la misma serie
  diaria. Si muestras un porcentaje de `summary-v2` junto a la curva, se
  contradicen.
