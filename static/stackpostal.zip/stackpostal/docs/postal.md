# La postal: especificación

Una imagen para compartir en redes que resume cómo va la newsletter del lector en
un periodo. Se ve en una pestaña de Chrome, se configura con unos pocos controles
y se descarga como PNG.

Principio que manda sobre todo lo demás: **es una postal pública**. Solo cifras
que el autor querría enseñar, ninguna cifra de dinero, y **cada cifra sin dato se
omite** en vez de mostrarse como "0" o "—".

---

## La página (`postal.html`)

Una sola página, centrada, con fondo neutro claro y tipografía del sistema
(`system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`).

```
┌──────────────────────────────────────────────────────────────┐
│  [Nombre de la extensión]           [Publicación ▾] [Actualizar] │
├───────────────────────────────┬──────────────────────────────┤
│                               │  Periodo                     │
│                               │  (7 días) (30 días) (90 días)│
│        VISTA PREVIA           │                              │
│        (el canvas, a          │  Formato                     │
│         ~480 px de ancho)     │  (Vertical) (Cuadrado)       │
│                               │                              │
│                               │  Color                       │
│                               │  (Tinta) (Claro) (Índigo)    │
│                               │                              │
│                               │  Mostrar                     │
│                               │  [x] Gráfico   [x] Cifras    │
│                               │  [x] Mejor semana [x] Hito   │
│                               │  [x] Autor                   │
│                               │                              │
│                               │  [ Descargar imagen ]        │
│                               │  [ Copiar imagen ]           │
│                               │  1080 × 1350 px · ideal para │
│                               │  Instagram, LinkedIn y X     │
└───────────────────────────────┴──────────────────────────────┘
```

- **Publicación:** el desplegable solo aparece si el autor tiene más de una. La
  elegida se recuerda en la configuración.
- **Actualizar:** vuelve a pedir los datos. Mientras carga, el botón queda
  desactivado y dice "Cargando…".
- En pantallas estrechas (menos de 800 px) el configurador pasa debajo de la vista
  previa.
- Los botones de opción son grupos de botones con `aria-pressed`; el activo se
  distingue por color de fondo.
- **Copiar imagen** usa `navigator.clipboard.write([new ClipboardItem({ "image/png": blob })])`.
  Si falla, muestra "No se pudo copiar; usa Descargar imagen".
- Debajo de los botones, una línea con el tamaño del formato elegido:
  - Vertical: "1080 × 1350 px · ideal para Instagram, LinkedIn y X"
  - Cuadrado: "1080 × 1080 px · cuadrado"

### Estados de la página

| Estado | Qué se ve en lugar de la vista previa |
|---|---|
| Cargando (primera vez) | "Leyendo tu Substack…" |
| Sin sesión (401/403 en el perfil) | "No encuentro tu sesión de Substack en este navegador. Entra en substack.com, inicia sesión y pulsa Actualizar." con enlace a `https://substack.com/sign-in` |
| Sin publicaciones de administrador | "No eres administrador de ninguna publicación de Substack. La postal necesita las estadísticas de una publicación tuya." |
| Error de red o plazo agotado (45 s en la página) | "Substack no respondió. Comprueba tu conexión y pulsa Actualizar." |

El plazo de la página (45 s) es mayor que la suma de los del service worker
(20 s el perfil + 20 s el resto en paralelo): si fuera menor, la página se
rendiría con la respuesta a punto de llegar.
| Listo | La postal |

Si el perfil carga pero falla alguna otra petición, la postal se muestra igual con
lo que haya (ver "Fallo parcial" en `CLAUDE.md`).

### Configuración guardada

En `localStorage`, clave `stackpostal.config`, como JSON:

```json
{ "dias": 30, "formato": "vertical", "color": "tinta",
  "mostrar": { "grafico": true, "cifras": true, "mejorSemana": true, "hito": true, "autor": true },
  "subdominio": "objetobrillante" }
```

- Los valores por defecto son los del ejemplo: 30 días, vertical, **tinta**, todo
  activado y la publicación principal.
- Lee y escribe dentro de `try/catch`: si `localStorage` falla, usa los valores por
  defecto y la página funciona igual.
- Valida al leer: un valor desconocido vuelve al de por defecto.

---

## Datos

`postal.js` pide al service worker `{ tipo: "cargar", subdominio, dias }` (el
subdominio puede faltar la primera vez). El service worker hace en paralelo las
peticiones de `docs/substack-api.md` y responde:

```js
{
  ok: true,
  publicaciones: [{ subdominio, nombre, logo }],   // solo las de administrador, para el desplegable
  publicacion: { subdominio, nombre, logo },       // la elegida
  autor: { nombre, foto },
  seguidores: 150 | null,
  suscriptores: 138 | null,          // total hoy
  suscriptoresInicio: 108 | null,    // total al empezar el periodo, SOLO como respaldo (ver Cálculos)
  publicados: { valor: 11, minimo: false } | null,
  diario: [{ fecha: "2026-08-19", altas: 3, bajas: 1 }, …] | null  // últimos 90 días
}
```

o `{ ok: false, motivo: "sesion" | "sin-publicaciones" | "red", mensaje }`.

- `diario` es **`null` si la petición falló** y **`[]` si respondió sin filas**
  (es decir, ningún día con altas ni bajas: un periodo real con cero altas). No
  los confundas: lo primero es "sin dato" y lo segundo es "cero medido".
- `publicaciones` solo incluye aquellas en las que el lector es administrador
  (ver `docs/substack-api.md`, sección 1). Si no queda ninguna:
  `motivo: "sin-publicaciones"`.

El perfil es la única petición imprescindible: si falla, `ok: false`. El resto,
con `Promise.allSettled`; lo que falle llega como `null`.

## Cálculos (en `postal.js`)

Todos sobre el periodo elegido: **hoy y los `dias − 1` días anteriores** (con 30
días, del 10 sep al 9 oct). El recorte es **por fecha**, no por número de filas.

**Una sola fuente para el cambio del periodo.** Nuevos suscriptores, crecimiento
y curva salen todos de `diario` anclado en `suscriptores`, para que las tres
cifras cuadren entre sí. `suscriptoresInicio` (de `summary-v2`) solo se usa si
`diario` es `null`.

1. **Serie diaria completa.** Si `diario` no es `null`, rellena los días del
   periodo que no tengan fila con `{ altas: 0, bajas: 0 }`.
2. **Nuevos suscriptores** = suma de `altas` del periodo. `null` si `diario` es
   `null`.
3. **Inicio del periodo** = `suscriptores − Σ(altas − bajas)` de todos los días del
   periodo **excepto el primero** (el primer punto de la curva es el total al
   cierre de ese primer día). Si `diario` es `null`, el inicio es
   `suscriptoresInicio`.
4. **Crecimiento** = `(suscriptores − inicio) / inicio`. `null` si falta alguno o
   el inicio es ≤ 0. Si el crecimiento es ≥ 1 (se ha duplicado o más), se muestra
   el **múltiplo** `suscriptores / inicio` con un decimal: "×2,2 en 90 días". Si
   no, como porcentaje entero con signo: "+12 % en 30 días" o "−3 % en 30 días".
5. **Curva de suscriptores.** Se reconstruye **hacia atrás** desde el total de hoy:
   el último punto es `suscriptores`, y cada día anterior vale el siguiente menos
   (altas − bajas) de ese día siguiente. Su primer punto es, por construcción, el
   inicio del paso 3. Necesita `suscriptores` y `diario` no `null`; si no, no hay
   gráfico. (La curva puede bajar si hubo más bajas que altas: es honesta.)
6. **Mejor semana**: agrupa las altas del periodo por semana (lunes a domingo,
   identificada por la fecha del lunes) y elige la de más altas; en empate, la más
   reciente. En las semanas que el periodo corta a medias solo cuentan los días
   dentro del periodo. Si la mejor tiene 0 altas, o el periodo es de 7 días, no
   hay mejor semana.
7. **Próximo hito**: el primer valor de
   `[50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000]` mayor que
   `suscriptores`; pasado 100.000, el siguiente múltiplo de 50.000. El progreso es
   `(suscriptores − hito anterior) / (hito − hito anterior)`. El hito anterior es
   el mayor valor de la lista que sea ≤ `suscriptores` (o 0); pasado 100.000, el
   múltiplo de 50.000 inmediatamente inferior (con 230.000, el anterior es 200.000
   y el siguiente 250.000). Sin `suscriptores`, no hay hito. No se proyecta ninguna
   fecha.

## La postal (dibujo en canvas)

Ancho siempre **1080 px**. Alto: **1350** en vertical, **1080** en cuadrado. Las
medidas de abajo son para el vertical; en cuadrado, reduce un 20 % las letras de
46 px o más y el gráfico un 40 %. Margen interior: **72 px** en los cuatro lados.
Esquinas rectas (la red social recorta a su gusto).

**Huecos:** 32 px entre secciones (24 en cuadrado), 32 px tras la cabecera y
32 px antes del pie.

**Mide siempre el texto** con `ctx.measureText` antes de colocarlo: la letra del
sistema cambia entre Windows y Mac, así que ningún ancho se puede dar por
supuesto.

**Si no cabe todo**, en este orden: (1) encoge el gráfico desde su alto
normal hasta un mínimo de 120 px; (2) si aún no cabe, omite el gráfico; (3) si
aún no cabe, omite la mejor semana. Es normal que en cuadrado con las tres cifras
el gráfico no aparezca.

**Fechas cortas** ("14 sep") con una tabla fija de meses
`ene feb mar abr may jun jul ago sep oct nov dic`, no con `toLocaleDateString`
(Chrome escribe "sept"). La fecha larga de la cabecera sí puede usar
`toLocaleDateString("es-ES", { day: "numeric", month: "long", year: "numeric" })`.

De arriba abajo:

1. **Cabecera.** Logo de la newsletter (cuadrado de 140 px, esquinas de 32 px;
   si no hay logo, la inicial del nombre en grande sobre un cuadrado de color de
   contraste). A su derecha, en dos líneas:
   - Periodo y fecha, 34 px, seminegrita, color secundario: "Últimos 30 días ·
     9 de octubre de 2026".
   - Nombre de la newsletter, 68 px, negrita. Si no cabe en el ancho, reduce el
     tamaño hasta 44 px; si aún no cabe, recorta con "…".
2. **Protagonista.** El total de suscriptores en enorme (190 px, extranegrita,
   formato compacto: `1.234` → "1234" hasta 9.999, después "12,3 mil"). Debajo,
   "suscriptores" (46 px, secundario). Debajo, el crecimiento en verde (46 px):
   "+12 % en 30 días" o "×2,2 en 90 días". Sin crecimiento, esa línea no existe.
3. **Gráfico** (si está activado y hay curva): área suave de la curva de
   suscriptores, 220 px de alto (puede encogerse, ver arriba), a todo el ancho
   útil, sin ejes. Debajo, en los extremos, el valor y la fecha del primer y del
   último punto ("108 · 10 sep" a la izquierda, "138 · 9 oct" a la derecha,
   28 px). El eje X es proporcional al tiempo. El valor de la izquierda es el
   inicio del periodo, el mismo que usa el crecimiento: las dos cifras cuadran.
4. **Cifras** (si están activadas): hasta tres casillas en una fila, con fondo
   ligeramente distinto y esquinas de 34 px. Cada una: número grande (86 px) y
   etiqueta debajo (32 px). Si la etiqueta no cabe en el ancho de la casilla,
   pártela en **dos líneas como máximo**; todas las casillas tienen la altura de
   la más alta. Solo las que tengan dato, en este orden:
   - "+35" · "nuevos suscriptores" (solo si es > 0)
   - "150" · "seguidores en Substack"
   - "11" · "publicaciones en total" (o "11+"; es una cifra histórica, no del
     periodo, y la etiqueta lo dice)
   Si queda una sola casilla, ocupa todo el ancho; si quedan dos, la mitad cada una.
5. **Mejor semana** (si está activada y existe): una línea de 38 px: "Mejor
   semana: 12 altas, la del 14 sep." (la fecha es el lunes de esa semana). Con
   una sola alta: "1 alta".
6. **Hito** (si está activado y existe): "Próximo hito: 250 suscriptores" (36 px)
   y una barra de progreso de 18 px de alto, esquinas redondas, con el avance
   (mínimo un 2 % visible para que se note que hay barra).
7. **Pie**, pegado al borde inferior: a la izquierda, foto del autor en círculo
   de 64 px (o su inicial, con los mismos colores que el cuadro del logo sin
   imagen) y "Por Ana Pérez" (32 px) si "Autor" está activado. Si el autor no
   tiene nombre, no hay foto ni texto a la izquierda. A la derecha, discreto
   (26 px, color terciario), el nombre de la extensión.

Las secciones 2 a 6, **como grupo**, se centran verticalmente en el espacio libre
entre cabecera y pie: si al desactivar secciones queda hueco, se reparte arriba y
abajo del grupo. Nada puede salirse del lienzo (ver "Si no cabe todo").

### Colores

| | Tinta | Claro | Índigo |
|---|---|---|---|
| Fondo | `#1c1c1e` | `#f2f2f7` | `#5856d6` |
| Texto principal | `#ffffff` | `#1c1c1e` | `#ffffff` |
| Texto secundario | `rgba(255,255,255,.65)` | `#6c6c70` | `rgba(255,255,255,.75)` |
| Texto terciario | `rgba(255,255,255,.4)` | `#8e8e93` | `rgba(255,255,255,.5)` |
| Crecimiento | `#8cf0a8` | `#248a3d` | `#ffffff` |
| Fondo de casillas | `rgba(255,255,255,.07)` | `#ffffff` | `rgba(255,255,255,.14)` |
| Número en casillas | `#a5a4ff` | `#5856d6` | `#ffffff` |
| Línea del gráfico | `#a5a4ff` | `#5856d6` | `#ffffff` |
| Relleno del gráfico | `rgba(165,164,255,.18)` | `rgba(88,86,214,.14)` | `rgba(255,255,255,.18)` |
| Pista de la barra | `rgba(255,255,255,.12)` | `#e5e5ea` | `rgba(255,255,255,.22)` |
| Barra de progreso | `#a5a4ff` | `#5856d6` | `#ffffff` |
| Cuadro del logo sin imagen | `#ffffff` con letra `#1c1c1e` | `#1c1c1e` con letra `#ffffff` | `#ffffff` con letra `#5856d6` |

## Descarga

- `canvas.toBlob(…, "image/png")` y un enlace temporal con
  `download = "postal-<subdominio>-<AAAA-MM-DD>.png"`.
- Antes de descargar o copiar, asegúrate de que el canvas está dibujado con los
  datos y la configuración actuales.

## Fuera de alcance (no lo añadas aunque parezca fácil)

- Suscriptores de pago, ingresos o cualquier cifra de dinero.
- Tasa de apertura, clics, notas, comentarios o cualquier otra métrica.
- Guardar históricos o datos de la newsletter.
- Publicar en redes desde la extensión.
- Idiomas distintos del español.
