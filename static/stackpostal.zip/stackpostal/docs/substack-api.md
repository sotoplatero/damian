# Rutas de Substack que usa la postal

Substack no publica una API oficial para estadísticas. Estas rutas son las que usa
el propio panel de Substack (`/publish`) y se han **observado** en la pestaña
Network de Chrome con una sesión real. Son las **únicas** que puede usar la
extensión. Si algo no sale de aquí, no se muestra.

Todas son `GET`, todas se llaman desde el service worker con
`credentials: "include"` (Chrome adjunta la cookie de sesión del lector) y todas
devuelven JSON. Como Substack puede renombrar campos sin aviso, lee cada dato con
alias (`perfil.photo_url ?? perfil.photoUrl`) y trata un campo ausente como
"sin dato", nunca como cero.

Abreviaturas:

- `RAIZ` = `https://substack.com/api/v1`
- `PUB` = `https://<subdominio>.substack.com/api/v1`, donde `<subdominio>` es el de
  la publicación elegida (por ejemplo `objetobrillante`).

---

## 1. Perfil del autor y sus publicaciones

```
GET RAIZ/user/profile/self
```

Forma observada (recortada a lo que se usa):

```json
{
  "id": 43892226,
  "name": "Ana Pérez",
  "handle": "anaperez",
  "photo_url": "https://substack-post-media.s3.amazonaws.com/public/images/…",
  "followerCount": 150,
  "publicationUsers": [
    {
      "role": "admin",
      "is_primary": true,
      "publication": {
        "id": 123456,
        "name": "Objeto Brillante",
        "subdomain": "objetobrillante",
        "logo_url": "https://substack-post-media.s3.amazonaws.com/public/images/…"
      }
    }
  ]
}
```

- **Sesión:** si responde 401 o 403, el lector no ha iniciado sesión en Substack en
  este navegador.
- **Publicaciones:** las de `publicationUsers[]` que tengan `publication.subdomain`
  **y en las que el lector sea administrador**: `role` igual a `"admin"` (el valor
  observado) u `"owner"`, sin distinguir mayúsculas. Las demás (colaborador,
  editor invitado…) se descartan: Substack no le enseña sus estadísticas y la
  postal saldría vacía. Si no queda ninguna, la extensión muestra el estado "sin
  publicaciones de administrador". Por defecto, la que tenga `is_primary: true`;
  si no, la primera.
- **Seguidores:** `followerCount` (alias `follower_count`). Son seguidores de la
  *cuenta* en Substack, no suscriptores del boletín. Es una cifra viva: se pide
  cada vez.
- **Autor:** `name` (si falta, `handle`) y `photo_url` (alias `photoUrl`,
  `profile_photo_url`).
- **Logo:** `publication.logo_url` (alias `logoUrl`).

## 2. Total de suscriptores y crecimiento del periodo

```
GET PUB/publish-dashboard/summary-v2?range=<7|30|90>
```

**No trae series**, solo escalares. Los que usa la postal:

```json
{ "totalSubscribersStart": 108, "totalSubscribersEnd": 138 }
```

- `totalSubscribersEnd` = total de suscriptores hoy (gratuitos + de pago, como un
  único número).
- `totalSubscribersStart` = total hace `range` días. **Solo es respaldo**: el
  crecimiento del periodo se calcula con las altas y bajas diarias (sección 3),
  para que cuadre con la curva y con "nuevos suscriptores". `Start` solo se usa
  si esa serie no llegó. No mezcles las dos fuentes en la misma postal.
- Solo se han observado `range=7`, `30` y `90`. No pidas otros valores.
- Ignora el resto de claves (`arr*`, `paid*`, `pledged*`): son dinero.

Respaldo, si `summary-v2` falla:

```
GET PUB/publish-dashboard/summary
```

```json
{ "totalEmail": 97, "subscribers": 0 }
```

El total está en **`totalEmail`**. **`subscribers` NO es el total** (vale 0 en una
cuenta con 97): no lo uses nunca.

## 3. Altas y bajas por día

```
GET PUB/publication/stats/paid_subscriber_growth?start=<ISO>&end=<ISO>&period=day&is_subscribed=false
```

- `start` y `end` son instantes ISO completos (`new Date().toISOString()`),
  codificados con `encodeURIComponent`. Pide siempre **los últimos 90 días**
  (cubre todos los periodos de la postal) y recorta en la página.
- `is_subscribed=false` = audiencia gratuita + total. **No uses `true`**: es la
  variante de pago.

Forma observada:

```json
{
  "subscriberGrowth": [
    { "dt": "2026/08/19", "total_new_subs": 3, "num_upgrades": 0,
      "num_unsubs": -1, "num_expirations": 0, "num_free_trials": 0 }
  ]
}
```

Normaliza cada fila a `{ fecha: "2026-08-19", altas, bajas }`:

- `fecha`: `dt` con `/` cambiado por `-` (alias `date`).
- `altas`: `total_new_subs`. Si no viene, suma las presentes de `new_free` y
  `new_paid`. Si tampoco, `new_subscribers` o `new`.
- `bajas`: **valor absoluto** de `num_unsubs` + `num_expirations` (llegan en
  negativo en algunas cuentas). Alias: `unsubscribes`.
- La lista puede venir directamente como array o dentro de `subscriberGrowth`,
  `rows` o `data`: acepta las cuatro.
- **Un día sin fila es un día con 0 altas y 0 bajas.** Esta serie es de eventos,
  así que aquí el hueco sí significa cero. Pero si la **petición** falla, la serie
  entera es `null` (sin dato), no una lista vacía.

## 4. Publicaciones publicadas

```
GET PUB/post_management/counts
```

```json
{ "published": 11, "publishedIsCapped": false, "drafts": 8, "scheduled": 0 }
```

Solo se usa `published`. Si `publishedIsCapped` es `true`, el número es un mínimo:
muéstralo como `11+`.

---

## Imágenes: logo y foto del autor

Las URL de imagen de Substack no siempre permiten usarse dentro de un `<canvas>`
(algunos almacenes antiguos no envían cabeceras CORS y el canvas queda bloqueado
para exportar). Su CDN de imagen sí las sirve con CORS abierto, ya recortadas:

```
https://substackcdn.com/image/fetch/w_256,h_256,c_fill,f_png/<URL original codificada con encodeURIComponent>
```

- Si la URL ya empieza por `https://substackcdn.com/image/fetch/`, úsala tal cual.
- Si no empieza por `https://`, no hay imagen.
- Carga con `const img = new Image(); img.crossOrigin = "anonymous"; img.src = …` y
  espera a `onload` / `onerror` (con un plazo de 8 s). Si falla, dibuja la inicial.
- No hace falta ningún permiso extra en el manifiesto para estas imágenes.

## Lo que NO existe o no se usa

- No hay ruta para suscriptores por día "acumulados": la curva se reconstruye con
  la sección 3 (ver `docs/postal.md`).
- `subscriber-stats` y las listas de suscriptores **traen datos personales**
  (emails, nombres). No se usan.
- Cualquier ruta de ingresos, pagos, planes o pledges: fuera.
- Dominios personalizados: la API se llama siempre por `<subdominio>.substack.com`.
