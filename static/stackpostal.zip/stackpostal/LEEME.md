# Tu postal de Substack

Esta carpeta contiene las instrucciones para que **Claude Code** construya contigo
una extensión de Chrome que crea una postal con las cifras de tu newsletter
(suscriptores, crecimiento, mejor semana, próximo hito) y la descarga como imagen
para compartir en redes.

No necesitas saber programar. Claude escribe todo el código; tú respondes a sus
preguntas y sigues sus indicaciones en Chrome.

## Qué necesitas

- **Google Chrome** (o Edge, Brave u otro navegador basado en Chrome).
- Tu **sesión de Substack iniciada** en ese navegador.
- **Claude Code** instalado y con tu cuenta de Claude conectada.

## Cómo empezar

1. Abre Claude Code **en esta carpeta**:
   - Con la aplicación de escritorio: abre esta carpeta como proyecto.
   - Con la terminal: entra en la carpeta y escribe `claude`.
2. Copia y pega esta frase y pulsa Intro:

```
Lee CLAUDE.md y construye mi extensión de la postal de Substack. No sé programar: guíame paso a paso.
```

3. Te aparecerá un pequeño formulario con tres preguntas (tu navegador, tu
   sesión de Substack y el nombre de tu extensión). Elige
   con las flechas e Intro; si ninguna opción te sirve, elige "Otro" y escribe.
4. Claude te pedirá permiso para crear archivos. Puedes aceptar cada vez o elegir
   la opción de permitir las ediciones durante esta sesión: solo trabaja dentro de
   esta carpeta.
5. Cuando termine, te explicará cómo instalar la extensión en Chrome y la probaréis
   juntos.

## Qué hace (y qué no)

- Lee tus estadísticas de Substack **usando tu propia sesión** del navegador. No
  pide tu contraseña ni la guarda.
- **Solo lee**: no publica, no edita ni borra nada en Substack.
- No guarda tus datos: los pide cada vez que abres la postal.
- No muestra ingresos ni suscriptores de pago: la postal está pensada para
  enseñarse en público.

## Contenido de la carpeta

- `CLAUDE.md` — instrucciones para Claude: cómo construir la extensión y cómo
  guiarte.
- `docs/postal.md` — cómo es la postal y qué cifras lleva.
- `docs/substack-api.md` — de dónde saca cada cifra en Substack.
- `extension/` — aparecerá cuando Claude construya tu extensión. Es la carpeta que
  cargarás en Chrome.
