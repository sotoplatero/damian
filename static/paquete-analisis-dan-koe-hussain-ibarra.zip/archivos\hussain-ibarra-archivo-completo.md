# Archivo completo de Passion & Profit

Autor: Hussain Ibarra
Publicación: Passion & Profit
Fuente: https://hussainibarra.substack.com
Periodo: 2025-06-22 — 2026-08-12
Entradas en el índice: 36
Publicaciones con cuerpo: 34

Este documento reúne las publicaciones disponibles en orden cronológico. Conserva los metadatos y el contenido recuperado del archivo público.

## Índice

- 2025-06-22 — My realistic plan to reaching $10,000/month
- 2025-06-29 — The Fastest Way To Grow An Audience (In 2025)
- 2025-07-13 — 7 Lessons I learned After Making $12,985 From My Small Writing Business
- 2025-07-16 — What Goes Behind Writing ONE Good Post
- 2025-07-20 — If You Want To Monetize Your Writing Don't Monetize Your Newsletter — Do This Instead
- 2025-07-27 — 6 Months is All It Takes To Completely Reinvent Your Life
- 2025-08-07 — The 5 Stages of Wealth Creation (And Why 99% Of People Are Stuck At Stage 2)
- 2025-08-11 — My Idea Generation System That Gained Me 72 Million Views
- 2025-08-20 — Being Average Is The Fastest Way To Being Miserable In Your Life
- 2025-08-24 — Being "Unemployable" Is The Fastest Way To Build Wealth
- 2025-09-21 — I Brainwashed Myself Into Starting A Business With Zero Experience (The Psycho-Cybernetic Method)
- 2025-09-28 — I Ran 1,121 Miles & It Changed My Life
- 2025-10-06 — How To Build An Audience (As A Person With Many Interests)
- 2025-10-27 — How to take back control of your life (in 6-12 months)
- 2025-11-04 — How to be so productive it feels illegal
- 2025-11-09 — If the average person did this for 90 days, they would be unrecognizable
- 2025-11-12 — I gained 49 leads in 7 days. Here's how I did it (without cold outreach or paid ads)
- 2025-11-17 — 1M Follower Network (How To Grow As A Beginner Without Relying On The Algorithm Or Going Viral)
- 2026-01-05 — 60 minutes is all it takes to do a hard reset on your life
- 2026-01-18 — The most profitable niche in 2026
- 2026-01-24 — Full Guide: How to start a profitable one-person business (in 2026)
- 2026-01-31 — I went from 800 to 26,000 followers in 13 months. Here's how (146 lessons learned):
- 2026-02-14 — You have a $100K product stuck in your mind (here's how you can extract it)
- 2026-03-16 — Most high-income skills will be irrelevant in 10 years (learn these 4 skills instead)
- 2026-03-31 — How to make the greatest comeback of your life in 2026
- 2026-04-04 — Hussain Ibarra: How To Create a Winning Personal Brand — sin cuerpo disponible
- 2026-04-12 — The world economy is f*cked right now (here's what you can do about it):
- 2026-04-20 — How to become disgustingly creative in 2026
- 2026-05-17 — How to stay relevant in the next 10 years (do these 4 things)
- 2026-05-31 — The fastest way to grow on social media (with zero followers & experience)
- 2026-06-22 — What you need to succeed as a creator and writer on Substack (in 2026) — sin cuerpo disponible
- 2026-06-24 — You have 24-36 months to make it (learn these 5 skills)
- 2026-06-30 — My story: Who the f*ck is Hussain Ibarra?
- 2026-07-16 — Happiness is a skill (here's how you can master it):
- 2026-08-05 — How to build a beautiful mind
- 2026-08-12 — How to do a hard reset on your life in 1 day

---

<!-- Archivo original: posts/2025-06-22-my-realistic-plan-to-reaching-10000month.md -->

---
titulo: "My realistic plan to reaching $10,000/month"
subtitulo: "How I'll reach $10,000/month while working 4 hours a day and still being in university."
fecha: 2025-06-22T20:35:06.785Z
url: https://hussainibarra.substack.com/p/my-realistic-plan-to-reaching-10000month
audiencia: gratis
palabras: 1204
likes: 24
comentarios: 10
---

# My realistic plan to reaching $10,000/month

_How I'll reach $10,000/month while working 4 hours a day and still being in university._

[![](https://substackcdn.com/image/fetch/$s_!_Qe0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb84d20f-ebcd-41b4-9fdf-1da8e1419d1f_3296x1440.png)](https://substackcdn.com/image/fetch/$s_!_Qe0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb84d20f-ebcd-41b4-9fdf-1da8e1419d1f_3296x1440.png)

You're not imagining things…

I just moved to Substack.

It's part of a bigger plan that will take me from $4,000 to $10,000/month.

I'll explain how the plan looks shortly.

But first, I just moved my entire email list here — some mistakes happen when moving. So some might be added here by mistake. If that's you, please feel free to unsubscribe.

As for you, dear reader, who can't get enough of me yapping…

I wanna share with you the reason behind the move and my plan that will take me to $10,000/month (and how you can do it too).

I've broken this down to two parts:

- Growth
- Monetization

Let's start with part one.

# **Part 1 — Growth**

My friend Noah convinced me to move to Substack. I was hesitant at first.

I thought it was just hype and the reason why people were joining was because of FOMO (we’ve seen the same thing happen with Threads).

But I've seen some promising results.

Sure it's still small — compared to X which has 500 million, or LinkedIn with 1 billion users — Substack is a baby with only 10 million active users. But this also means that it has a lot of room for growth.

So if you're one of the few who join now, you're reaping all the benefits of being an "early-bird".

The reach here is crazy.

So here's my plan on how I'm gonna be growing.

X will still be my main platform. It's my bread and butter. I know how to go viral over there on repeat and keep seeing exponential growth.

So what I'll be doing is repurposing some of my content from X and turning it into Substack notes (the equivalent of tweets).

The weekly letters will be posted here.

And because of how Substack works — your followers being your email list — every weekend I'll be syncing my Beehiiv list with Substack.

The reason is because Substack is still behind in terms of email marketing ability.

Why is this a problem?

This leads me to the second part…

# **Part 2 — Monetization**

Everyone is motivated by money (you can't pay rent by being kind).

Those who deny it, suffer, struggle to make any meaningful change in their life, and think that the world is out to get them.

My advice:

Ignore them. They'll only hold you back from reaching your goals.

Surround yourself with people who are optimistic.

_**If you want to have a positive impact and make a dent in this world, you need money.**_

As for monetization, landing clients and customers is much simpler than you'd think.

And I feel like I have created a flywheel that turns readers into loyal fans who support your work.

It all starts with your high-ticket offer…

### **1) Your High Ticket Offer**

People throw the word "high-ticket" around like there's no tomorrow.

For me, high-ticket means $2,000+/month/client.

Not $500.

Not $750.

Not $1,000.

$2,000. That's high-ticket.

And if you want to reach $10k/month, you only need 3-5 clients a month.

To sell high-ticket offers, you need high-value skills like, marketing, ghostwriting, paid ads, copywriting, sales, video editing, graphic design, web design, etc — these are usually Done-For-You services.

I chose ghostwriting. Simply because that's the skill I learned.

I know how to do it well. I can get results relatively easily.

I've done ghostwriting before — in the beginning, I wrote for everyone. Therapists, CEOs, founders, entrepreneurs, writers, coaches.

I've burned out multiple times ghostwriting. It happened so often that I started hating it.

Not because I took on too many clients, but because I was writing about things that I didn't have an interest in.

I was taking clients who were aligned with my ideas and brand — when you do this, you hurt yourself in the long run. You fill your mind with your clients' ideas and not yours. So when it comes to writing content for your brand, you can't think clearly.

But recently, I've spoken to someone who's a big creator (4+ million followers) and is more aligned with my brand and ideas.

And from what it looks like, it seems like it's going to be a long-term partnership.

But I'll limit ghostwriting to one client only — that's $2,000-$3,000 per month consistently.

The reason why I'm limiting it is because of the next point…

### **2) Mid-Ticket Offers**

With ghostwriting, you're earnings is capped.

You deliver huge results for your clients (some start to make 5-6 figures a month because of your skills), but you're still only getting paid $2,000-$3,000.

So if you can deliver those kinds of results for your client, why don't you do it for yourself as well?

That's why I'll be having one core offer — [The Profitable Micro Business](https://docs.google.com/document/d/1IoghOCCFlb4OelWZ7Atov3zCbr9hJLkUHwJyhGRCcmg/edit?usp=sharing) — a 12-week group coaching program

It's everything I know about:

- How to build an audience — how I built my audience to 20,000 followers and 2,000 email readers in 8 months.
- Creating offers that are so good that your audience starts begging you to take their money.
- How to create landslide launches and monetize (even when you have a small audience).
- Landing higher-ticket clients without doing any cold outreach or relying on sleazy tactics.

This offer will be limited to 10 members — two people have already joined this program even before I launched it. Looks promising so far.

But that's not all.

Every 2-3 months, I'm planning to run a 30-day group coaching.

These will be different.

They're more focused on people who are interested in being more consistent with their writing, audience building and monetization.

It's "lower-ticket" than [Profitable Micro Business](https://docs.google.com/document/d/1IoghOCCFlb4OelWZ7Atov3zCbr9hJLkUHwJyhGRCcmg/edit?usp=sharing), but it means it's available for more people.

Now… the question is "How will I get people into those programs?"

Because not everyone can invest $500-$900 for coaching.

This is where the last step comes in.

### **3) Low-Ticket Offers**

In my eyes, low-ticket offers are for two things:

- Build trust
- Display competence

Which is why I'm currently working on turning The Modern Creator (my current group coaching) into a digital product.

I can serve people at scale and at a much affordable price.

But that's not all.

Every two weeks, I'll be running paid workshops.

These solve smaller problems, but are highly actionable.

So far, I've done two, and people loved them. And since I enjoy doing them, it seems like it's a perfect match.

_Student from the Profitable Micro Business Program will also be getting free access to these workshops._

And the best part about paid workshops is you get to filter out "freebie seekers" from high-quality followers.

From my experience, 10%-30% of people who join these workshops end up converting into higher-ticket clients.

So that's my plan for reaching $10,000/month in the next 3 months.

Thank you for reading and enjoy the rest of your day.

- Hussain

**P.S.**

Speaking of workshops…

I'm thinking of hosting one called "How To Do A 5-Day Launch and make $2,000+ every time (Even With A Small Audience)"

If it sounds like your cup of tea, reply to this with "I'm interested".

If there are enough responses, I'll do it.

Cheers.

[Subscribe now](https://hussainibarra.substack.com/subscribe?)


---

<!-- Archivo original: posts/2025-06-29-the-fastest-way-to-grow-an-audience.md -->

---
titulo: "The Fastest Way To Grow An Audience (In 2025)"
subtitulo: "Grow so fast that it feels illegal"
fecha: 2025-06-29T16:01:27.823Z
url: https://hussainibarra.substack.com/p/the-fastest-way-to-grow-an-audience
audiencia: gratis
palabras: 2118
likes: 21
comentarios: 4
---

# The Fastest Way To Grow An Audience (In 2025)

_Grow so fast that it feels illegal_

[![](https://substackcdn.com/image/fetch/$s_!CS7c!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F22200423-5440-4bca-a190-4b7db717f9a2_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!CS7c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F22200423-5440-4bca-a190-4b7db717f9a2_1920x1080.png)

I always wanted to do what I love for a living.

_Isn't that what we all want?_

But somewhere during our development, we get reprogrammed into what society tells us to do.

Go to school. Get a job. Stop thinking for yourself. Get a mortgage.

And for 20+ years that's what I did.

I followed the default path that society has laid down for me.

That's until the summer of 2023.

I landed a 3-month internship at the biggest private developer in Dubai.

And when I graduated from university, they hired me.

I got to see firsthand what it's like to be working on mega projects.

And what I saw from my coworkers was my biggest nightmare…

Depressed. Miserable. Financially struggling. Sleep deprived. A marriage that's barely surviving.

Their entire mind is consumed by "work".

They were living to work…

That's when I realized that society won't give you what you want in life.

So if you want freedom, you need to build something that you own — a business.

And if you're like me, you weren't born to a billionaire father whom you can ask for loans or born with a silver spoon in your mouth.

So I had to start from scratch and start a micro business — you create content (video or written like this one), build an audience, market your skills, sign clients, make money.

It might take a little longer, but it costs nothing to start and run (perfect for a broke college student like I was once) and everything you make is pure profit.

I started writing online and created a product almost immediately — it was a fitness guide on how to get in shape.

I wrote it after I gained 33lbs of muscle in 1.5 year.

But when it came to selling the product, I noticed a problem…

I didn't know how to get people to see the guide, let alone buy it.

It's fair to say that no one bought the guide.

It was a complete flop.

But I learned a crucial lesson from this experience…

=====

_Gentle reminder…_

_I'm hosting a live call in 24 hours._

_The topic?_

_**Create Landslide Launches That Guarantee You Make $1,000-$4,000 With Each Offer (Even If You Have A Small Audience).**_

_So if you have an offer and you're struggling to land clients, tired of sending DMs and not seeing any response, and want to sell more of your offer (product or service) without second-guessing yourself…_

_[Now is the time to join.](https://stan.store/hussainibarraabboudi_233/p/landslidelaunches)_

_=====_

[Subscribe now](https://hussainibarra.substack.com/subscribe?)

# **Traffic = Money**

This is a mistake most founders (and creators) make:

They focus too much on the product and not enough on traffic (eyeballs) and when it's time to launch, they realize that they don't have anyone to sell it to.

And an audience is the best traffic you can have.

This is why I'm running my business with an _audience-first _approach.

**Why the audience-first approach is the best way to start a business:**

- **The barrier to entry is extremely low:** Anyone can start sharing their ideas online, building an audience of like-minded people, create a digital product that solves your problems, and selling it to their audience (who also struggle with the same problem).
- **People have grown out of paid ads:** People are programmed to skip ads the moment they seem them — I don't remember the last time I or any of my friends have bought something from an ad.
- **High profit margins:** My business makes ~89% in profits and the more I make in a month, the higher the profit margins become. A micro business costs you nothing to run. All you need is a social media profile and a method to accept payment (PayPal or Stripe, which take around a 2.8%-7% fee) — if you want to be really fancy, you can start using different software for emails, hosting products, etc. But that’s just extra.
- **Your brand grows as you grow:** This is the only approach that I've found that follows human nature and evolution. Most businesses put you in a box and your entire identity is based on it. But with an audience-first approach, you get to talk about interests, share ideas you care about, solve your own problems and create solutions that other people can use to solve their own problems. With this approach, you get paid to live your life the way you want to.

My first 14 months of writing were hell.

I posted every day, followed "expert" advice, did all the work they told me to do.

But I saw no progress.

Email list was at 70 people, had 800 followers, and sales weren't consistent.

But now I have an audience of 20,000+ people in the last 8 months.

I'm not an expert.

I'm not a guru.

All I know how to do is generate traffic.

A LOT OF TRAFFIC.

That's all I really do.

I get people's attention on social media (traffic).

I send people to a page.

People buy from that page.

That's it.

But that is the best skill you can have if you want to start a business.

Like I said before:

Traffic = Growth

Growth = Customers

Customers = Money

Money = Freedom

So that means, traffic = freedom.

Now, let me show you how to build an audience as fast as possible (after 2 years of writing).

_I wish someone had told me this before…_

[Subscribe now](https://hussainibarra.substack.com/subscribe?)

# **‍How To Build An Audience (FAST)**

To build an audience you need two things:

- Attention
- Trust

You build trust and sell your products in your newsletter — _[70%-80% of my revenue came from my newsletter.](https://hussainibarra--kierandrew.thrivecart.com/magnetic-emails/)_

But unlike what most people think, your newsletter doesn't magically grow.

To grow, you need to go where attention flows — social media is the best place to gain attention.

When you gain attention, all you have to do is direct that traffic to your newsletter.

When you do this correctly, you'll start making that sweet, sweet Benjamin.

In this letter, I'll talk about attention — social media— because it doesn't matter if you have the best newsletter in the world, if no one sees it, no one will read it. If no one is reading, no one is buying.

### **1. Pick The Right Platform**

Social media is where all the attention is.

There are a bunch of platforms you can start writing on — LinkedIn, X (Twitter), Threads, Instagram, and Substack.

But some perform better than others.

My advice?

Pick a platform that (1) gives you fast feedback, (2) doesn't punish you for posting many times a day, (3) has a lot of users already, and (4) is already proven that you can build a real business off of.

Substack is great. It's VC backed (that means they'll pay a lot of even if it means making it work) and it has a lot of potential (they're one of the fastest growing social media platforms now).

But I'm a huge fan of X.

It meets all the criteria I just mentioned and it's already established (500 million users) and it's already been proven that you can build a successful business with it.

This is why I'm a fan of X.

- You can post 10 tweets and not get punished.
- You can get immediate feedback on your posts.
- You aren't judged by how you look or sound — you're purely judged by how good your ideas are.
- People have already succeeded on X (and it's a good representation that you'll succeed as well).

### **2. Become A Leader**

People don't follow for information.

People follow you because you're leading them towards a vision.

Think of your favorite creators. Why do you follow them?

Usually it's because they lead you towards a vision. A vision that you want to have. A life that you want to live.

And the same goes for you.

Where are you guiding people towards?

If you don't know where you want to lead them, start with yourself.

Ask: _"What kind of life do I want to live?"_

Find that answer, if you don't know, start experimenting.

Anything that sounds interesting, give it a crack. Talk about it, write about it. Share it with the world.

If you don't like it, tell people why.

If you do, great, talk about it more.

Write about what you're doing and how you're going to bring that vision you have to life.

Tell your audience your game plan.

Everyone likes to be part of a story that's unfolding in real time.

### **3. Write Killer Short Form**

Nothing will teach you how to become a more concise and articulate thinker, writer, and speaker than writing short-form.

You're forced to package your big idea into a 280-character post.

Here's how to write good short-form:

- Pick an idea (any idea).
- List out the benefits of your idea (how will it impact someone else’s life? Why should they do it? How does it serve your vision?)
- Write about that idea from your own perspective. Don't worry about the first draft.
- Use proven copywriting structures to package your idea in a way that makes it impactful (if you want, look up AIDA and PAS frameworks)
- Edit it. Make it punchy, snappy, and short.
- Iterate based on feedback and engagement.

The goal of short-form isn't to solve problems. It's to change people's perceptions and beliefs when it comes to an idea.

The goal of short-form is to capture attention, stay on top of people's minds, and to practice writing.

### **4. Educate People With Medium Form**

In my eyes medium-form content has two goals:

- Build trust
- Display competence

If you're looking to explode your audience — get a "shortcut" — this is the way to go.

95% of my audience came from threads (medium-form content).

For other platforms:

- IG = Reels
- TikTok = 10-30 second videos
- YouTube = 5-10 minute videos
- Substack = Doesn't have one…

And it's the same for all the big creators — Dan Koe, Tim Denning, Kieran Drew, Dickie Bush, Nicolas Cole — they all did it with threads.

Why I'm bullish on threads:

- They have the highest growth potential (if done correctly).
- Each thread can add 100-2,000 email subscribers.
- You can sell low-ticket products ($100 or less) directly in your thread and expect to make a sales every time— every thread that I write and promote a low ticket product made me a sale.
- You can have leads book a call with you.
- If written well, it can be turned into a newsletter outline or a YouTube video script.

On X, I'm known as the "threads guy" — and for good reason.

My growth exploded because of threads.

I was a ghostwriter for founders, entrepreneurs, and health experts — I’ve built their brands and landed clients for them with threads alone.

Now, every time I open X, I see one of my posts get plagiarized.

The Modern Creator Bootcamp was built entirely around threads.

_[The Profitable Micro Business](https://stan.store/hussainibarraabboudi_233/p/the-profitable-micro-business) is the big brother version of The Modern Creator Bootcamp, it’s the complete roadmap for starting a social media business on X from scratch._

But another reason why I love threads so much is if you're anything like me, you love doing deep dive.

You love taking notes and educating people.

Threads help you add more depth to your content.

You get to show people you know what you're talking about — and when done correctly, you can build an entire business with it

### **5. Promote Shamelessly**

The greatest lie we've been told:

_**Build it and they'll come.**_

Truth is, if you don't promote yourself every day, you'll never get what you want.

Promote your newsletter under one of your posts — at least once a day.

Promote your newsletter under your threads.

Promote your newsletter in your bio.

Promote it everywhere.

It's your greatest asset.

That's where your real fans are.

That's where your customers are.

Stop ignoring them.

Drop your ego.

And promote. Every. Single. Day.

That's all for today.

Thank you for reading and enjoy the rest of your day.

- Hussain

**P.S.**

A gentle reminder:

In 24 hours, I'm hosting a live workshop.

Inside, I'll show you how to promote an offer and make $1,000-$4,000 each time without having to second-guess yourself, needing a big audience, or being an expert.

You'll also have access to my best-performing emails and posts, so all you have to do is copy/paste the process over to your brand and see success.

So if you want to make more money, work less, and build a stress-free business…

[Now is the time to join.](https://stan.store/hussainibarraabboudi_233/p/landslidelaunches)

**P.P.S.**

Because I want to give you the best experience possible, I'm not running this workshop again.

And I'm not selling replays.

But if you do join, you'll get the replay and notes.

[Subscribe now](https://hussainibarra.substack.com/subscribe?)


---

<!-- Archivo original: posts/2025-07-13-7-lessons-i-learned-after-making.md -->

---
titulo: "7 Lessons I learned After Making $12,985 From My Small Writing Business"
subtitulo: "The good. The bad. The lies. The lessons."
fecha: 2025-07-13T09:59:16.340Z
url: https://hussainibarra.substack.com/p/7-lessons-i-learned-after-making
audiencia: gratis
palabras: 1684
likes: 9
comentarios: 3
---

# 7 Lessons I learned After Making $12,985 From My Small Writing Business

_The good. The bad. The lies. The lessons._

[![](https://substackcdn.com/image/fetch/$s_!tJtg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd0fb3757-d549-4c58-b8cc-3d9b9b3c802e_2912x1632.png)](https://substackcdn.com/image/fetch/$s_!tJtg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd0fb3757-d549-4c58-b8cc-3d9b9b3c802e_2912x1632.png)

In the past 3 months, I had 6 launches.

That's an average of one launch every 2 weeks.

The goal behind it?

Get good at sales emails.

Just 5 months ago, I didn’t even know what a sales email even was.

So I'm far from being an expert at email marketing or copywriting. After all, I'm a graduate student who's building a writing business on the side.

But I'm happy to say that I've gotten much better at sales emails (at least that's what my readers and expert copywriters are telling me).

However, before I tell you the lessons, here's a breakdown of the $12,985

- The Modern Creator Cohort (launch 1) = $3,750
- The Modern Creator Cohort (launch 2) = $3,000
- 1-on-1 coaching = $2,500
- Workshops = $2,749
- Ghostwriting = $750
- Productize Your Knowledge (affiliate) = $236

So without further ado… here are the 7 lessons I learned:

## **1) Email is King**

My email list is 1/10th the size of my audience on social media.

_(2,000+ readers compared to my 22,000+ followers on social media)_

But 90% of my revenue came from my email list.

_See? size doesn't always matter…_

Now, you might be wondering why am I selling on email and not social media, or sales call, or DMs?

3 reasons why:

1. On social media, only about 1% of your audience actually gets to see your content. But with emails, almost 40% of people get to see your content.
2. I have an extremely low social battery. So getting on sales calls with people just leaves me exhausted afterwards — just last week, I had 3 back to back calls with clients, and I was tired for the rest of the day.
3. I also don't like wasting hours of my time pestering and begging people in the DMs hoping for someone to decide to work with me.

This is why I built my entire writing business around NOT doing them.

Which is why I love emails so much. You get to write about topics you love, you invite your readers to invest, and if you did a good job, you make a sale.

You save time, you have higher leverage (1 email can lead to 10+ sales).

The most valuable asset you have in your business is your email list.

## **2) The Low-Ticket Lie**

All most all of the big creators sell preach about low ticket products.

_"Create a $150 course and sell it. It's passive income"_

Don't get me wrong. I'm a huge fan of courses and low-ticket $100 workshops. They're a great way to build trust and relationships with your readers.

You get to show them that you know what you're doing and you're someone worth investing in.

But 71% of my revenue came from selling my higher-ticket offers — group coaching or 1-on-1 coaching.

The only way I can see you can make low-ticket offers work is if you have a lot of traffic coming in (i.e. you have millions of followers, a huge email list, or are running paid ads).

## **3) Aspirational Hourly Rate**

Earlier this year, I read a concept from Naval Ravikant and it blew my mind:

**Aspirational Personal Hourly Rate.**

In short, you decide how much your hour is worth.

At the beginning of this year, I was making around $40/hour from my writing business.

So when I decided to set my hourly rate, I set it at $200/hour.

Why?

I don't know. All I knew is that it made me feel scared and if somehow I could pull it off, then I must be doing something right.

I increased my private coaching prices from $750/month → $1,250/month.

I also created "lower-leverage" offers — group coaching — $750 for 5 calls.

This allows you to serve more people at scale while working less.

But after setting my $200/hour aspirational hourly rate… I forgot about it. But my subconscious mind was always working on achieving that goal — after just 2 months, I reached it — now, I am ~$325/hour.

Writing this makes me realize that I should increase my hourly rate to $425/hour…

So you'd like to work with me closely to help you build an audience and gain more readers towards your business and writing…

Now is the time to take advantage of it.

I'm increasing my prices on July 17th from $1,250/month to $1,675/month.

_**[Build your audience today.](https://stan.store/hussainibarraabboudi_233/p/the-oneperson-business-shortcut)**_

## **4) You Need To Learn This Skill — Marketing**

Most people see marketing and sales as evil.

Perhaps they've had a bad experience before or that's just the idea they have from all the shows and movies they've watched.

_I've certainly had the same perception of them._

But recently, I realized how wrong I was.

Marketing and sales are spiritual.

If you're a good person, you need to learn how to market and sell.

Otherwise, how will you help other people if you can't convince them to buy your products?

Now, I don't want to get into too much depth here because I'm already working on another newsletter called _"Sales & Money is Spiritual."_

But the reason why you need to learn marketing as a fundamental skill for your life is because it is the skill that puts you in the best possible place to help others.

It's how you make others aware of their problems and the solutions that exist.

And if you want to turn your passion into profits, you must learn how to hunt for yourself — build, promote, and sell your own products — not relying on your boss to do the selling for you and pay you pennies in return.

All the successful writers, creators, and entrepreneurs that are making $50k-$100k/month I've met this year, all of them, by no exception, have nailed their marketing.

Marketing and nailing my launches is what helped me go from getting paid $40/hour to $300+/hour

Marketing is what separates starving artists from thriving artists.

[Subscribe now](https://hussainibarra.substack.com/subscribe?)

## **5) Business Growth = Personal Growth**

In my last workshop, the software I was using to sell, Stan, stopped working just 3 hours before the deadline.

I didn't know this at the time. So I went on with my normal schedule, delivered the workshop, people loved it, and I went to sleep.

But I woke up the next day to 5 emails from people telling me how they couldn't join because the website stopped working.

That's $500 lost…

If this was 12 months ago, I would've been upset about it for the next 2-3 months.

But this time?

I laughed it off.

My reaction was: "This would make for a really good story."

I was so surprised by my reaction that I even told my mentor about it. I saw it as a win. I was _glad _that I lost on that $500. Because it made me realize that I don't even blink or care about a $500 sale anymore.

It showed me how much personal growth you can have from running a writing business.

Who cares about losing $500 when your business can make you $500k?

## **6) Passion Projects**

A launch requires a lot of effort.

Doing one every 2 weeks is exhausting. After my 5th launch I was starting to burn out.

Yes, writing sales emails are fun, I was laughing at my own jokes when I was writing them, but it's the creative energy it demands that's exhausting.

And if you don't have the right systems in place, you could easily run yourself into burnout.

But one good thing I had was having passion projects. Projects where I get to write and explore my ideas without having to worry if it'll lead to a sale or not. Writing these weekly newsletters are my passion projects.

When you get to do something for the sake of enjoying it (not because you want to get a sale or leads for your business), it energizes, it fills you with excitement and motivation to keep going.

So a habit I had during my launches was to write down the ideas that excite me or caught my attention.

Now, whenever you're struggling to find an idea you write about, you can just open your folder of ideas and see it filled to the brim.

It makes the writing process much easier.

## **7) Things Will Always Go Wrong**

Like I said, at my last workshop, some people couldn't join because my software stopped working 3 hours before the deadline.

But in almost every launch something went wrong.

I'd send the wrong emails. I forgot to put the correct links. Emails are going out at the wrong times. Sending too few emails. Typos… A LOT OF TYPOS…

But that's all part of the learning curve.

With every launch, you learn something new and you improve.

The process of running a launch became faster, more enjoyable, made me more money, and most importantly, people liked reading them.

I even started getting emails from people saying: _"How can I write emails like you?"_

Which made me think, if I should run a small group coaching where I help you write emails like me.

Emails that build your relationships, revenue, and reputation with your readers.

Because I know what it feels like to have great ideas but not have anyone reading them or feel like what you're writing has no impact.

So do me a favor…

If you'd be interested in joining a 4-week exclusive group coaching where you get to discover how to write engaging sales emails (that don't feel sleazy)…

Reply to me with your biggest problem and what you're hoping to achieve with your emails (i.e. make more money, build an audience, start writing in your voice, etc).

The more detailed your answers are, the better I can serve you.

Thank you for reading and enjoy the rest of your weekend.

- Hussain

[Leave a comment](https://hussainibarra.substack.com/p/7-lessons-i-learned-after-making/comments)

**P.S.**

Gentle reminder:

I'll be increasing my 1-on-1 mentorship on July 17th from $1,250/month to $1,675/month.

If you'd like to build an audience, your emails, and turn your passion into profit.

Now is the time to join.

_**[Start building a loyal audience today.](https://stan.store/hussainibarraabboudi_233/p/the-oneperson-business-shortcut)**_

[Subscribe now](https://hussainibarra.substack.com/subscribe?)


---

<!-- Archivo original: posts/2025-07-16-what-goes-behind-writing-one-good.md -->

---
titulo: "What Goes Behind Writing ONE Good Post"
subtitulo: "Most people never get to see the Behind The Scenes"
fecha: 2025-07-16T09:35:39.613Z
url: https://hussainibarra.substack.com/p/what-goes-behind-writing-one-good
audiencia: gratis
palabras: 1564
likes: 8
comentarios: 0
---

# What Goes Behind Writing ONE Good Post

_Most people never get to see the Behind The Scenes_

[![](https://substackcdn.com/image/fetch/$s_!n6fV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd937e817-0cf6-4843-aa8f-c43ccfe99283_2912x1632.png)](https://substackcdn.com/image/fetch/$s_!n6fV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd937e817-0cf6-4843-aa8f-c43ccfe99283_2912x1632.png)

I got bombarded with DMs the past few days.

People were all asking me about my thought process on how I approach writing a thread on X.

So instead of answering every person individually, I figured I'd show you.

Earlier this week, I wrote a newsletter called "_7 lessons after my writing business made over $12,985"_

I had some ideas to include in that letter, but I didn't feel like they were "newsletter worthy" — it would be a shame to let them go to waste…

So the best thing I could do is show you a bit of what goes on behind the scenes when I'm writing a thread on X.

Let me show how I'll write the thread.

#### _A word of warning… it gets messy…_

Before I show you, let me make a cup of tea and put some music on (I like to listen to The Weeknd or Cigarrettes After S*x when I'm writing).

_Making a cup of tea…_

_Searching for the right song to listen to…_

_Still searching…_

_Got distracted with my cat…_

_Found the song!_

_Got my tea ready._

_Ok… back to writing…_

## **The Goal**

Every thread must have a clear goal:

- Are you trying to go viral?
- Be useful?
- Sign clients?
- Get email subscribers?
- Gain followers?
- Book a call?
- Display competence?

For me, the goal of this thread is to show people how I did things — being useful.

So I'm not expecting it to go viral and I'm ok with it.

_Not every thread has to go viral._

## **The Big Idea**

I always like to start my threads with the hook.

The reason I do this is because the hook captures your big idea.

Here's my hook:

[![](https://substackcdn.com/image/fetch/$s_!AlVB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc76bfd7f-e5fb-4ce2-92fb-5922738e48ea_1080x598.jpeg)](https://substackcdn.com/image/fetch/$s_!AlVB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc76bfd7f-e5fb-4ce2-92fb-5922738e48ea_1080x598.jpeg)

Simple and straight to the point.

But I'm not too happy with the promise I made: _How to make your first $1,000 from writing._

But we'll see if I'll change it later on.

Let's move on with the outline

## **The Skeleton**

I like to always create key points of what I want to include inside the thread.

Here’s the general outline I have:

> Write on social media
> Build your email list
> Be Useful
> Send emails
> Be Shameless

Again, I like it.

It's on the shorter side of things — the thread by be 6-9 tweets long (not including the hook or CTA) — usually my threads are 12-15 tweets long. But I'm happy with it being short.

## **Adding The Meat**

A few question come up to my mind now:

- Why do [X]?
- How to do [X]?

I'll ask these questions for each point I laid out:

Why should you write on social media?

> _5.52 billion people are on social media. The internet is a big place. You can reach anyone just with a laptop._
> _You don't need to be an expert…_

While I was writing the tweet, I got rudely interrupted by another idea. I think I know what to to include on "build your email list"

> _Only 1% of your social media audience will see your content. But with email, it's 40%._
> _On social media, you only have 2 seconds to make an impression, you're fighting against other creators._
> _But with email, it's a 1-on-1 conversation. It's much more personal and you're not fighting other distractions._

Not too happy with how this came out. It's too long and wordy. I'll come back to it later.

But now, let's go back to why you should write on social media...

> 1) Write On Social Media
> _The internet is a big place. There are 5.52 billion people on it. That's potential 5.52 customers for your business._
> _You just need to capture a small audience to build a profitable business._
> _2 pieces of advice to building an audience:_

In the last line I did something I like to call "bridge".

It helps me break up my idea into two parts. I do this to avoid the "Show more" button.

But back to the 2 pieces of advice…

> _A) Pick one platform_
> _A problem most beginners fall for is they try to be everywhere at once._
> _Choose one platform and stick to it. You'll grow faster and make more progress_
> _B) Write to one person_
> _When you write for everyone, you write to one. Write to one person, the previous version of yourself._

This tweet is 296 characters… not good…

I have an idea to make it shorter.

> _A) Pick one platform_
> _Most beginners try to grow on every platform at once. But they grow on none_
> _Choose one platform and stick to it. You'll grow faster and make more progress_
> _B) Write to one person_
> _When you write for everyone, you write to one. Write to one person, the previous version of yourself._

Somehow I made it longer, 300 characters…

Ok, I think I found a way to make it shorter this time, for real.

> _A) Pick one platform_
> _Most beginners try to grow on every platform at once. But they grow on none_
> _Choose one platform and stick to it._
> _B) Write to one person_
> _When you write for everyone, you write to one. Write to one person, the previous version of yourself._

254 characters. Good.

But I don't like the last sentence….

It doesn't capture the big idea of this part — you writing to the best person you know, your previous self.

Let's change Point B to Serve Your Shadow.

It sounds cooler but also captures the big idea.

> _A) Pick one platform_
> _Most beginners try to grow on every platform at once. But they grow on none_
> _Choose one platform and stick to it._
> _B) Serve Your Shadow_
> _When you're creating content, you want to write to one person, and who's better than your previous self?_
> _You know their fears, struggles, problems, and frustrations._

A question came to my mind when reading "you want to write to one person":

_Why should you write to one person only?_

1. It makes it easier to capture their attention — which makes creating content and understanding their problems easier.
2. You want to be _their_ favorite writer — which makes buying easier.

OK. Now I have an idea on what to say:

> _A) Pick one platform_
> _Most beginners try to grow on every platform at once. But they grow on none_
> _Choose one platform and stick to it._
> _B) Serve Your Shadow_
> Write To Your Previous Self
> _Why?_
> _You know their struggeles, fears, hopes, and dreams._
> _Be THE writer for someone._

Looks good to me. For now…

But I’m re-reading my thread, and I’m not happy with the “Write On Social Media” tweet.

It feels too shallow. It lacks the “ounf”. There’s no drama. It’s too logical — human beings are emotional.

Let me see what I can do.

> _1) Write On Social Media_
> _The biggest lie you've been told: "Build it and they will come."_
> _To build a business you need to go where attention flows._
> _There are 5.52 billion people on social media. That's potential 5.52 billion customers for your business._
> _But you only need a small audience to build a profitable business._
> _2 pieces of advice to building an audience:_

I'm repeating myself with the "5.52 billion customers" sentence. People aren't that dumb.

I can also remove the "biggest lie you've been told” — and the “Write On Social Media” sounds boring. I can make it sound more abstract.

> _1) Reach_
> _To build a business you need to go where attention flows._
> _There are 5.52 billion people on social media._
> _You only need a small audience to build a profitable business._
> _2 pieces of advice to building an audience:_

Ok, I’m happy with how it looks now.

Let's see how the thread is looking like now:

[![](https://substackcdn.com/image/fetch/$s_!wyDF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd6ad8486-9c0e-45c6-bcb2-20e4222b196d_1080x598.jpeg)](https://substackcdn.com/image/fetch/$s_!wyDF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd6ad8486-9c0e-45c6-bcb2-20e4222b196d_1080x598.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!--M9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5da30336-93df-4e61-a4df-46c2e656901a_1080x784.png)](https://substackcdn.com/image/fetch/$s_!--M9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5da30336-93df-4e61-a4df-46c2e656901a_1080x784.png)

[![](https://substackcdn.com/image/fetch/$s_!hX50!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F632ce1dd-2a0f-4757-9907-6098606ff981_1080x1080.jpeg)](https://substackcdn.com/image/fetch/$s_!hX50!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F632ce1dd-2a0f-4757-9907-6098606ff981_1080x1080.jpeg)

Now, I’d love to keep showing you my entire thought process behind each post, but I finished my tea, so that means my writing sessions is over and this letter is already more than 1,300 words…

================

_24-hours older Hussain here with a new cup of tea…_

So I just got around to finishing the thread this morning — obviously I couldn’t show you the entire thread because we'll be here all day.

But I changed the "skeleton" I had. Here's how it looks like now:

> Reach
> Email is King
> Be Useful
> Be Shameless
> Volume

They are more abstract and feel like they capture the big idea better.

I also changed my CTA from the typical "subscribe to my newsletter" to my guide "How to grow an audience in 2025 (FAST)"

Why?

Because when I'm reading this thread, the main problem that people have is a lack of growth and my newsletter helps people solve that problem, so it makes sense.

And I’m aware how this letter makes me look like I’m a crazy overthinker but this is usually how my threads look like — this thread is also considered as “low-effort” thread where I’m not really overthinking things.

_You should see how I write my viral threads. I spend days obessing over the smallest details._

With that said…

Thank you for reading and enjoy the rest of your day.

- Hussain

**P.S.**

In 24 hours exactly, I’ll be increasing my 1:1 mentorship from $1,250 to $1,675.

So if you’re trying to grow an audience on X (or Substack) and want to skip beginner’s hell and want to get to the “fun part” of building a creator business of monetizing…

This is the time to join.

[Here’s the link.](https://stan.store/hussainibarraabboudi_233/p/the-oneperson-business-shortcut)


---

<!-- Archivo original: posts/2025-07-20-if-you-want-to-monetize-your-writing.md -->

---
titulo: "If You Want To Monetize Your Writing Don't Monetize Your Newsletter — Do This Instead"
subtitulo: "A complete guide on how to make your first $1,000 from your writing"
fecha: 2025-07-20T14:29:07.788Z
url: https://hussainibarra.substack.com/p/if-you-want-to-monetize-your-writing
audiencia: gratis
palabras: 1694
likes: 21
comentarios: 4
---

# If You Want To Monetize Your Writing Don't Monetize Your Newsletter — Do This Instead

_A complete guide on how to make your first $1,000 from your writing_

[![](https://substackcdn.com/image/fetch/$s_!cqGT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5621d14d-93ad-4abd-bcad-9c4340f219a2_1456x816.png)](https://substackcdn.com/image/fetch/$s_!cqGT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5621d14d-93ad-4abd-bcad-9c4340f219a2_1456x816.png)

_**Paid Newsletters Are A One-Way Ticket To Burnout**_

I moved to Substack almost 4 weeks ago now.

In my first week, I got 2 people pledging $120/year.

That's $240/year for no extra work.

But I immediately turned off the option to monetize my newsletter.

Because I realized that it's just a distraction.

I see it all the time on Substack:

_"Substack just paid for my rent, flight, holiday, and dinner. I just replaced my full-time job with Substack."_

Now you get all sorts of ideas.

_"If I could get 1,000 people to subscribe to my $5 newsletter, that's $5,000 per month!"_

Passive income baby!

But if I learned one thing after writing for 2 years, it would be this:

There's no such thing as "passive income" — everything requires you to put effort.

The house you're leasing requires you to find tenants, maintenance, and constant care.

The stocks you own require you to buy every month, sell, hold, and keep track of the news.

Sure, some methods are easier than others, but the concept of "making money without work" is false — paid newsletters are no different. If anything, they require MORE work than other methods.

And it's hurting you more than you'd think.

Here's why:

- **Recurring Revenue Means Recurring Work: **You'll always have to write newsletters, you can't take a break. If you do, people will leave. If you change your content, people will leave. If your content isn't good enough, people will leave.

- **You Become Distracted: **A paid newsletter will put you in an awkward spot. You need to find content that is too good to be free, but also not good enough so that you can have something to sell as high-ticket offers. So now you're constantly trying to do 3 things — it's better to just focus on having free content and having a CTA to a paid offer that you have.

- **You Need A Very Big Audience To Make It Work:** Only 1% of your readers will buy from you. The rest are just more than happy to keep reading your stuff. Nothing wrong with it, but when you drill this concept in your head, you'll realize that you'll need a very big audience at a $5 subscription to hit your monthly target. If you want to reach $10k/month, you'll need an audience of 200k (this will lead to 2k paying customers). But most people can't even gain 500 free readers.

- **Nobody Wants More Emails: **Go out and ask people, "Who wants to receive more emails?". No one. So why do you think people will happily keep paying you? Some people will read your paid stuff, think it's not worth it, and stop paying you next month. That's called churn. And most people don't have the skills to keep their churn rate low.

- **Growth Stops:** Because of your paid newsletter, you now don't have as much time as you would to growing your audience. You'll be too busy writing for your paid content. Your clients get worse results because you're not focused on them as much as you are. You don't want to write sales emails and promote your offers to your subscribers because you feel bad asking them for more money. All of this stops your growth.

- **It's A Slow, Grueling Grind To The Top:** If for some weird reason, you still think paid newsletters are the way to go, this point will help wake you up. In the beginning, you'll only have one or two paying subscribers. That means, from the start, as soon as they pay you, the hamster wheel of needing to write paid content starts. Until you gain those 2,000 paid subscribers, it'll take you YEARS to get to (because of churn, slow growth, lack of skills, and many other factors). You'll be spending hours every week writing paid content just to make $10 every month. Now tell me, is it worth the effort?

But there's a better way to monetize your writing.

Let me show…

# **How To Monetize Your Writing In 90 Days (As A Beginner)**

## **1) Learn A Skill**

If you have a 9-5, you have a skill you can monetize.

If you were like me, a broke college student who spent all his life playing video games and has no real-world experience, then you'll need to learn a skill.

You don't need to have a fancy degree to offer your services.

All you need is as you're learning a skill, build projects to gain experience.

That's the beauty of the internet. It decentralized experience.

You no longer need to spend 4 years getting a degree just so people can pay you.

You just need 3 months of learning a skill and building projects to gain experience.

If you don't know what skill to learn, learn writing.

It's the foundation of all high-value skills.

It's the skill of all skills.

- Ads
- Sales
- Design
- Content
- Podcasts
- Marketing
- AI prompting
- Public speaking
- YouTube scripts
- Email marketing

They all depend on how well you write.

## **2) Create An Offer**

This is arguably the simplest, but hardest thing you'll ever do when it comes to monetization.

Because there are so many moving parts that you don't even know where to begin.

So I'll simplify it in 5 simple points:

- **The 4 Eternal Markets:** Health, wealth, relationships, and happiness. Every problem you can think of can be categorized into one of these 4 domains. Once you know your domain, ask yourself these two questions: _Am I saving people time or effort? Or is it both?_

- **Who Are You Selling To:** It is easier to sell to one specific person than it is to sell to 100 different people. The internet is a big place. Most people think it's where you shout from the mountaintops, but in reality, it's about whispering into people's ears with the right message. Once you have the right message (offer), all you need to do is find the right people who resonate with it. Then the internet becomes a huge search engine for you. All you'll need to do is dial in your messaging and capture their attention.

- **What Are They Getting:** People love to buy. They love feeling they're changing their lives. Your offers should do the same. It should change people's lives. Doesn't have to be a drastic change, but there must be a change, a transformation. From "hey, I have this problem" to "I don't have this problem anymore"

- **How Much Does It Cost:** Name your price and justify cost.

- **Why You & Not Someone Else: **Hundreds of other people are selling the same offer as you, so why should your reader buy from you and not someone else? If your answer is "because I'm the cheapest," then you have already lost, because there will always be someone who's willing to sell for a lower price. The best answer is to figure out what makes you different.

For example, I'm not the only one who teaches people how to grow an audience or monetize their writing.

But most people who teach others how to monetize tell you to send cold DMs and do sales calls to land clients.

However, inside [The Profitable Micro Entrepreneur,](https://docs.google.com/document/d/1IoghOCCFlb4OelWZ7Atov3zCbr9hJLkUHwJyhGRCcmg/edit?usp=sharing) I don't teach that.

Matter of fact, I tell my clients NOT to do cold outreach. Those who resonate will pay you. Those who don't won't and that's okay.

To nail this part — what makes you different — you'll need to understand what your readers are sick and tired of hearing and seeing.

It’s only then, you’ll nail your messaging and positioning.

## **3) 4 Methods To Find Clients**

[![](https://substackcdn.com/image/fetch/$s_!hLbZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1f557cc5-98dc-4af0-a939-05224591a3f3_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!hLbZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1f557cc5-98dc-4af0-a939-05224591a3f3_1080x1080.png)

My favorite method is High Leverage-Warm Traffic. This is content, newsletters, and emails.

Why?

- Because it's free and the reach is insane. When you know how to capture attention and generate traffic, you'll have ~89% profit margins.
- You already have an audience, why not sell to them directly? They already know you, trust you, and like you enough to buy from you.
- It doesn't require you to break your back like other methods — cold outreach, cold DMs, cold calls.
- It doesn't require you to be an expert or need to burn through a lot of money like paid ads.

Once you find clients, deliver on your offer and promise you gave them.

## **4) Refine, Iterate & Charge More**

As you land more clients and deliver results.

You'll notice patterns emerge. Some questions keep popping up again and again.

My advice:

Collect every question you get and slowly refine your process.

As you do, future clients will get better results.

Charge more for your offer.

As you get more expensive, create lower-ticket offers.

Which leads me to my last point…

## **5) Evolve As You Go**

As your private 1-on-1 coaching gets more expensive, some people might not be able to afford you.

This is where you create lower-ticket offers to help them.

They can be courses, guides, or group coaching.

That's what I've done.

My 1:1 coaching was $500 at first. 2 months later, it was $750. Then it was $1,250. And last week I increased it $1,675/month.

Which is why I created the [Profitable Micro Entrepreneur.](https://docs.google.com/document/d/1IoghOCCFlb4OelWZ7Atov3zCbr9hJLkUHwJyhGRCcmg/edit?usp=sharing)

It's a group coaching version of the 1-on-1.

It's $175/week or $700/month, and you'll be getting the same level of support.

The only difference?

No private calls. They're all group calls.

And as my group coaching gets better, the prices are only gonna keep going higher and higher.

That's all for today.

Thank you for reading and enjoy your weekend.

- Hussain

**P.S.**

If you'd like to build an audience and monetize your brand…

I just opened 10 spots for The Profitable Micro Entrepreneur.

More than 2,000 people are seeing this email.

So to be fair to everyone, seats are given out on a first-come, first-served basis.

Doors close on Tuesday.

[Take a read here.](https://docs.google.com/document/d/1IoghOCCFlb4OelWZ7Atov3zCbr9hJLkUHwJyhGRCcmg/edit?usp=sharing)

[Leave a comment](https://hussainibarra.substack.com/p/if-you-want-to-monetize-your-writing/comments)


---

<!-- Archivo original: posts/2025-07-27-6-months-is-all-it-takes-to-completely.md -->

---
titulo: "6 Months is All It Takes To Completely Reinvent Your Life"
subtitulo: "How your mental programming decides what kind of life you'll have"
fecha: 2025-07-27T22:30:06.588Z
url: https://hussainibarra.substack.com/p/6-months-is-all-it-takes-to-completely
audiencia: gratis
palabras: 3245
likes: 462
comentarios: 41
---

# 6 Months is All It Takes To Completely Reinvent Your Life

_How your mental programming decides what kind of life you'll have_

You're 6 months away from completely changing your life.

The problem is most people think 6 months is too long.

They're so used to quick fixes that they don't realize that change takes time.

Change takes intentional effort. Conscious decision making. And the consistency to do it every day until it becomes their new identity.

6 months is nothing compared to 30 years.

Like I said, most people are looking for quick fixes.

Their search history says it all:

- “How to lose 15 pounds in a week.”
- “The easiest way to make passive income.”
- “How to run a business without learning any skills.”

There's nothing wrong with wanting to get into good shape or making money. The problem is wanting it to be easy. To want all the upside without the downside.

Ancient Chinese thinkers figured this out thousands of years ago when they came up with the concept of Yin and Yang.

To be want to be in good shape, it requires you to give up junk food and to work out to build muscle.

To build passive income, you'll need to build a profitable business, invest, and nurture your investments.

To run a business requires you to learn skills — even though AI can do most of the work with design, writing, marketing, ideation, you'll still need to develop the skill to ask it the right questions and give it the right instructions.

Back when I was in undergrad, every weekend, I would always drive 2 hours from my house to my dorms, and then another 2-hour drive back when I finished for the week.

So I had nothing to do in those drives but to think and reflect about my life and the people around me.

And I'll never forget this moment.

It was 2021, in the middle of the night and I was driving back to my dorms from my house. And as I was reflecting, I came to a radical realization:

**Everyone in my life, my family, friends, teachers, and mentors, always preached about how you needed to get good grades so you can get a better job that pays you more.**

At first glance, there' nothing wrong with their advice. But subconsciously, they all preached how you should be working for someone else.

They all thought of themselves as "less than" or not as good enough to make it on their own so they always felt the need to resort to working for someone else.

# **Society's Programming**

> If you don't know what you want to do, society will tell you what to do.
> - Robert Greene

There is a default path that everyone gets put on.

It's the path of the mindless people who don't want to wake up.

School, college, job, promotions, mortgage, marriage, kids, retire, and when you're on your deathbed bed you realize that you've spent the majority of your life living someone else's life, not yours.

I don't know about you, but to me that's my worst nightmare.

The problem is most people are living this way and they don't know it.

They go about their days not questioning their actions. Mindless actions. Numbing their minds with cheap dopamine because facing reality is too painful.

Society is a ruthless place. It doesn't have space for waste.

If you don't know what you want to do, you'll be told what to do.

If you don't create your own goals, you'll be assigned goals.

If you don't create a routine, you'll be assigned a routine.

The problem with society's programming is it conditions you to expect linear results and so whenever you start something new, learning a skill, going to the gym, or building a business and you stop seeing linear results — which is inevitable — you immediately think that you've failed, you stop. and go back to your default's programming.

The problem with society's program is they train you into thinking life is linear.

You pass your exams, so you move up to the next grade.

If you fail your exams, you stay where you are and keep trying until you do pass.

It's a binary system.

But the real-world isn't as simple as that.

You can have a great product or a business idea and still fail and it's fine.

It's normal.

Because the real world isn't binary. There are no guarantees or assurances.

Once you understand that, you'll become aware of society's programming and how monotone everyone lives' are.

They're living mechanical lives, mechanical thoughts — generally somebody else's mechanical emotions, mechanical actions, and mechanical reactions.

They relive the same 6 months for the rest of their lives. That's not living. That's hell.

The way you break free from this programming starts by asking a question most people never want to ask themselves:

Who are you when you strip away everything society told you to become?

# **Understanding The Self**

_"Who am I?"_

This is a question I've been asking myself a lot recently.

Because if you don't understand the problem — yourself — you can't solve it. You can't become something else unless you understand what you are now.

So _"Who am I?"_

Am I an engineer, a writer, a graduate student, a researcher, a bodybuilder, a runner, depressed, or happy?

Which one is me?

Wait…

Did you see what just happened?

The "I" referred to "me".

That means "I" is aware of "me", but "me" isn't aware of "I".

You can visualize this by seeing yourself in third-person view. You get to see your physical body from someone else's point of view. You get to observe yourself.

So the question now becomes, which one is you?

Which one is "I"?

Are you the observer or the physical body?

The "me" can't be you because it wasn't aware of itself. So what are _not_?

- You are not the thoughts that you think — thoughts come and go.
- You are not the emotion you feel — emotions are temporary waves that normalize with time.
- You are not your body — your body regenerates millions of cells every minute and millions of cells die every minute.
- You are not your profession — you can always change your job and the "I" is unaffected.
- You are not your name — you can change your name, but the "I" is unaffected.

So that means you're the observer. Because the observer is detached from all feelings, thoughts, emotions, beliefs, body, physical, and labels that you can put on it.

My friend, what you just discovered is called awareness, and there are 3 levels to it:

- Awareness of things (spatial)
- Awareness of thoughts ("me")
- Awareness of the thinker ("I")

The thinker — the observer — is the "I".

That's the real you, but you'll almost never come to understand the real you, because once you do, you'll start putting labels, and the "I" is detached from labels.

Labels belong to "me". The "me" is always changing. But the "I" stays the same. It's constant.

Niagara Falls' water keeps changing, but it stays the same. It doesn't matter even if you change its name. It's gonna stay the same. Because the "I" isn't dependent on the name either.

The power of "I" is you becoming detached from everything.

That means you're not the story that you told yourself. You are not your past. You are not the hardships that have happened to you.

You can always change your story.

# **How To Reinvent Yourself — Waking Up**

> **You don't do anything to be free, you drop something. Then you're free.**
> **- Anthony De Mello**

You don't "find" yourself.

You already have it.

So the goal isn't to gain something, but rather to drop everything so you're only left with the real you.

By doing dropping everything that you've been programmed by society, you begin to chip away at all the fat and only be left with the essence.

This is extremely hard to understand and conceptualize if you haven't done any form of meditation or read any philosophy or spirituality.

But once you understand that you are whole — in the sense that you have everything you need to build the life you want — you begin to realize that searching and becoming becomes stupid. Because you can't become something you already have.

The real you is already there, it's just been buried under all the decades of subconscious programming that has been done to you by society.

The key is to let go of that programming to allow the Self to prop up.

Nobody can tell you how to change. Nobody can tell you a method or a technique on how to do it. The moment you pick up a technique, you're programmed again.

People can only help challenge your ideas — those ideas lead to change. But you have to think for yourself and come to your own conclusions.

What I'm about to give you are general frameworks. You'll have to go through each step and experiment with it yourself. The answers I found and have worked for me will be completely different from what you'll find.

This process takes months, sometimes even years to happen. But it doesn’t matter how long it takes because living life on your terms is the greatest gift you can ever have.

### **Step 1 — Awareness**

The first step to reinventing your life is awareness.

You must become aware of your actions, thoughts, beliefs, ideas, and everything in between.

Are you aware of your reactions as you're reading this letter?

If you aren't you'll be brainwashed by everyone. You'll be influenced by forces within you that you don't even know they exist.

The goal is to observe.

It sounds counterintuitive but if you want change, you can't interfere.

Just like a scientist trying to understand how animals behave, he does not interfere until he understands what they're doing and why they're doing it.

At this stage, you just need to become aware of your thoughts, the conditioning and programming that has been done to you.

You'll start to realize you have thoughts that were never yours.

As I am writing this, I am getting the urge to check my phone. I am not fighting against myself by saying, "You can't check your phone until you finish writing this section". If anything, I simply acknowledge the fact that I have this urge. If I do pick up my phone, then it's fine, I haven't "failed".

Don't judge yourself. Don't try to change. Simply observe.

It is important that you don't judge your actions. Because once you start judging, you start shaming, and shame is the worst way to drive change.

Which is why I think self-help books are a complete scam. They make you feel like you're "less than" and that there is something wrong with you — which is why you need to read self-help books.

But the reality is, you just need to observe your action and not judge.

Like we said, the "I" is detached from the physical realm. It has no feelings, no emotions, no judgment.

It simply observes. Observation alone is enough to change the trajectory of your life. Observation is awareness. Through awareness you find yourself.

Once you become aware of your actions, you become aware of what _not _to do — this leads to a vision.

### **Step 2 — Create A Vision**

The vision guides your thoughts and actions.

A vision moves in the right direction. It creates its own discipline. Similar to how a river as it moves towards the sea — it creates its own banks that contain it. You don't need to have all of the vision figured out. You just need something to work towards.

4 weeks ago, my friends and I were laughing about hosting an in-person Creator Economy Conference in 2026 in Vancouver, Canada.

But 2 weeks later, we've got the venue sorted, main speakers booked, tickets, marketing, and landing page all planned.

There was a small problem with all of this — currently I'm making $4,000-$5,000 per month — that means for me to travel from Dubai to Canada it's gonna cost me $4,000-$5,000 — a full month's of work.

I even wrote in our group chat: _"This got me hyped, I need to get to $30k/month"_

I said it as a joke.

I didn't have any idea on how I'll reach there. But just having a vision in place will kick your subconscious mind into play. And your subconscious mind is more powerful than you'd think.

All of a sudden, I launched a group coaching program — 4 people joined — and as time goes on, more and more people will join. Next week, I'll start promoting the 30-Day Writer.

And 5 days ago, I got the idea of starting a ghostwriting agency — I know many ghostwriters, my friend has the leads, and teaming up just sounded like a no-brainer.

If you asked me 6 months ago if I'll ever start a ghostwriting agency, my answer would've been no. I'm still not sure if this is something that I'll enjoy doing long-term. But you'll only know this through experience.

So if everything goes to plan, I'll reach the $30k/month faster than I would ever expect (probably in the next 4-6 months).

> **The important part is this:**
> _You don't need to have all the answers when you create your vision. Pick a general direction you want to go and start moving in that direction — the path will reveal itself as you walk._

Humans are a goal-driven species. We interpret and view the world based on our vision. Your vision shapes your reality.

Create a vision. It doesn't need to be perfect and start moving towards it.

Your vision is the filter for your reality.

### **Step 3 — Install New Programming**

If the vision is the filter, then your programming is the focus.

Your programming shapes what you pick up on and what you miss.

A bodybuilder who goes to a gym will get the idea of how he can buy better equipment and create a food stand for other bodybuilders in the gym.

Someone who's into business will go to the same gym and spot the opportunity of how he can market the gym better and get more people to sign up.

Both are in the same gym, at the same time, two completely different ideas.

The reason this happens is because of their programming. One cares about building more muscle, the other cares about making money.

A vision kicks you into action and your programming keeps you on track.

Just like how society gave you the vision of becoming successful — by their absurd definition of success — they installed a program with it. Go to school, get a job. Chase an imaginary corporate ladder for 40 years. Always work for someone else for 8-10 hours a day for 5 days a week. Ask no questions.

The same thing you need to do to yourself if you want to reinvent your life. You need to install a new program.

Here's how to do it:

**1) Change your circle.**

Stop talking to friends who keep you stuck in life. If your friends are happy seeing you fall into your old self-destructive habits, they're not your friends. If they make fun of you for trying to improve your life, they're not your friends.

My advice: cut them off.

They're with you because you make them feel good. They feel good because they feel superior to you — and seeing you improving your life is painful for them because they can't handle the fact that you're better than them and they'll leave you when their social status is threatened by you.

**2) Consume new information.**

Stop following the news. Stop watching brain rot content. Stop following drama.

Follow creators and writers who force you to challenge your thoughts, see new perspectives, and propel you towards a life that you want.

Social media isn't toxic. Social media isn't just for entertainment. Social media is a reflection of your consumption habits.

For me, social media is extremely healthy. Every time I open an app I get filled with ideas and inspiration for what I want to write about.

Read new books.

Don't tell me "but I like to read AI summaries because it's all value and there's no fluff — you need to understand is books were never meant to be about learning or being actionable. You have courses and YouTube tutorials for that.

Books are meant for programming. You get to develop the sense of seeing a new perspective and question your current perspective. Reading AI summaries is mental masturbation. You're still running on old programming of getting cheap dopamine hits to avoid the pain of being woken up to reality.

I've had a really good education. It's taken me years to get over it. When I did get over it, I realized something:

Success isn't about learning more. Success is about unlearning most of what you've been taught by society and learning through self-experimentation and through real-world feedback.

**3) Listen to podcasts that help you get closer to what you want to achieve.**

I know a friend who listens to Naval Ravikant every day, multiple times a day.

When I started writing online, I watched hundreds of YouTube videos about the philosophy behind running a writing business. Through self-experimentation and trial and error, I came to the conclusion that a micro business is the best business to have.

**4) Write about your vision.**

Every day, write about what you want to achieve and why other people should do it. You're actively training your subconscious mind to spot opportunities and rewire your brain to success.

If you're not actively programming yourself to success, you're actively programming yourself to failure.

**5) Learn new skills**

Learn new skills that will help you take on new interesting challenges.

As you get better, the harder the challenges become which exposes you to different perspectives. You don't become one-dimensional in your thinking.

### **Step 4 — Obsess Every Day Until It Becomes Second Nature**

The most successful people I know don't think about what they want to do.

A bodybuilder doesn't think to eat healthy, he does it on autopilot.

An investor doesn't need to think about checking the stock market, it's part of his daily routine.

A writer doesn't need to think to write, he writes because it's part of what he does.

I've obsessed over writing and running my creator business for the past 2 years. Now I no longer need to think of what I need to do or write about.

I've also been working out for the past 2 years. Now I don't need to think about going to the gym or going for a run. I do them because I want to. It's more painful for me to not write, not to go lift weights, not to go for a run.

If you've done all the previous steps correctly, becoming obsessed should feel relatively easy. You should feel like you _want _to write, to build your business, to launch products, to go to the gym, to read books. Because the pain of not doing it is more painful than doing it.

That's all for today.

Thank you for reading.

Enjoy the rest of your day.

- Hussain

**P.S.**

This is the first time I've written about spirituality/self-improvement in a long time.

Let me know what you think about it.

[Leave a comment](https://hussainibarra.substack.com/p/6-months-is-all-it-takes-to-completely/comments)


---

<!-- Archivo original: posts/2025-08-07-the-5-stages-of-wealth-creation-and.md -->

---
titulo: "The 5 Stages of Wealth Creation (And Why 99% Of People Are Stuck At Stage 2)"
subtitulo: "How society brainwashed you into being poor"
fecha: 2025-08-07T13:30:44.478Z
url: https://hussainibarra.substack.com/p/the-5-stages-of-wealth-creation-and
audiencia: gratis
palabras: 5049
likes: 24
comentarios: 4
---

# The 5 Stages of Wealth Creation (And Why 99% Of People Are Stuck At Stage 2)

_How society brainwashed you into being poor_

Making money makes you a good person.

Wanting to make more money makes you a good person.

If you think you are a good person, then you have a moral obligation to make more money.

And if you're already making money, you have to make more.

This isn't about being greedy, exploitive, or evil.

This isn't just about "start a business to make money". It's much bigger.

Making money is spiritual.

This is one of those concepts that you have to keep repeating to yourself until you etch it into your subconscious mind.

So let me repeat myself:

_**"If you are a good person, you have a moral obligation to make money."**_

This is hard to understand, especially if you're like me, you come from a family who told you that money isn't everything, money is evil, or you shouldn't care about making money.

For a long time, I believed them.

But now, I realize the phrase "money is evil" is the biggest lie we've been told as kids.

Think about this for a second — when someone tells you "money is evil", what message are they sending to your subconscious mind?

I'll tell you.

Only evil, greedy, and exploitive people who only care about themselves make money and become rich.

But if you're a good, honest, hard-working person, you are supposed to supper, be poor and struggle for the rest of your life.

I don't know if you believe in God or a high-power, but I do. So I refuse to believe that God, who is all-loving, all-good, will allow evil to win and let those who are good suffer.

Society has done a great job of programming us into thinking money is evil.

In movies, shows, and even the news, wealthy people are almost always evil corporations, corrupt politicians, drug dealers, and criminals.

So again…

**If you are a good person, you have a moral obligation to make more money.**

Thinking "money is evil" and not wanting to make money is a lazy way of viewing life.

Money is so fundamental in our lives that it affects every aspect of our lives but many choose to live in a delusion that they don't care about money then they wonder why they're so miserable in their lives.

Your education depends on your money. Your health depends on money. Your relationships depend on money. Your status is massively dictated by how much money you earn. Your mental health depends on how much money you have — the more money you have, the less anxious you'll be about meeting your monthly bills.

The goal of this letter is to get across this message:

**If you don't start a business to provide information, education, solutions that helps people live a better life — unethical businesses, corrupt politicians and government will rise to the top and make society a worse place.**

By not starting a business, you are directly helping evil.

By refusing to start a business and seeing business, marketing, and sales as evil, you are forced to work for someone who is "unethical" — by your standards — to give you money and live your life.

There is no such thing as "doing nothing". Choosing to do nothing is choosing to not do good — that's the same as choosing to let evil win.

If you consider yourself to be a good person, you have a moral obligation to _always _do the right thing.

No matter how small it is.

# **Making Money Is Spiritual**

Spirituality is understanding your part in the Universe.

Spirituality is all about waking up and seeing reality for what it is, not what you _think _it should be.

Spirituality is not you disappearing from the world, living in the mountains, doing mushrooms, meditating for months, and achieving enlightenment.

Spirituality is understanding, feeling, and knowing that you have the power to make the world a better place by helping humanity to "wake up" and help advance the collective consciousness.

Money is how you can make a change in this world. Money is the only objective and sustainable way to keep doing good in this world.

Everything in this world that helps humanity is built around money.

- Charities host fundraisers because they need money.
- Temples accept donations because they need money to stay open.
- Schools need money to pay for books, teachers, and resources to educate students.
- The Vatican — arguably one of the most religious and holy places on earth needs money — sells tours and souvenirs to keep operating.

Money is spiritual.

To make money, you need to create value in society.

But a lack of money puts you in survival mode and you can't create anything valuable when you're operating from survival mode.

When you're operating in survival mode, you're creating from a place of "lack" — your perception narrows, you miss information and opportunities that help you in your creation.

You need to create from a place of wholeness and a place where your perception is wide.

This is why you need money.

When you are financially secure and aren't operating in survival mode it frees up almost all of your mental bandwidth and worries.

Making money is how you survive in the modern world.

We used to run from lions and predators because they threatened our survival — now a lack of money threatens our survival — mentally, emotionally, and spiritually.

This is why I keep saying money is good — money isn't inherently evil or neutral.

Money is good.

I'm repeating this phrase many times in this letter because you need to truly understand it in your bones that money is good.

It took me 3 years of daily action and conscious programming to wake up and realize that money is good.

Society has done a pretty darn good job at convincing us that money is evil and that "it's not everything", but it is.

A common saying I hear is: _"The best way to make money is by teaching others how to make money."_

People say this to point out how everyone who teaches you real skills, skills that can change your life, and is charging you for it, is a scammer.

But they never stop to think that the $150 you spend on a course that teaches you a real skill and gives you knowledge that could help you start a business and change your life is more valuable than the $1,000 they spend on junk food, gambling, alcohol, and drugs every month.

The beliefs of _"Courses are a scam"_ and _"If you're so successful, why are you charging money for it?"_ is what's holding most people back in their human development and their ability to make more money.

They fail to realize that spending money to learn a skill changes how they perceive and receive the information.

They fail to realize that money dictates almost every decision a person takes — even the most "spiritual" people are motivated by money (to some extent).

Anyone who says that they're not motivated by money is lying to you.

Money is deeply connected with modern survival.

You work 8 hours a day, 5 days a week, 45 years straight because you need to get paid, put a roof over your head and take care of your family.

You work out, eat healthy, dress well, so you can increase your perceived value and status, to attract better opportunities, partners, and make more money.

The urge you get to go off to the mountains and disconnect from reality to eliminate the need for money, and to achieve enlightenment.

But what you fail to realize is what you're doing is selfish. You give up and refuse to play your part in the universe and to take responsibility to make the world a better place.

The reason I am writing this letter is because I run a writing business.

I make money by writing on social media, publishing weekly newsletters, and sending sales emails (when do I decide to sell something).

Even at the end of this letter there is a call-to-action to join a group coaching program.

Writing pays my bills.

So is money the _only _reason why I'm writing?

No.

But I'd be lying if I said money plays a big role behind my writing, because it does.

However money isn't everything.

I write to gain clarity, to share ideas I find interesting, to be creative, to express myself, to identify my problems, to solve problems I have, to share the solutions I found _and _to get paid.

But I also write to help you realize that you don't need to follow societal programming. That you can live life on your own terms. That you can get paid doing what you love. The only thing that's stopping you from living the life you want is your perception, beliefs, and ideas that you tell yourself. If you end up buying from me, great, if not, also great.

The most important goal behind my writing is to help you wake up and become aware of the self-limiting beliefs that are holding you back in life.

If you want to make a positive change and make a dent in this world, you need money.

# **Admit It, You Are Selfish**

Everything you do is selfish.

You might tell yourself you're not selfish, but that's a lie.

You are selfish.

You do charity work because it makes you feel good.

You work hard to provide for your family because they're _your_ family, not someone else's.

You'll die for _your _country, not for another country.

Some people want money because they only think about themselves. Others want to make money so they can help their family. Very few people want to make money so they can give it to charity and do good in the world.

They're all doing it for selfish reasons.

The second and third person just have more refined taste.

Being selfish doesn't make you a bad person. It just means you're human. The faster you accept the fact you're selfish, the faster you'll start to see progress, because you're not lying to yourself anymore.

There are 5 stages to making money — I call this concept The 5 Stages of Wealth Creation.

Every stage is selfish, but with each one you develop a more refined taste.

The purpose of money changes with each stage.

# **The 5 Stages Of Wealth Creation**

### **I) Survival**

Your goal determines your perspective — what you pay attention to and opportunities you spot.

When you're in the survival stage, you won't notice money-making opportunities. Your mind is too occupied with bills, mortgage, rent, car payments, insurance, the relationships problems that come out because of the lack of money you have.

At this stage, money isn't at the top of your priority because you have more life-threatening tasks right in front of you.

A homeless man won't notice or even care that the stock market is down by 20% — he's too busy trying to figure out how he'll eat and survive the day.

So when you're here, you're forced to take any job to survive.

To escape, you need a basic level of income (enough to put food on the table, a roof over your head, and a little extra in case of an emergency) and becoming deeply aware of your conditioning and beliefs that are holding you back.

Start questioning where the self-limiting beliefs came from and how they affect your life.

Almost every problem you face at this stage is solved by "making more money". Nothing wrong with it. If anything, it's a good thing. Because you get to live a better life and help those around you.

You get to free up your mental space and mental energy that you can later use to help you move on to the next stage of development.

### II) **Status**

Humans love to brag about how smart they are but in reality they're still monkeys.

As much as we like to say "don't judge a book by its cover", we do judge a book by its cover.

We always think who's monkey #1 and monkey #2.

When you're at this stage, you have a sense of security around money, and you're doing financially well — you also realize the need for others to perceive you as valuable.

You want to move to a higher socioeconomic place — because your mental health and level of well-being are correlated with how you are nested within your social hierarchical structure.

The more money you have, the more status you can gain, which increases your level of happiness and well-being.

So when you're here, you acquire skills that help you increase your value in society, which leads to more opportunities. You start landing better jobs. Signing bigger clients. Making connections with the right people who help you excel even more.

All of this leads frees up more of your mental energy to focus on improving your other areas of life — health, looks, manners, speech, relationships.

The problem is society's programming stops here. Society doesn't care about creativity. They want employees who do the job, tick boxes, clock in, clock out, and ask no questions.

So society programmed you to "do more".

Work more so you can get a new promotion with a fancy title.

Work more so you can buy fancy suits and drive fancy cars.

The life of indulging in cheap and surface-level pleasures quickly becomes old.

I am from Dubai, so when I was younger, I got to live a "dream" lifestyle. I would spend $200 on breakfast on a random Tuesday. I would buy designer clothes that I don't like to impress people I hated. Life started feeling shallow.

In school I was doing great. Got admitted in the best university in the country. When I graduated I landed an engineering job at the biggest developer in Dubai. Worked on mega projects and closed 6-7 figure deals every week. Now I'm at university again, getting my master's in environmental engineering. I have a full scholarship and I even secured a full scholarship for when I go and get my PhD abroad and I get to choose the university I want — and I am still only 23 years old.

Based on society's standards, I have status and I am "successful".

Not to mention the writing business I am running (but I don't tell people that I have a writing business).

I am not saying this to brag, but to show you that status isn't hard to achieve once you know how society operates. All what society cares about is status. Society is shallow. Society judges a book by its cover.

If you want to gain status, dress well, get in shape, brag about how successful you are, brag about how much money you're making, and brag about what projects you're working on.

In the office, always look like you're somewhat annoyed, every time you finish a task, tell your boss you just finished a task. Before starting a task, tell your boss you're going to start a task. Always walk around in the office with papers in one hand and act like you're speaking in the phone.

People will always think, "This guy works really hard, he deserves a raise".

But you're not doing any work. You're just playing the status game.

When you signal status, people start treating you differently. They take you more seriously, and opportunities fall on your lap.

But what I realized is as you get higher in the status level, progression slows — I realized that I was chasing the wrong goals in life. I was doing what society wanted, not what I wanted.

### **III) Creativity & Mastery**

You've escaped the status game.

You no longer think in terms of who's monkey #1, who's #2.

You now have a more refined taste. You begin to notice all of your mistakes.

You wake up. You are now beyond the social programming.

You realize how pointless everything that you've achieved is.

You have the money. You have the status.

The cars, the fancy dinners, the expensive watches, designer clothes, all of those desires become old. They don't hit the same as they once did.

You begin to crave something more meaningful and deeper — this is where creativity and mastery come in.

You understand that humans are meant to be creative.

At this stage, you're not doing it for the money, because you have money, you're doing the work because you want to — you realize that humans are meant to create, be creative, and pursue their interests to the point of mastery.

At this stage, you'll need to develop a philosophical view of life — of what your purpose is and what you want to do.

When you develop that view, you'll notice a few pursuits stand out.

Robert Greene doesn't need to write to make money or to gain status. He's a 7x NYT bestseller and made millions from the books he sold. For him, writing is a form of self-expression and creativity. It's art to him.

This is the creativity stage.

Before, almost everything you learned and did was based on what others told you to do.

In this stage, you explore the unknown and begin to create a new path — your own way of doing things.

You've tried different programs, learned many skills, achieved goals, and experienced life in ways no one else has. Your goal in this stage is to simply create.

To be successful as a creative person, you need to go through the first two stages. Creativity demands calm, peaceful, and clear mind. You can't create something meaningful from a place of lack, a place of weakness. You can only create from a place of wholeness and a place and strength.

When you're creative, you break free from the societal programming and always needing to be told what to do and follow rules that nobody knows where they came from.

You build novel solutions from your mind.

Once you get a taste of what creativity feels like, you snap and naturally move to the next stage of human development.

### **IV)** **Autonomy**

Once you've had that taste of creativity, there's no turning back now.

You reach escape velocity. You transcend.

All that's on your mind at this point is wanting to have autonomy over your life so you can be creative and pursue mastery.

You become deeply aware of what you're doing on a daily basis. Your calendar is carefully curated around giving you the most energy.

The autonomy stage acts like a bridge. Between creativity and the next and final stage…

### **V) Purpose & Consciousness**

This is what everyone is secretly striving for but doesn't know yet.

You aren't working or running your business for money. Money becomes a tool for your purpose in life.

Remember, you're still selfish.

Like I said before, everything we do is because it makes us feel good in the end. In this stage, you feel good by improving other people's lives.

You're still selfish — but you have a more refined taste.

When you reach this stage, you still need money.

If you're not making money, whatever purpose you're trying to achieve, it won't be sustainable.

When you're here, you have a set of high-value skills and the creativity to impact other people's lives — your family, friends, community, and even the entire world with the internet.

You feel motivated to go and _do good_ in the world.

You feel a pull that tells you to share everything you know that has helped you in your life.

You begin to see life from a new perspective.

All domains of your life become one — work, rest, and play become impossible to tell apart.

You don't see work as something _you have _to do.

Work becomes something you _get to do._

All you think about is your purpose.

All you care about is advancing human consciousness and making people aware of what reality is like and what they need to focus on.

_**Note about the 5 stages of human development:**_

There isn't a certain number you need to make per month for you to move from one stage to another.

You get to decide how much money is enough for you to move on to the next stage of human development — and it all comes down to awareness, perspective, and your unique experiences.

# **How To Make Money (Spiritually)**

> _**Sensible people get paid to do what they enjoy.**_
> _**- Alan Watts**_

The internet is where the permissionless economy lives.

You no longer need fancy 4-year degrees or 20 years of experience to sell. If you solved a problem in your life before, you are more than qualified to start a business and sell your solution.

The reason why most businesses fail because they try to solve a problem based on what they _think _people should do.

They try to solve a problem without having experienced the problem.

So they create complicated 17-step solutions to a problem that people don't even have — then they complain by saying "people don't appreciate real value" just because they couldn't make a sale.

No, people didn't buy your product because you're solving the wrong problems. You're trying to guess your way to success.

It's better to create a solution from experience than to _guess_ what people want.

My philosophy is to turn yourself into a business.

You solve your own problems.

You write content for yourself.

You create solutions to a problem that would've helped you in the past.

You market for yourself.

You sell to yourself.

When you understand how all humans are the same — we all struggle with the same problems, want to achieve similar goals and have the same desires, you'll see that a one-person business and turning yourself into a business is the only sustainable and logical way of running a business.

Here's how to turn yourself into a business (and get paid to improve your life):

### **Identify A Problem**

You're not the only one who's struggling with health, financial, relationship, focus, or productivity.

There are thousands of people who are struggling with the same problem you have.

Pull out a notebook.

Write down:

- Exactly what you don't want your life to be like — be extremely specific.
- Everything that you are doing wrong right now
- Where will you be if you refuse to change your behavior

Pick the most pressing problem.

Then start experimenting.

### **Self Experiment**

No one can solve your problems for you.

There is never a one-size-fits-all solution.

You will have to try different methods, programs, and techniques to find what works best for you.

When I started going to the gym, I started with a Push, Pull, Leg split, then moved to upper/lower, then did calisthenics for a while, started running marathons — after 2.5 years of lifting, running, and trying almost every program I found on the internet, I created a program that works for me.

The same thing happened to my writing business. I spend ~$6,000 on courses and $5,000 on mentorships to understand how to run my business.

That's when I learned that the only way to solve your problems for good is through self-experimentation.

You won't know if a program, method, or technique is good unless you try it. You won't know if you're into spirituality unless you read about it and practice it.

I never thought I would be writing about spirituality and societal programming until I started reading and writing about these topics.

Buy courses, read books, listen to podcasts, and try templates.

Give everything you can get your hands on a try. Take notes. A lot of notes when you're experimenting — what you liked, what didn't like, what worked, what didn't work.

Become the mad scientist who's in his lab and is tinkering with his experiment, changing one variable at a time, and observing what's happening.

Once you've experimented and solved the problem, create your own solution based on your experience — usually, it'll be a mix of different solutions.

### **Create A Structured Program**

Based on what you now know, how would you teach a beginner to solve the same problem?

People don't like to buy half-built solutions or woo-woo guides with a bunch of information — it needs to be practical to some extent.

Create a clear program to help others solve the problem you just solved, but in less time.

If you don't know how to create a program, ask AI to help you do it. Look at the courses you bought and see how they are structured.

### **Build Distribution**

The internet is a big place.

There are millions of people who share the same ideas, beliefs, problems, mindset as you do.

There are thousands of people who are struggling with problems that you've solved.

Your goal is to build distribution and attract them to your brand.

There are 3 ways to build distribution:

- **Buy:** You buy distribution by paying for sponsorships, Google ads, Facebook ads, newsletter ads.
- **Borrow: **You borrow distribution by asking your network to market for you, you appear as a guest on podcasts, you write guest newsletters for other people's publications.
- **Build: **You build distribution by going on social media and building an audience.

I'm going to assume that you're a beginner, you don't have a lot of money, and that you don't have any connections to get yourself on podcasts or have the skills to run profitable ads.

So the best option for you to take is to build your distribution.

It's free, you can write about what you love and find interesting, you get to express your authentic self, and build a fan base around your brand.

Go on social media. Start writing content that resonates with you (because what resonates with you will resonate with other people). Test new ideas. Share your interests.

Drop your beliefs of having to "niche down". You are human, you have multiple interests, hobbies, and ideas.

Niching down means turning yourself into a glorified search engine — you won't win on social media if your entire content can be compressed down into actionable steps, How To's or advice. AI can pump thousands of them in seconds.

Go broad. Speak about your problems from a big picture view. Talk about your interests to appeal to a wider audience and attract like-minded people. Your goal is to talk about what life is like before and after solving their problems. Write to appeal to their deeper desires.

Your readers want to feel seen, heard and understood.

Having an audience means now you have thousands of people that you can help.

### **Learn Money-Making Skills**

Making money is a skill.

You need money to survive. You need money to make the business you're running sustainable.

Those who refuse to learn how to make money are starving artists. They are still running on the old social programming of "money is evil". But like I said, money isn't bad, it's not neutral, money is good.

For a long time I thought if I just became better at writing and wrote beautiful posts (like this one), I'll make more money.

But for almost a year I struggled to make even $1,000 per month.

However, now I am making $5,000 without struggling. My writing got better, but what helped me the most was learning money-making skills.

If you want to have an impact in this world and make money, you need to learn marketing, persuasion, sales, psychology, spirituality (yes spirituality is a money-making skill when you know how to relate it to living a better life).

You need persuasion to get people to listen to you and to show them that your solution is right for them.

You need psychology to understand how people think and behave so you can better understand your audience.

You need spirituality to understand what people are trying to achieve in their lives.

You need marketing to get your message in front of the right people to increase the likelihood of people

You need sales to get people to give you money, take your solution seriously, and make what you're doing sustainable.

Charities host fundraisers to make money. That's them doing sales.

_If you want to focus on one thing, focus on writing. It's the foundation of all high-value, money-making skills._

### **Deliver & Fulfill**

Once you have an audience and something to offer them, you can deliver it as a digital product or as a service (coaching, consulting, done-for-you).

If this is your first time selling your solution, go for coaching or group coaching.

Because what worked for you won't work 100% for someone else. This way, you're reducing the risk of people not finding value in it and feeling lost — you'll also get real-world feedback on your solution and discover blind spots that you weren't aware of previously.

One reason why I love coaching so much is you get to see your impact on people's lives. Your clients tell you how you're changing their lives in real-time. There's nothing more fulfilling than seeing how you can

### **Iterate & Refine & Evolve**

Once you've gotten a few people in your group coaching and received feedback, you get to iterate and improve on your solution.

You get to make it smoother.

After a while, you can turn your coaching into a digital product, film a few videos, create worksheets and exercises for people to follow so you can free up your time to solve new problems in your life.

Then repeat the process — ideally, for the rest of your life.

And that, my friend, is how you get paid to improve your life.

That's all for today.

Thank you for reading and enjoy the rest of your day.

- Hussain

**P.S.**

Inside The Profitable Micro Entrepreneur I show you how to attract an audience, build a solution, and sell your solution to people (without being sleazy).

I just opened 5 spots.

If you're interested in joining, [take a read here](https://docs.google.com/document/d/1IoghOCCFlb4OelWZ7Atov3zCbr9hJLkUHwJyhGRCcmg/edit?usp=sharing).


---

<!-- Archivo original: posts/2025-08-11-my-idea-generation-system-that-gained.md -->

---
titulo: "My Idea Generation System That Gained Me 72 Million Views"
subtitulo: "A 15-minute daily habit that will change your content creation system"
fecha: 2025-08-11T14:13:48.305Z
url: https://hussainibarra.substack.com/p/my-idea-generation-system-that-gained
audiencia: gratis
palabras: 1849
likes: 23
comentarios: 7
---

# My Idea Generation System That Gained Me 72 Million Views

_A 15-minute daily habit that will change your content creation system_

When I was in 3rd grade, my art teacher made fun of my drawing in front of the whole class.

That was enough for me to avoid any creative work for the next 15 years.

I even gave up my dream of becoming an architect. I told myself I wasn't built for it.

But 2.5 years ago, I started writing online.

At first it was hard.

I would struggle to put two sentences together.

However now I can write 3,000+ word newsletters with relative ease.

Here's what I've learned from my journey:

Creativity isn't a switch that you flip on and off. It's more like a faucet. If you haven't used it in a while, you'll need to let it run to let all the stagnant water run out for cleaner water to come through.

But here's what changed everything for me:

I realized that idea generation is applied creativity. It's not about waiting for inspiration - it's about training your mind to hunt for connections others miss, to see old wisdom through new eyes, and to turn familiar concepts into new concepts that capture attention.

And as I became more creative, formed unique perspectives on life, this helped me build an audience and monetize my interests.

Now I run a one-person writing business which only takes about 2-4 hours of writing a day.

So today, I'd like to show you how I:

- Implement my ideas in my day-to-day life (to help me expand my conscious mind and perception of life).
- Find and capture time-tested ideas that fuel my content (and how it helped me gain 72 million views on Twitter in the last 12 months).
- Turn old ideas into unique concepts and build a fan base while doing so.

The best part is you don't need to be a gifted genius or artist to see results.

If I could do it, you can too.

Let's dive in.

## **Start With Intention**

Humans are goal-striving machines.

Our goals shape our perception. Our perception dictates what we pay attention to, what is important, and what is not.

Your perception dictates what kind of life you'll live.

For most, their perception is mindless.

They've been conditioned by society on what to do. They are machines with the goal of going to college, getting a job, and retiring at 65. They only register information that is aligned with themselves and their goals.

That means 99% of the information they receive goes unnoticed because it doesn't align with them.

If you want to experience the beauty of life and everything it has to offer beyond the surface-level lens:

- Become brutally aware of your current conditioning and what kind of life it's leading you towards
- Find out what you want by setting yourself meaningful goals for your future
- Develop agency in your life by taking on full responsibility for your income, situation, future, and life.
- Notice how you start to perceive your thoughts, yourself, and life differently and how your decisions begin to align with your goals.

Through this new lens you have, you can begin to find ideas you can write about.

Because without intention, everything you consume will be meaningless and you won't be able to direct the energy towards a meaningful goal.

I want you to consume this letter with intention.

When you finish this letter, write a summary of what you read, the ideas that you got, and how they can be implemented in your life, brand, and content.

## **Find An Idea**

Our ancestors went to wars to gain glory and become memorable and cement themselves in history.

But we don't live in that world anymore.

You don't need to go on 15-year-long campaigns to gain glory and become a legend in history.

We as a species have transcended.

Great and memorable humans cement themselves with the impact of their ideas.

Books live for hundreds and thousands of years.

In modern society, you can publish your ideas on the internet and have them live there forever.

If you want to leave a mark in this world, the way to do it is through writing about meaningful ideas.

To gain these ideas, you need to explore the unknown.

- Read books that interest you.
- Read books that challenge your pre-existing beliefs.
- Read books that you've been wanting to read and have saved in your "books to read" list.

Read philosophy and spirituality to see how great thinkers used to see the world.

Books allow you to explore the world through someone else's lens.

Books allow you to view the situation in a new light.

Books are a goldmine for big, powerful, and time-tested ideas that can change the way you think. By changing the way you think, you change your perception. Like I said before, your perception determines the kind of life you'll live.

I was never a fan of books. But for the past 6 weeks, I've been reading 30 minutes a day as soon as I woke.

I never thought I would be reading about spirituality and take it seriously. It always seemed to be woo-woo for me.

But lately, I've been reading Awareness by Anthony De Mello and Psycho-Cybernetics by Maxwell Waltz and the ideas I gained are incredible.

These two books have been fueling my writing for the past 3 weeks (and will fuel it for 3 more weeks).

Find a book that piques your interest. Start reading it. If it doesn't grab your attention, skip a few chapters or drop it for another book.

Repeat this process until you find an idea that jumps out at you

## **Dissect Your Idea**

You forget all the time.

We all do.

I can't tell you how many times I told myself, “I'll remember this idea when I sit down to write,” but forget what it was.

This is when I realized ideas are fragile.

When you get an idea, act on it. Write it down in a place that you won't forget it — a notebook or a notes app on your phone.

The second step is to stop reading.

Like I said, ideas are fragile. You can lose your idea within seconds.

You don't read a book to understand every word that's in it. You read a book to find that lightbulb moment that turns your life upside down and apply it to your life.

When you find that idea:

- See how your idea relates to your life in more ways than just one?
- Understand the utility that comes from your idea: How does it help you improve physically, mentally, financially, and spiritually?
- Seek to know how it fits with your other ideas and if you can create a unique concept from it.

If you don't have an idea development system, [you can try my note-taking system here in the form of a 15-minute course.](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go)

The most important part is this:

> **Most people don't need more advice. They don't need more information. They need a new perspective of viewing their situation.**

I mostly write about one-person business, writing, creative work, and the creator economy, at first glance, you'd think spirituality has nothing to do with business.

But when you look closely, you realize that spirituality is all about understanding the part you play in the Universe. Then all I did was figure out a way to tie both, one-person business and spirituality together — that's how I wrote [my last newsletter.](https://hussainibarra.substack.com/p/the-5-stages-of-wealth-creation-and)

To fully develop your idea, you need to write long-forms.

When you write long-form content (like this letter), you'll realize how incomplete your idea is. You'll be forced to think deeply and contemplate your idea to develop a unique perspective to talk about.

In the beginning, you'll find yourself turning to other writers and thinkers to form your perspective. That's a sign that you're on the right track and that you need to think deeper about your idea and view it from different perspectives. The more perspectives you explore, the easier it becomes to form your own.

The reason why most people never develop their ideas and are suffering from shallow surface-level ideas is because they're stuck in tutorial hell.

They never try to think for themselves. They always need to be told what to do.

For great, novel ideas to emerge, you need to contemplate them, test them against reality and see how they hold up.

Apply the ideas and concepts that jump out at you when reading a book to your life and see how it you.

Become the mad scientist who is constantly running experiments and seeing how they affect your life.

## **Become intellectually Jacked**

Creativity is a muscle.

The more you use it, the better you become at it.

If you don't create an outlet for your ideas, if you don't write about your ideas, you become mentally obese. There's no point in hoarding ideas.

Consuming content without creating is mental masturbation.

Consuming information itself is passive. Experiencing information is active. Apply what you consume to your life. Write about the ideas you get and the experiences you have with them. When you experience your ideas, your nervous system and midbrain are activated. New neural pathways are created, signaling your brain that you're on the right track and to do more of it.

- Deconstruct the content you're consuming into notes.
- Use your notes as building blocks for your writing.
- Reconstruct them through original writing. Deconstruct your writing into new ideas.
- Repeat the process and expand your mental capacity and perspective.

This is how I write my content.

I read a book for the first 30 minutes of my day. This fuels me with ideas that I can write for my newsletter. As I write my newsletter, I get ideas that get turned into tweets. From my tweets, newsletter, and the book I'm reading, I get inspiration to write a Twitter thread.

This thread later serves as a foundation for new tweets, Substack notes, newsletters, or threads to write about.

And the cycle repeats itself.

The point is your content doesn't need to be around the same topic, but they all have the same underlying message.

One post can talk about one-person business, the other can be about productivity, but both of them have the same underlying message — becoming a high-agency individual.

Read about topics you normally wouldn't read.

Expand your perspective.

Think big picture.

Think in abstract forms.

This allows room for ideas to emerge.

This is how you gain new perspectives and find topics you can write about.

That's all for today.

Thank you for reading and enjoy the rest of your weekend.

-Hussain

P.S.

If you'd like to try my note-taking system to help you find ideas and turn them into content ideas.

This is the system that I've been using for the past 9 months and helped me grow my writing business.

[You can get it here.](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go)


---

<!-- Archivo original: posts/2025-08-20-society-programmed-you-to-fail.md -->

---
titulo: "Being Average Is The Fastest Way To Being Miserable In Your Life"
subtitulo: "A 12-month plan to change your life"
fecha: 2025-08-20T21:15:30.880Z
url: https://hussainibarra.substack.com/p/society-programmed-you-to-fail
audiencia: gratis
palabras: 2858
likes: 12
comentarios: 3
---

# Being Average Is The Fastest Way To Being Miserable In Your Life

_A 12-month plan to change your life_

Being average is a death sentence.

Society tries its best to make you average.

Their goal is to turn you into a product so they can benefit from your labor.

Go to school. Get a job. Climb an imaginary corporate ladder for 45+ years. Work your butt off for a month just so you can get a salary that barely pays your bills.

Just look at the masses.

Everyone is the same. Same level of education. Same degrees. Same jobs. Same habits. Same mindless thoughts. Same goals. Same routines. Same miserable life.

It's boring, lifeless, and leads you down a path of resentment (because you know you could be doing better).

Admit it. You're not like other people.

You have wild dreams, goals, and aspirations you want to achieve. And trying to fit in society just makes it harder for you to achieve them.

> _**The more you try to fit in, the more you feel like an outsider, watching the ‘normal people’ as they go about their automatic existences.**_
> _**-Timothy Leary**_

Back in my engineering job, I was fortunate to work with ultra-successful and wealthy individuals.

I worked on $100M development projects.

_(My boss's boss is the wealthiest man in Dubai)._

Because of my unique situation, I got to see how the ultra-wealthy and successful individuals worked.

And there were many people just like me, normal, just graduated college with no idea how the ultra-successful think, who got the same access to the same people.

But I noticed the mindset differences between "average" people and the ultra-successful.

## **People's Mindset is What Keeps Them Stuck in Their Lives**

I'll get a lot of hate for saying this, especially from boomers…

But I never believed in the idea of working 45 years and saving a little bit of my income each month, putting it in a 401K or a retirement account.

To me, it sounds stupid.

People's definition of "securing your future" is putting their future in the hands of a stranger who doesn't even know that they exist.

It's flat-out dumb.

Just last week, I was speaking with my family about this.

It never made sense, having a retirement account and then worrying about it day and night (because any economic collapse will wipe out the money that I had saved for it).

A much better approach is if you could create your own business or have an investment portfolio that will pay you more money than a retirement account every will and is under your control and you can start to benefit from it before I turn 65.

### **Average People Don't Want To Take Responsibility Of Their Lives**

The average person doesn't want to take responsibility of their lives.

They always want to outsource it.

They're happy to break their backs building someone else's dreams for 8 hours a day but aren't willing to set aside 1 hour a day to work on their dreams.

They put their future in the hands of a complete stranger. They want to have all the upside — status, money, assurances that the future will be ok — but not the downside that comes _with _chasing the upside.

### **The "Safe Path" is No Longer Safe**

Average people think that having a job is safer than entrepreneurship.

But it's not.

10 years ago, software engineering was your ticket to a secure future. Fresh graduates were paid $200k+ per year. Then COVID hit and[over 400,000 employees in tech lost their jobs in 2 years](https://www.elliottscotthr.com/hr-insights/hr-insights-and-trends/the-fallout-of-the-tech-sector-hiring-spree/).

Microsoft, earlier this year announced they'd lay off[9,000 more employees.](https://procurementmag.com/news/what-9-000-microsoft-redundancies-say-about-the-tech-sector)

These layoffs reveal a deeper truth: the 'safe' path isn't actually safe.

With AI becoming more popular, even "guaranteed" career paths are disappearing.

The "traditional path" sells you the illusion of safety but puts you at more risk than you'd ever imagine.

You get paid a monthly salary but then you're worried about inflation, making rent, paying debts, buying food, and a million other things that are on your mind.

Entrepreneurship isn't any more dangerous than having a job. But it has upsides that a job can't give you.

Nobody can fire you. You're no longer restricted to a 5% raise every 2 years. You have the ability to earn as much as you want. You get to work on what you want. You get to change how work is being done.

The internet is filled with case studies.

- Students who filmed their university life and gained one million followers.
- Economics professors who went on YouTube and shared their knowledge around money and the current economic situation has now quit their jobs and pursued content creation because it pays him more.
- A doctor who shared his productivity habits on YouTube has now built a $5M/year business.
- Average people working a 9-5 who managed to build a business on the side that later allowed them to live a comfortable life.

Countless others have found success too. It's no longer a case of being an exception, it's a reality that anyone can achieve.

And by no means am I saying that you need to quit your job to start a business.

In fact, if you quit your job before starting a business and seeing any substantial results, then you're going in blindly and setting yourself up to fail.

But what I am saying is you need to be aware of the risk you're putting yourself in by not having something you have complete ownership over.

If normal people found success on social media, why can't you?

## **How To Break Free & Take Back Control Over Your Life**

Everyone is striving for the same goal in life: _more life_.

More life has many definitions: happiness, success, wealth, creativity, relationships, peace of mind, or whatever concept you have of what ultimate good is.

When you experience that emotions — ultimate good — that's when you feel _more life_.

You experience _more life _when you have autonomy over what you do.

Autonomy is being free from anyone's mental programming.

What I am about to give you are general frameworks for you to follow and self-experiment with.

I cannot give you specific techniques or methods to use to become more autonomous, because if I do, that means you're being programmed.

So the specifics and details are up to you to figure out and see how it fits in your life.

### **1) Wake Up**

If you don't know what you want, society will tell you what to want.

The best way to know what you want is by figuring out what you don't want.

- Grab a notebook
- Write down exactly what you don't want in your life — be specific
- Write down exactly what your life will be like if you never change your current habits
- Then do all that's in your power to avoid turning your hell into reality

This will help prime your mind to notice all the mistakes and unconscious actions that you were doing.

If you don't know what you don't want, just observe society and how most people are asleep and miserable with their lives.

### **2) Give The Middle Finger To Society**

Every successful person I met pretends like rules don't exist. Whenever they saw one, they'd give it the middle finger.

They know if they want to change an industry, you don't do it by following rules.

Rules are set by gatekeepers who want to keep you stuck in life.

Average people see rules as something that's fixed. So every time they try to change their lives, they see a rule that tells them "you can't do that" they stop and say "I tried".

But you haven’t tried.

Because if you have tried, you’ll realize that you can bend reality to your will if you're willing to work for it.

This is one reason why I love the internet and AI so much.

They are the biggest middle fingers to society.

Rules are being broken every day. Industries are being reshaped as we speak — vibe coders are building million-dollar apps without knowing how to write a single line of code. The vibe coding industry became a $20 billion industry.

Business models have changed.

20 years ago, you couldn't run a company by yourself. But now with no-code tools and AI, you can run a multi-six-figure company by yourself.

You can monetize your interests, ideas, and skills and sell them to the masses.

You are no longer chained to society's norms.

Go on the internet, write about your ideas, talk about your skills and benefits, attract an audience, build something meaningful for people without having a boss to tell you to do so, build systems, automations, and products using AI to help you do the work with 1/10th the effort and manpower.

In today's world, you can have the output of 100 employees with nothing but AI, no-code tools, a keyboard, and your ideas.

### **3) Direct Negative Emotions Towards A Meaningful Goal**

Most people try to suppress their negative emotions like they're something bad.

But they fail to recognize that negative emotions are raw energy, when channeled towards a meaningful goal they can be the missing key you always needed to break through.

Looking back at my life, I made the most progress in the gym, running, and writing when I was completely fed up with the lack of results and being frustrated with where I was.

### **4) You Are Where You Are Because Of The Choices You Made**

For a long time I blamed my lack of success in writing on the algorithm for "not favoring me" and other people for "not seeing the value of my writing".

But the truth is, my writing was horrible. I was blindsided by my ego. Facing reality was too painful. So I kept lying to myself and saying that the reason my friends were finding success was because they were cheating or had gotten lucky.

It's only when I took responsibility of the lack of results I was seeing did I wake up.

I put my head down, studied great posts day and night for a month straight, and when it came to putting everything into action, I started taking off.

Now I have an audience of 23,000 followers.

[![](https://substackcdn.com/image/fetch/$s_!Y8gl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb6dd2e9b-d1dd-4df0-a505-30e792150299_1071x605.png)](https://substackcdn.com/image/fetch/$s_!Y8gl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb6dd2e9b-d1dd-4df0-a505-30e792150299_1071x605.png)

Drop the victim mindset. Take responsibility for your life. Realize that society won't give you what you want. Take matters into your own hands. Everything that's wrong in the world, take responsibility for it.

By taking accountability of the problems gives you the power to fix it.

Because if it were someone else's problem, then you have no control or power over it. There's nothing you can do about it.

Take accountability. The Universe always rewards those who take accountability.

### **5) Develop An Unreal Sense Of Urgency**

Back in March, I took a gamble.

I spent my last $3,000 on an 8-week group coaching program.

And for the next 8 weeks, I woke up every day and made sure that I did all the work and more.

Every day I was under massive pressure to perform.

Because of this unreal sense of urgency, I made $4,000 in my first 3 weeks.

This helped me realize that most people underestimate how much progress they can make if they just focus.

Now, I turned my 5-year goals into my 6-month goals.

The point is this:

Stop saying "I'm taking things slow because I don't want to burn out".

The reason you burn out is because (1) you hate the work you're doing, (2) you aren't seeing the results that you're hoping for.

Stop saying "I'll take action after I settle in my new job" or "I'll do it when I'm less busy".

You'll never settle in your new job.

There will always be deadlines to meet, quarters to achieve, projects to finish.

The best time to start is today. Set unrealistic goals and be unbelievably fast with how fast you achieve them.

Success favors speed.

### **6) Be Delusionally Optimistic**

My first 16 months of writing online were hell.

I had less than 1,000 followers and couldn't sign clients consistently.

95% of the people I met back in 2023 had stopped writing 3 months later.

Anyone in their right mind would've realized that there's no point in writing and would've stopped.

But I kept writing.

I was delusionally optimistic that I would succeed. I genuinely think most people saw me as crazy.

I didn't have any proof that I'll make it. If anything, all the signs pointed out that I'd fail.

But I had this deep feeling inside that I can't explain but it told me that I was going to succeed.

And one month later, in October 2024, I had my first post that went viral. Gained 6.6 million views and 2,000 followers overnight.

And since then, I've gone on to gain over 72 million views, and built a business around writing making $5,000 a month.

I've also helped my clients do the same thing.

The point is this:

If you have crazy, wild dreams that no one else dares to dream as big as you, you'll need to be delusionally optimistic. Because no one has done it.

Society will tell you to be "realistic" with your goals but every "realistic" person I met was unbelievably boring, miserable, fat, and unsuccessful.

Give the middle finger to society.

Set unrealistic dreams.

Be delusionally optimistic

### **7) Figure Things Out As You Go**

One thing I learned after 2 years of writing online and working with 4 different 7-figure entrepreneurs is that nobody has anything figured out.

Everyone is lost.

I am figuring things out as I write this. I have a general plan of what I wanna do and achieve, but I don't have a detailed plan down to the smallest actions I need to take.

The key is you need to develop the skill of figuring it out and solving your problems on the spot.

Because no matter how good you plan, things will never go the way you want them to.

So there's no point in spending 6 months planning your next 5 years and after the first step you take you have to adjust your plan.

> _**Everyone has a plan until they get punched in the face.**_
> _**-Mike Tyson**_

### **8) Chase Impact, Not Money**

Almost every high-agency and wealthy individual I met wasn't motivated by money. They're motivated by impact.

Like I said, my boss' boss is the wealthiest man in Dubai. He's also my second cousin. And I got to see how he acts, behaves, and thinks — he's motivated by impact, not money.

Elon Musk is the same as well.

When you observe ultra-successful and wealthy individuals, you'll notice they're motivated by impact, not money.

Which is exactly why my goal with my writing business isn't _just _to make money. The goal of my writing is to help you realize that you are capable of more. More life. You can achieve more.

You see, when I first started writing online, I couldn't make any money. I lacked the skills to attract people and to monetize but more than that, I lacked the vision for people to follow. I didn't have something to guide people towards. So I was stuck in beginner's hell for over 16 months.

But when I started chasing impact and wanting to change people's live and by extension the entire human civilization, I started growing faster, I made more money, and I can see how my thoughts, ideas, and writing is changing people's lives.

Every week I get emails from my readers telling me how I've helped them change their lives.

This is when I realized this important lesson:

> **The money you make is a byproduct of how much impact you have on society.**

And there's no better way to make an impact than to write on social media.

You have access to ~5.8 billion people. The impact and reach the average person now has is unbelievable.

And if you have a radical belief and vision and believe that everyone should do it and you have the skills of grabbing people's attention, and being articulate enough to care about your vision, and to take action, then you'll make more money than you could ever imagine.

That's all for today.

Thank you for reading and enjoy the rest of your day.

-Hussain

**P.S.**

If you're on social media and want to build an audience around your ideas, interests, and passion and want to get paid while doing so…

I am opening 7 spots for my exclusive group coaching program for September.

In there, I'll help you add 10,000 followers, 1,000 email subscribers, and $3,000/month to your brand in the next 12 weeks or less.

To get early access and before prices are increased (at the start of September)…

Reply with "agency" and I'll send you the full offer.


---

<!-- Archivo original: posts/2025-08-24-how-to-become-your-own-monopoly-using.md -->

---
titulo: "Being \"Unemployable\" Is The Fastest Way To Build Wealth"
subtitulo: "Turn your passions into a profitable business"
fecha: 2025-08-24T20:13:59.754Z
url: https://hussainibarra.substack.com/p/how-to-become-your-own-monopoly-using
audiencia: gratis
palabras: 3005
likes: 28
comentarios: 4
---

# Being "Unemployable" Is The Fastest Way To Build Wealth

_Turn your passions into a profitable business_

I was a shitty employee.

I’d go on long breaks. Submit my work last minute. If someone asks me to do something for them, I'll act like I don't know what I'm doing and ask them so many questions to the point where they'll do it themselves.

Because once I realized that I everyone around me was miserable and mindless and didn't want to think for themselves, I knew that having a job won't allow me to live the kind of life I want.

My colleagues would do tasks in an inefficient way, make things harder for no reason, and when I showed them a way of doing something easier and faster, they didn't want to do it.

Their reason?

"This is how we always did things".

So then I spent all my time figuring out how to cheat the system so I could skip out on work.

And oh boy, did I find a method.

I would take a stack of papers and put them on my desk, the first paper would have all kind of sketches about work, buzzwords, and whenever I got up from my desk, I'd take a couple of papers and walk around the floor really fast and always look pissed.

Because once I learned how to cheat the system, it didn't make sense to work so hard.

My promotions are fixed. My salary won’t go up by much. And when they do want to give me a higher pay, they’ll add more responsibility to my plate and make me work more to make someone else rich.

So it was smarter for me to “be lazy” at work and spend all my time in the office going through a course I bought and reading a book that was slowly programming my mind to perceive new opportunities.

After just a couple of months of doing this and building a new perspective from which I can view the world and started to notice how the world of doing business is changing…

---

_Before we dive in…_

_Fonder tickets for the Creator Economy Convention are live now._

_Speakers like Dan Koe, Kieran Drew, Taylin Simmonds, and Hussain Ibarra are gonna be there._

_So if you want to network, future-proof yourself, and learn the skills to turn your passion into profit…_

_[Save $200.](https://thelivinginternet.com/)_

_40 tickets are available._

---

## **The Business Model for Creating Your Own Monopoly**

> _**The internet enables 8 billion monopolies. — Naval Ravikant**_

I always wanted to have my own business.

At 16, I taught myself data science, hoping I could freelance and work as a consultant for major tech companies.

But after learning data science and knowing how hard it was, I quit.

At 19, I wanted to start a social media marketing agency.

I took a course that was ~100 hours long and had everything covered. From finding clients, to drafting legal contracts, to funnels, to hiring and managing employees. But I hated doing outreach and hated the idea of having to manage 10 different employees.

I love my freedom too much to build myself a golden prison.

At 20, I tried to learn SEO but then gave up because it seemed like a lot of tedious work.

At 21, I discovered a new business model. One that didn't require you to do cold outreach, sales calls, or manage a team of employees. That model was the one-person business model.

It was a wake-up call for me. It's the perfect model. You turn yourself into a brand. You don't need to be an expert or have major accomplishments. All you needed was an idea you believe in and the drive to make it real. The only way for this business to fail is if you stop trying to improve your life.

Humans are meant to be creative.

Every human invention, agriculture, plow, steam engine, internet, and AI all have the same fundamental goal: To move humanity out of manual labor and do more creative tasks.

When you're in creative flow, time moves differently, work feels effortless, ideas start to connect, and the lines between your personal, professional, and romantic life all become a blur. When you create, you experience and perceive information differently. Your nervous system and midbrain are activated. New neural pathways are created, signaling your brain that you're on the right track and to do more of it. When you're in creative flow, that's when you're happiest, most driven, and ambitious.

Through consciousness, attention, and focus, you have the ability to think, create, build, and make.

Isn't this mind-blowing?

You can form a mental image in your head, a vision, and with the right skills, tools, and AI, you can bring your vision into reality. You get to bring immaterial and abstract ideas into the world either in the physical world or the digital world (internet).

Anyone who understands that consciousness is the same for all humans understands that solving local problems (your problems) is the same as solving global problems (problems other people have). Because problems are systematic, not personal. That means everyone has the same fundamental problems (just with a different front), so anyone can identify a problem in their lives, solve it, and by extension, you now have a product or service that you can offer to people in exchange for money, status, food, or whatever you want.

The problem?

People are holding themselves back from creating the life they want because of limiting beliefs, social programming, and a lack of self-belief.

We've been conditioned by society to always rely on other people. To never take matters into our own hands. We were graded based on our performance and obedience in school. We followed our parents because "your parents are always right," so we adopted their beliefs, mindset, and worldview without any questions.

The solution?

Agency, self-independence, self-reliance, personal accountability, self-education, self-interest, self-awareness, a set of values, beliefs, goals, and priorities that you can work towards, learn lessons from, and pass your experiences to others (and help humanity advance as a species).

That's what my entire brand, The Profitable Micro Business, is all about.

**Your brand (which is how people perceive you)** is the vision you're trying to bring into reality. The vision encompasses a lifestyle, identity, and practices that your reader can adopt. It is the big goal and reason why people follow you. Your brand is your worldview of reality. What vision are you leading people towards?

**Your content (the way people are exposed to your ideas and brand)** is created from the problems, benefits, limiting beliefs, lessons, insights, interests, skills you're learning, and stories that you experienced in your life while you're trying to bring your vision into life. Your goal is to educate, entertain and inspire people to start pursuing and achieving the vision. People follow leaders.

**Your offer (getting paid for improving your life in exchange for giving value)** is your unique experiences packaged in a repeatable system that solves people's problems and gives them the tools needed to bring the vision into reality. Your offer can be in the form of a service, consulting, or a digital product where your readers can do it themselves.

You are the business, the ideal customer, and the product at the same time.

When you turn yourself into a business, no one can compete with you. Because no one has the same exact experiences, upbringing, perspective, skills, ideas, and beliefs as you do.

Your goal as a creator is to expose yourself to ideas, beliefs and learn from every domain of life so that you don't become one-dimensional in life.

By sharing your experiences and system with your followers, you help them accelerate their learning which solves their problems and by extension, you're helping the human race advance as a specie.

I like to believe that social media was created for this goal — advancing human civilization. It connected us together, decentralized education and gave everyone the chance to go on social, build an audience, create amazing products, market them, and make a profit.

## **How To Start A Micro Business**

> _**Today, you can start a one-person company that will be more than $1 billion. — Sam Altman**_

Everyone is an entrepreneur.

If you solved a problem in your life before, you are more than qualified to start a business.

Most people are sitting on a goldmine of experiences, information, and skills but they don't fail to recognize the value in their years they have been alive thus far.

With AI, no-code tools, and social media, anyone can now start posting valuable content online, attract people to their brand, and turn a small percentage of them into paying customers.

So here's what you need to do to start a profitable micro business.

_The next part is very actionable. Get a pen and a notebook and do the exercises. It'll be worth it._

### **Turn your life into a brand**

Like I said before, your goal is to lead people towards a vision.

Think big picture here.

Where are you leading people towards? What is the set of values, beliefs, and ideas do people need to adopt to achieve their vision?

More importantly, what are _your _beliefs, worldviews, values, and goals you want to achieve in your life?

This will give you (and your readers) a goal to always chase after. And to achieve any goal, you need a set of practices to do every day.

If a guy is trying to put on muscle, he won't do it by sitting in his room all day and eating junk food. He'll need to go to the gym, lift weights, eat proper nutrition, and, with time, progressively increase the challenge. The same thing applies to your brand. No one achieves their goal by accident. There is a set of practices that you need to do every day to bring your vision into reality.

Now, the next part you need to answer is:

Why are you doing it? Why are you trying to bring your vision into life?

This will help you understand the benefits (and by contrast, the problems people have) of achieving your goal.

Now you have a goal, a set of practices for people to apply in their lives, and why they should do it. All that is left to do is talk about any idea that helps you and your reader to reach your goal.

This is your entire brand mapped out in a single piece of paper.

If my ultimate goal is to be calm and at peace with myself because I know being in survival mode just leads to burnout, anxiety, chronic health problems, and how it impacts every aspect of my life, from my personal, professional, and romantic life. Then I need a practice that I can do daily to become calm and at self-peace, this can be done through meditation, journaling, yoga, etc.

That is your entire brand.

Looks simple, right?

Because it is. The problem is most people are too caught up with the technicality of business that they miss the fundamentals.

**You have a vision: **Getting out of survival mode and healing yourself.

**You have a mechanism and a practice that people can adopt:** Journaling

**You have your audience:** People who struggle are burnt out, anxious, depressed, have chronic health problems, and anyone who is stuck in survival mode

**The benefit:** You feel calm, happy, at peace with yourself, you no longer feel the need to always please others, you take care of yourself, and it takes less than 5 minutes to do. etc.

You don't need to have your entire brand figured out right now. I still do this brand exercise every 2-3 months for myself. Because the longer I write, my ideas change, my beliefs change, and my worldviews change, and so by extension, my brand changes.

Your vision will become clearer as you keep writing about it and walking down that path.

### **Build Your Most Profitable Asset**

_"Nobody checks their emails anymore."_

That's what everybody who doesn't understand how powerful emails are says.

I have a small email list of 2,300 readers and in the past 6 months, it made me $24,000+.

I didn't do sales calls. I didn't.

So no, email isn't dead. If anything, email is even more in demand because of AI-generated content. Your readers are craving the human element. Newsletters are a lot more personal and intimate. You get to talk about your stories, ideas you enjoy, and share a lesson that helps other people. You aren't fighting against an algorithm.

Because of the For You Page, your social media following doesn't matter as much anymore. You are constantly shown new creators that you never followed or even interacted with.

Build your email list, go deep with your ideas. Writing long-form newsletters will expose you to the blind spots you had. You'll notice the gaps that are in your vision. You'll notice how a lot of your beliefs weren't actually yours to begin with and that you'll need to let go of self-limiting beliefs.

Newsletters will challenge you to expand on your idea, add depth to it, and create a persuasive argument of why people should believe in your vision.

Newsletters are the key to building trust, authority, and getting customers for your brand without having to spend hundreds of hours doing cold outreach or sales calls.

But to build your newsletter, you need to funnel people to it.

### **The #1 skill you need to learn to make it all work**

The problem most people make is they don't know how to grow their newsletters.

They write weekly and sometimes daily newsletters but they only have 13 readers and then wonder why no one is buying from them.

You don't have an offer problem. You have a traffic problem.

The problem with newsletters is they don't have a built-in growth mechanism. So if you don't know how to grow your newsletter, you'll be a starving artist. You won't monetize your passions, you won't get paid doing what you love, and you'll have a lot of spin but no results (no sales, no growth, no audience).

So if you want to build a profitable one-person business, you need to know the most powerful and fundamental skill: **capturing attention.**

And to capture attention, you need to go where attention flows, social media. More than 5.56 billion people are on social media, to think that you're "above" social media is stupid.

How did you discover your favorite creator? Through social media.

How did you discover your favorite podcast? Through social media.

How did you discover your favorite writer? Probably seeing someone recommend a book on social media.

Social media is where people can discover your brand.

The problem is most people just want to write about their "deep thoughts" without understanding what makes people want to read their content. They are so blindsided by the fairytale they're living that they don't understand that nobody wants to see, read, or share their content. Then they start to get mad at the world and say, "people don't see the value in me", "to get attention, you need to do silly dances on TikTok", then they quit.

If you want to gain an audience, you need to learn how to play the attention game and play it well.

You need to know how to capture their attention, make it worth their while, and also feel compelled to share your content with their family, friends, or audiences. That is what social media is all about. It's getting people to share your content. And unlike what most people think, you don't need to be controversial to gain attention. You can gain attention _and _be helpful.

**How to capture attention:**

- Find an idea, any idea
- See how your idea relates to your vision
- See how your idea helps someone improve their life
- Talk about

You can make it fancier if you want, but the fundamentals are the same.

This is why I'm a huge fan of taking notes. I almost always take notes whenever I'm reading a book, a newsletter, or even tweets. Ideas are everywhere, you just need to be aware to identify them and capture them.

_If you don't have a note-taking system, [you can give mine a try.](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go)_

Once you have your idea, use basic copywriting frameworks to make your ideas stick.

At this stage, you're still a beginner. You don't need to try to be original. It doesn't matter how "authentic" you think it is to just word-vomit your idea and post about it. It won't do well. The desire of beginners to be so different and original is the reason why they're struggling to find any meaningful success with their writing.

Use PAS, AIDA, and PASTOR. These are the most beginner-friendly frameworks to use (I still use these frameworks for my writing).

As you write on social media, some posts will perform better than others. Those outliers, the ones that do exceptionally well for you, save them in a folder, try to figure out what made them work, what was the idea? The structure? The problem?

Then do more of that. Experiment more. Once you find something that works, keep doing it.

Every day, under your best-performing post, put a call-to-action to your newsletter. People won't join unless you tell them to.

That's all for today.

Thank you for reading and enjoy the rest of your weekend.

-Hussain

**P.S.**

**What problems are you currently struggling with?**

Social media growth?

Email list growth?

Writing newsletters?

Signing clients?

Or something else entirely?

Leave a comment and I’ll get back to you with suggestions.


---

<!-- Archivo original: posts/2025-09-21-i-brainwashed-myself-into-starting.md -->

---
titulo: "I Brainwashed Myself Into Starting A Business With Zero Experience (The Psycho-Cybernetic Method)"
subtitulo: "How to program your mind into becoming successful"
fecha: 2025-09-21T20:46:55.975Z
url: https://hussainibarra.substack.com/p/i-brainwashed-myself-into-starting
audiencia: gratis
palabras: 4408
likes: 33
comentarios: 8
---

# I Brainwashed Myself Into Starting A Business With Zero Experience (The Psycho-Cybernetic Method)

_How to program your mind into becoming successful_

[![](https://substackcdn.com/image/fetch/$s_!n6zh!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b9d010b-c92d-462c-ba97-04e4e1e99b0e_2048x1152.png)](https://substackcdn.com/image/fetch/$s_!n6zh!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b9d010b-c92d-462c-ba97-04e4e1e99b0e_2048x1152.png)

I always saw myself as someone who couldn't be an employee.

I hate taking orders, checking boxes that don't mean anything, and not being able to do what I love.

So when I got a job after graduating, I hated it, even though I was successful in society's definition.

22 years old with a six-figure salary. Fancy office. Working on mega projects in Dubai.

But I dreaded every day I woke up. Up at 5 AM and back home at 11 PM.

I was living a nightmare that never ended.

I just wanted to write about my ideas and build my brand but I was stuck in an office doing work that I didn't care about.

The problem?

I didn’t know how to start a business. I didn’t have another method of _not _being an employee.

So I was forced to stay in my job.

My identity wasn't aligned with reality and it made me feel lost and miserable.

# **The Identity Crisis — Why Most People Feel Lost & Miserable**

Most people don't know who they are.

And reflecting on that problem is too painful (because they're so used to others telling them what to do).

So they choose the easy route: Follow the traditional path and don't think.

Society gives you work (which takes away the pain from having to reflect on the bigger question, who you are and what you want) and rewards you for it by having you achieve the goals they want.

They give you money and status, but they take the most important parts of your life, fulfillment and meaning.

So most people get trapped in the cycle of working their entire lives, climbing the corporate ladder, working on projects, and achieving revenue goals only to realize, when they hit 60, that they never got to do what they want.

They always chased someone else's goal, dreams, aspirations, and so they lived someone else's life. Not theirs.

It's the same as a surrogate mother who carries a child for 9 months only for when she delivers it, gets taken away from her.

Society does the same.

They make you work, give you goals and targets to achieve, and reward you with money, only to then realize that you were chasing the wrong goals and that you never got to live your life.

There's nothing wrong with admitting that you made a mistake. But it is wrong knowing that you made a mistake and you don’t try to fix it.

So when I started studying human behavior, I realized that everyone has the same fundamental goals: meaning, fulfillment, creative work, and to have autonomy to pursue their fundamental goals.

Not money or status. Money and status motivate you to keep you going, they're not the end goal.

Because if you're chasing the wrong goals and you're getting rewarded for it (by gaining status and making money), you'll be building yourself a prison thinking it's freedom.

But if you're working towards your own goals and self-development, you'll be the happiest man alive.

The problem is most people don't know what they want.

They never tried to experiment. They never dared to explore the unknown (because through trial and error is how you fidn what you love or hate).

So most people spend their entire lives doing what others want them to do. This is why they develop an autonomy problem which is the source of their misery.

### **A lack of autonomy is the source of your pain**

Your identity is a collection of your ideas, beliefs, values, experiences, relationships, conversations, and perspectives that you picked up in your life.

Autonomy is the ability to practice your identity.

And when I look at the masses and the problems I see on social media, it all has the same foundational problem: Lack of autonomy.

They don't have the ability to practice their identity because they're too busy adopting society's autonomy that has its own goals, values, thoughts, and lifestyle.

Society gave you money and status, but robbed you of having autonomy. You are no longer the one who's calling the shots. You are working towards society's goals and their goals are driven by self-interests and serve them, not you.

The lack of autonomy is the source of your misery. You are doing work you hate, and you don't find it creatively challenging.

When I was at my 9-5, I spent my entire day thinking about how much I hate my work and how all I wanted to do is write.

I didn't care that I wasn't making money. I love writing so much that I could do it all day. Writing online and building a brand helped me gain back autonomy in my life.

When you have autonomy, you get to create work that you love, find meaning in, and it fills you with energy and excitement.

And when I got a taste of what autonomy feels like, I just couldn't put up with my job.

Because I realized something:

### **Society gives you the freedom to consume, not to create**

In a traditional society, you don't have the freedom to create.

You have the freedom to consume.

They take 5 days and give you 2 (one of which, you spend thinking about how the next day you'll have to go to work).

They take your first 10 hours of your day (which are your most productive hours) and leave you so exhausted from work that you don't have any energy to do what you love.

So the average person goes and spends their evenings scrolling social media, drinking, walking the pet, arguing with their partner, and numbing their minds with whatever cheap dopamine they can get, hoping to forget that they have to do it all over again tomorrow.

That's not living.

That's hell.

That's how the average person lives.

And most people are average.

Everyone is living the same life. The same routine. Doing the same boring tasks. Working the same job they hate. They all have the same ideas, goals, and aspirations. Everyone is a clone of the other person.

This was the thing that sealed the deal for me.

When I quit my job, I knew I had made the right choice because I was finally able to see how most people lived their lives.

They had the same goals, talked about the same meaningless topics.

That's when I realized that when you're speaking to someone, you're not speaking to them. You're speaking to the content they're consuming, the videos they're watching, the people they're listening to.

Most people are consumers. Not creators.

Consumers don't think, they don't act, they don't build, they think education stops after it is no longer mandatory. Consumers like to be told what to do and that's exactly why most people struggle in their lives.

But creators are different.

Creators actively build and improve their lives. They are self-educating themselves every day (because knowledge not found in school is the source of wealth that's not found in employment).

Creators think for themselves and become aware of their thoughts and programming. They set their own goals. They work on projects that bring them fulfillment. Creators optimize for meaning and self-development (because they know that the key to a good life is self-development).

Everyone is born a creator. Everyone has the ability to create their own life and reality.

# **The Art Of Achieving Your Goals — Psycho-Cybernetics**

Humans are goal-striving beings.

We love goals for many reasons.

They give us structure, reduce uncertainty, and provide a sense of control over our lives.

You never have control, but goals give a sense of control which allows you to focus and create meaningful work.

Without goals or a project that you can apply your knowledge to, learning new skills and exploring new topics is mental masturbation. Without goals, you become lost, feel aimless, miserable, and have no idea on what you want to do in life.

If you don't have a goal, you'll be assigned one by society. And the goals they give serve their interests, not yours.

Go to school. Get a job. Chase promotions that don't mean anything to you. Work a job you hate for 40 years. Begin to seek "work-life balance" (which is just another indicator that you are working a job you hate and you need to set goals for yourself to take back control over your life). Retire at 65.

It's meaningless.

It's soulless.

It's hell.

Start asking questions about what you want. Design your ideal life. Create a vision for yourself. Set goals to take back control over your life. Learn skills that will help you actualize your dream life. Become the mad scientist who won't stop until he finds the answer he's looking for.

Goals shape your perspective.

They filter out what's important to you by using dopamine.

Just like when the hunter-gatherer went to hunt for food the other day and noticed that there were berries on a bush. He passed this bush many times before and hasn't noticed it before, but the reason he noticed the berries this time was because his goal was "find food". So his mind was programmed to "scan" for anything that resembles food and when he found the berries, his brain released a chemical called dopamine. Now the next time he goes out to hunt, a little spurt of dopamine is released to remind him to check the bush for berries.

### **Your Built-In Mechanism For Success**

Everyone is built to be successful.

Your success depends on the goals you set.

Your goals and actions are always aligned with the mental image you have of yourself.

Someone who thinks he doesn't deserve to be wealthy will sabotage himself every time (whether he's aware of his beliefs or not) and their mind sees it as a "success".

This happens because humans have a built-in Success Mechanism.

It's similar to how an intercept rocket works.

It has a goal (reach a target). It has an engine or a propulsion system that moves the rocket towards the general direction of the goal. It has a feedback system which brings in information (radar and sensors). The feedback tells the rocket two things: 1) positive feedback and 2) negative feedback.

In positive feedback, the rocket doesn't do anything new; the feedback system tells it to "just keep going, you're doing the right thing".

But in negative feedback, it tells the rocket to correct course, "you're too far right, steer left".

And if it oversteers, the negative feedback kicks in again and keeps correcting the rocket until it zeros in on the path it's supposed to take.

How does this apply to you?

You set a goal, target, or outcome you want to achieve. Your mind subconsciously starts working towards the goal (your propulsion system). You get feedback, which you then compare the feedback to your goal, iterate, adjust, and act again towards the goal.

You get what you want in life through trial and error.

And when your mind recognizes a "success" (through the release of dopamine), your mind will now keep trying to replicate what it did to keep getting the dopamine hit.

This is also how I train my algorithms for my thesis. I give them a "reward" for every time they predict something correctly and a "punishment" when they predict wrong. With time and enough training sets, the algorithms start to find the right answers almost every single time.

This is how everything is created. Medicine, AI, content, business, writing.

It's all done using this approach.

Everything starts with the goal you set for yourself.

Just like how you don't need to be an electrician to open the light, you don't need to be a mechanic to know how to drive a car, you don't need to be a dating coach — but you can still open the lights, drive a car, and find a partner — you don't need to be "successful" to know how you can operate your success mechanism.

This is something we all have.

And the best part is you can use it to get paid to improve your life.

# **How To Brainwash Yourself Into Starting A Business (And Get Paid Doing What You Love)**

[![](https://substackcdn.com/image/fetch/$s_!FAgZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F90d2f9f6-abe6-43a6-8124-7c6965944931_1188x1188.png)](https://substackcdn.com/image/fetch/$s_!FAgZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F90d2f9f6-abe6-43a6-8124-7c6965944931_1188x1188.png)

Every piece of technology mankind has created is towards the same 3 things:

Sovereignty, autonomy, and creative work.

The internet has decentralized education. Bitcoin decentralized the financial system. AI decentralized labor.

The future of work will be filled with micro businesses. Everyone will become self-employed.

Creators, freelancers, and contractors currently dominate the digital world.

And the number of creators and freelancers will only keep increasing.

Just take a look around you. People don't trust companies and traditional media outlets anymore.

With the internet, no-code tools, and AI, you can start a profitable business by yourself. The only thing you need is the self-belief that you have something worthy of sharing.

Once I realized that business IS self-improvement but at scale, I knew that anyone can start a business.

Self-improvement is all about improving your life.

Business is about improving other people's lives by creating value (a solution to problems they have).

So if you solved a problem in your life, you can start a business. You don't need to have a 4-year degree, a marketing team, or do all the marketing jumbo that people tell you to do.

When you turn your life into a business, you start getting paid for doing what you love. You get paid to improve your life.

You don't need to make $1M a year to have a successful business.

Most people would be living comfortably if they made an extra $1,000 or $3,000 a month.

Here's how I brainwashed myself into starting a business:

### **1) Become Aware Of Your Self-Image**

Everyone carries with themselves a mental image of themselves.

It may be vague to our conscious mind. To some, they don't even know that it exists. But it is there.

The metal image is your preconceived notions of "who you are".

It is your identity that has been shaped through your past experiences, losses, wins, beliefs, ideas, and thoughts that you're not conscious of.

Your actions, feelings, behaviors, and abilities are always consistent with your mental image.

That means if you have a mental image that you can never become successful, then it will manifest itself in real life.

Your mental image determines your life and your mind will always look for evidence to support it (even though it's false).

A student who tells himself that he's bad at math, and his report card confirms it (this is how his mind tells him that "he's right").

When I was in school I sucked at math. I was a B student at best. But now I'm an A student doing my post-grad in engineering and math is my best subject.

I also thought I was never good enough to monetize my writing or land clients. But now I am running a writing business that I'm proud of and writing about ideas that excite me.

If you don't change your mental image, your life won't get better.

You need to brainwash yourself into believing that you can become successful. That you can build a great business. That you can earn more money and not have to stress about work all day.

To change your mental image, you need to become aware of 3 things:

- Become aware of society's mental programming (and how they brainwashed you into thinking you can't become successful and how it's affecting your life).
- Realize that your current mental image you have of yourself is false and that you can change, and that people have done it previously.
- An answer already exists in the world, you just haven't found it yet.

### **2) Set A Target**

Goals are conscious programming.

To change your subconscious mind, first, you need to change your conscious mind into thinking that you can change. And by consistent effort and daily action, you can begin to steer your way into programming yourself into a completely different person.

When you work towards a goal, you begin to collect "evidence" that your previous mental image — the one that made you think you were a failure and can't succeed — is false and that the new mental image you're trying to create is real and true.

Setting a goal kicks your Success Mechanism into action.

When you set to do creative work — because humans are meant to be creative and that's what you should be aiming to do because when you're being creative that's when you're happiest, time moves differently, and gain the most fulfillment — you begin with a goal in mind and an end to be achieved, a "target" answer which is vague to you now will be "recognized" when achieved.

This will create a reference point that will tell your Success Mechanism to keep repeating.

Just like when you want to open a door, you don't think about which muscle to contract and to what degree to apply force. You do it automatically.

You did it successfully once before and your mind remembers it, so now you can open doors successfully without having to think about it.

### **3) Change Your Inputs**

The reason why most people are stuck in their lives is because they keep themselves in an environment that allows them to fail.

Once you have a new mental image and a goal, you'll need to change your inputs.

When you change what you feed your mind, your life changes.

Discipline becomes easy. Learning becomes fun. Opportunities begin to fall into your lap because your perception of reality changes.

**1) Change your circle**

Stop talking to friends who keep you stuck in life. If you're afraid to talk about certain topics with your friends because you're worried they'll judge you, then they're not your friends. Show them who you truly are and if they don't like what they see, cut them off.

It's better to deal with the pain today than to live your entire life hiding who you truly are.

**2) Consume new information**

Stop following the news and brain-rot content. Their goal is to numb your mind and make you miserable.

Start following creators and writers who challenge your thoughts, perspectives, beliefs, and ideas, and propel you towards the life that you want.

Listen to podcasts that are informative. Read books that you wouldn't normally read.

Get out of the small bubble that you've been programmed to see life as and expand your knowledge.

**3) Learn new skills**

Learn skills that will help you unlock different levels of life.

The difference between where you are now and where you want to be is skill. Not time, not information, it's skill.

Because if you have a goal, you'll Success Mechanism will start to take over and if you want your journey to be easier, you'll need to have skills that will help you do the tasks necessary to achieve the goal.

Buy courses. Join masterminds. Find mentors. Create a network of people whom you can reach out to for help and who are willing to show you the way.

If you don't know what skill to learn, learn writing.

Writing is thinking. Writing is how you become aware of your thoughts, actions, and behaviors. Writing is how you make sense of yourself and of the world at the same time.

### **4) Take A Lot Of F*cking Notes**

I'm a huge note-taking fan.

I take notes about everything.

Podcasts, newsletters, articles, threads, short-form posts, conversations, books, newspapers, and even shows that I'm watching.

Because notes are how you become conscious and remember big ideas. Ideas that are repeated daily become beliefs. Beliefs practiced become part of your identity.

This is why I love taking notes of ideas that I find valuable because they can change your life.

When you dissect your ideas through a system that challenges you and makes you think about what you're reading, doing, or thinking, it no longer becomes a passive activity — hoadring information — taking notes becomes an active process.

You start to see how it applies to the greater picture of your life that you're trying to achieve. You start to realize how everything in life is interconnected. Spirituality, education, business, self-improvement, finance, psychology, fitness, and science are all connected.

They're not separate domains that we once thought they were.

Taking notes becomes a method that you can use to make sense of the world and understand it on a deeper level.

So later, when you encounter a problem, your mind goes into "scanner" mode and starts to pick information from one note, a fact from another, a series of former experiences that you have to form an approximate answer that you can begin to work towards and will help you achieve your goal.

This is similar as when you're trying to pick up your phone when it's dark in your room. Your hand starts to touch everything that's on your table, "scanning" the object and seeing if it's a "match" to a phone. This mechanism keeps working until your mind finds a "match" (which is your phone).

I've tried many note-taking systems and iterated on them since I was in school. Now I've created a system that helps me not only in my studies but also in my writing.

90% of the success I found with writing was because of the notes I took.

_If you don't have a note-taking system, you can try mine [here](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go)._

My notes became the sources of my ideas and the building blocks of my brand and newsletters.

This newsletter is built around 3 notes called:

- Your self-image, your life
- How to achieve your goals without relying on motivation
- The rise of normal people

Your notes become the foundation of your self-improvement, identity, and by extention, brand.

You can always reflect on your notes (which are your ideas) and write about them.

### **5) Develop Your Perspective Of The World**

[![](https://substackcdn.com/image/fetch/$s_!743C!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2862e85d-01c0-4899-93a7-dafc4ff5f9a3_1188x1188.png)](https://substackcdn.com/image/fetch/$s_!743C!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2862e85d-01c0-4899-93a7-dafc4ff5f9a3_1188x1188.png)

Most people don't need more advice. They need perspective.

They need a new way of seeing a problem.

Most people are sick of hearing the advice of "start a business and build financial freedom".

But not many people have heard about a Micro Business or a Personal Brand.

Not many people know about the creator economy and how you can write about your ideas, interests, and share your experiences and lessons online, build an audience, and monetize.

If you want to get paid for doing what you love, you need to develop a perspective in life. You need depth behind your ideas.

This is why I love writing long-form content.

You go deep with your ideas and problems you're trying to solve.

What I like to do is use my notes as building blocks for my newsletters and when I go to put them together, I use personal stories and experiences.

If you're a beginner, your goal isn't to be unique. Your goal is to take something that is already working and taking it to a new place.

Once you understand that all ideas connect, no matter what niche you are in, you'll be free from the trap of "niching down" and being forced to create "actionable advice" content.

Giving your readers a new perspective of the world is how you stand out from the sea of noise. It is how you become known for something.

People want perspective. Not advice.

Perspective is giving people a new "Aha" moment. A new way of thinking. A new way of seeing the world. They get to see your world.

### **6) Create & Distribute Value in Society**

> _"Money is not wealth. Money is how we transfer wealth."__-Naval Ravikant_

People want wealth. Not money.

Wealth is value (resources, housing, experience, knowledge, ideas, health, relationships, and happiness).

People give you money to get wealth.

So if your goal is to make money, then you won't make money because you're too focused on the wrong things.

Your goal should be to create value.

Value means solving other people's problems and giving people what they want but don't know how to get it themselves (because if they knew how to get it, they'd do it themselves and won't pay you for it).

You create value by helping people improve their lives, which is delivered through content, education, services, and masterminds.

The easiest way to create value is by sharing a solution to a problem you've solved in your life.

Think back in your life and reflect on what problems you have solved. Create a 4-week program and sell it as coaching or tutoring.

_Hint: You already solved problems that other people want to solve themselves but don't know where to start._

You distribute value by sharing your notes, perspectives, lessons, stories, and experiences, and posting on social media (because you need a method to bring people to your brand, and social media is the best, most beginner-friendly, and cheapest way to do it).

[![](https://substackcdn.com/image/fetch/$s_!HMIe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb29ec85a-3f61-446a-b45e-e791fbec9456_1188x1188.png)](https://substackcdn.com/image/fetch/$s_!HMIe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb29ec85a-3f61-446a-b45e-e791fbec9456_1188x1188.png)

This is why I think writing is the best skill you can ever have.

You can create value (by writing courses) and build distribution for your business (having an audience on social), all by writing.

You don't need to show your face, do silly TikTok dances. You are rewarded primarily on the basis of the quality of your ideas, how well you can capture people's attention, and persuade them to take action.

And just because you haven't gotten paid, it doesn't mean what you're doing and creating isn't valuable. It means you need to learn more skills and get better.

The joke of "skill issue" is true.

Everything is a skill issue.

That means you can get anything you want if you're good enough.

It's just a matter of learning, practice, and execution.

That's all for today.

Thank you for reading.

And enjoy the rest of your day.

-Hussain

**P.S.**

If you don't have a note-taking system, you can try my Minimalist Note-Taking System.

It helped me gain 75 million views in 12 months.

It's in the form of a 30-minute course and you'll have templates that you can immediately use for your content.

[Give it a try here.](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go)


---

<!-- Archivo original: posts/2025-09-28-i-ran-1121-miles-and-it-changed-my.md -->

---
titulo: "I Ran 1,121 Miles & It Changed My Life"
subtitulo: "What I learned after running for 1081 days consistently"
fecha: 2025-09-28T21:36:36.409Z
url: https://hussainibarra.substack.com/p/i-ran-1121-miles-and-it-changed-my
audiencia: gratis
palabras: 2186
likes: 11
comentarios: 1
---

# I Ran 1,121 Miles & It Changed My Life

_What I learned after running for 1081 days consistently_

[![](https://substackcdn.com/image/fetch/$s_!h127!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F26ba72a8-8c44-494b-8780-4b040d2d27d0_1080x1440.jpeg)](https://substackcdn.com/image/fetch/$s_!h127!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F26ba72a8-8c44-494b-8780-4b040d2d27d0_1080x1440.jpeg)

__Credit: [@matthewvanthomas](https://www.instagram.com/matthewvanthomas/)__

1 full marathon.

12 half-marathons.

1121 miles.

Those are my stats since I started running 1018 days ago.

At first I hated running.

My legs would feel heavy I’d be out of breath, and I would feel like I was getting stabbed in the stomach and all of this would happen after the first 5 minutes...

But the Runner’s High was so good that I got addicted to running.

Now, a week doesn’t go by and I don’t go for a run.

_(Unless it’s summer and the Dubai heat is getting dangerously high)._

And running has changed my life. Not only did I get learner, put on more muscle, and my body looks better than ever before...

It completely changed my life. It taught me more about myself than any self-improvement book.

So here are some of the life-changing lessons I learned:

### **I lost a race to a 60-year-old**

In my first month of running, I was obsessed with running 5kms.

Every day I’d go out and run at the park that’s right next to my house (it has a 2.36 mile running course).

I was getting confident (and cocky) at that point.

But one day, I saw an old man in front of me running.

In my head I thought he started somewhere in the middle so that’s how he got in front of me and it was only a matter of time before I passed him.

But as time went on, he started pulling away. I pushed harder to catch up, he pushed harder. This kept happening until I was basically sprinting and I ran out of breath (still couldn’t catch him).

I was embarrassed that I couldn’t pass him.

Why did I bring this up?

Because it’s proof that age is just a number. If you’re passionate about something, and you work every day to get better at it, then you can do anything you want — at any age.

But most people think they’re too old to go back to college, to learn a new skill, too old to switch careers or start a business.

But reality is full of case studies that age is just a number and that you can reinvent your life, become successful, become healthy, become wealthy, at any age.

Societal norms are just that, they’re for normies who want to be average.

Average is boring.

Being average in today’s society is a death sentence.

Be daring and do cool sh*t.

I started a business at 21 with no experience.

Most people would think that I’m crazy or dumb for doing so, but now I’ve managed to build a successful writing business.

You are never too old (or too young) to start over.

### **Life is f*cking lonely**

Almost all of my runs are solo runs.

No friends. Never joined a run club.

It was always just me and my thoughts. And I’m not saying this to gain some sympathy, I genuinely enjoy my own company.

But the real reason why I always prefered running solo is because if you start running because it’s “trending” or you saw your friends to do it, then you won’t have a reason to keep going when the trend dies off or when your friends stop.

Here’s the truth:

Life is lonely.

It’s always up to you to get the results you want.

Nobody will run your miles for you. Nobody will do the work for you. No one will carry you to the finish line. They’re too busy with their lives.

When you’re at a race, you’re going to be the one who has to cross the finish line. Not someone else. People can encourage you, shout your name, or even run with you for a bit as a boost of motivation, but eventually, they’ll stop, and it’s up to you to keep motivating yourself to keep going.

And life is very much the same.

You’ll have family and friends who believe in you. They’ll motivate you. But at the end of the day, it’s up to you to figure sh*t out and solve your own problems. Everyone is too busy solving their own problems to come and lend a hand (unless someone is feeling very generous).

In business it’s the same as well.

Your mentor can show you the path you need to take, but the action is entirely on you. You’ll need to do the work, experiment, adjust, refine, and iterate.

Your results are entirely dependent on you.

It’s both scary and liberating.

Scary because you don’t have someone else to blame when things go wrong.

Liberating because you are always the one in control.

### **It’s you vs your inner b*tch**

> You’re a bitch. — David Gogins

When I was in my marathon, I was on pace to finish it in under 4 hours (that was my goal).

But at the 32 km mark, I hit a wall.

My entire body was aching. My ankles hurt. My hips and quads were cramping with every step I took. Sitting was painful. Walking was even worse.

So I only had two options:

1. Quit and call it a day because I “reached my limit”
2. Pushing through the pain and keep running until I can’t take another step

And since I was training for 3 months for this race, I couldn’t let 3 months of hard training and effort go in vain.

So I took the second option.

I stopped paying attention to how long I had left in the race. I just focused on “failing forward” — that’s what life is all about — not looking at how much is left, but focusing on taking the next step.

Because you owe it to yourself to finish what you started. You owe it to your past self who went through all the training, pain, and troubles to get you where you are now. You owe it to your future self who’s confidence relys on what you’re doing now. You also owe it to your current self to see what you’re truly capable of and what the world has in store for you.

Too many people quit early. They don’t realize just how much they’re capable of.

Just as David Goggins says: “Stop letting your inner b*tch win.”

### **Doing the boring work is how you become in the top 1%**

Most people are looking for the silver bullet — the secret to becoming successful overnight.

But that’s exactly the reason why most of them never see an ounce of success.

Truth is, success is boring.

You go in every day, you do the boring tasks day in and day out. You pull the same levers every day.

Success is about mastering the basics that you learned in your first 2 weeks. Then you keep repeating it, Every. Single. Day, until you find success.

There are no secrets. There are no tricks. There are no hacks that will make you an overnight success.

Most people are too caught up with fake internet gurus’ lifestyle of driving lambos, sitting on a beach, travelling to do Dubai, and making money while doing absolutely nothing.

When they think of success, that’s what they think of.

But success is boring. You keep pulling the same levers every day until success finds you.

I only started getting faster at running when I consistently ran at Zone 2. Before that, I was stuck, not getting faster, not improving, and a whole lot of frustration.

My business was the same. I was stuck not seeing any results because I was too caught up in finding tricks.

I thought I was “better than the beginners” and would skip whenever I saw beginner level content, I’d skip it. But as I’ve progressed and seen success with my business, I now realize just how important the basics are.

It doesn’t matter if you know all the latest hacks and tricks. If your foundation is shaky and you don’t nail the basics, you won’t succeed. It’s as simple as that.

Writing online and starting a personal brand is all about marketing, sales, persuasion and writing.. Then every day, you want to go in, practice in public, improve, and knock out your daily tasks, then let compounding do its job.

This isn’t sexy, but it’s the most reliable and effective way to find success.

### **Running is the best form of self-improvement & meditation there is**

What keeps me hooked on running is the self-reflection and realizations you get while on a run.

It’s just you and your thoughts.

In today’s society, we’re all chronically online.

Social media hijacked our attention. We’re constantly stimulating our minds with new information and not giving it time to process everything.

We go about our days on autopilot, not thinking, not living the present moment. A year goes by in the blink of an eye. It’s a sad reality.

This is why I love running so much, you get to reflect on your life, the information you’ve consumed and what you want to do in the future.

Running is how you get to compress time. You gain 10 years of experience in 2 hours. While on a long run, that’s when you’ll learn about yourself the most.

I got over my self-limiting belief of “money is evil” and “sales and marketing are evil” while on a run. I realize now that if what you’re selling genuinely helps someone, then what you’re doing is an act of kindess and refusing to get better at sales, marketing, and persuasion is you allowing evil to win (because now you’re letting greedy and evil corporations win).

I got better at conversation because I was able to think deeply about my ideas, how to articulate them, play old conversations in my head and spot my mistakes. I got to analyze the people I know and see what makes them “tick”. Now, almost every single person I meet had told me “You’re very easy to talk to”.

And I attribute all of this to running.

Now, I block out 3 hours out of my day to just train (lifting weights + running).

- It serves as a mental reset.
- It fuels me with ideas.
- It calms me down.

### **The more you run, the more money you make**

Your best ideas come when you’re away from the screen.

I got the idea to write this letter when I was on a run.

Almost all of the lessons you read here I got while on that run.

All of my best ideas came while I was on a run.

Running is where my mind wanders. We’re so caught up with technology that we don’t make space for our ideas to emerge.

We drown ourselves with content that we don’t get time to process everything.

But as a writer, you’re not valued by how many hours you put in. Your value comes from the quality of your ideas and how impactful they are.

So running is how I disconnect from the world. Let my mind calm down, reset my energy levels, and when I’m back home, I write down my ideas using [The Minimalist Note Taking System](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go) and use it as my building blocks for my letters.

And because of that, I get to write these weekly letters to you.

The better your ideas are, the more you make. Because you are now operating in the Idea Space. Your earning potential is disconnected from your working hours.

It doesn’t matter if you work 10 hours a day. If your idea is bad, you won’t succeed.

But if you have a great idea, you can work 2-4 hours a day and earn 10x more without working any harder.

I know this letter is about running, but if you like walking, then walk. If you like riding your bike, then ride your bike.

But for the love of god, do it in nature, leave your phon,e and let your subconscious mind do the heavy lifting for you. Nature is where you’ll find all the inspiration you need.

There is a reason why Da Vinci was so obsessed with nature.

Because when you’re in the present moment and paying attention to the little details, you’ll realize just how everything is perfectly created and connected. You’ll start to connect dots, find ideas, and notice all of the opportunities that are right in front of you, but you were never able to spot because you were so distracted by work, grinding, and hustling.

Go run.

It will change your life.

Thank you for reading.

Enjoy the rest of your day.

-Hussain

**P.S.**

In 2 days, I’ll open 10 spots to my exclusive group coaching program.

If you want to finish the year on a high note and add $5,000/month to your business, gain 10,000 followers, and work directly with me and get personalized help and feedback to make sure you succeed...

Then this will be your opportunity to join.

Keep an eye out for in your inbox.


---

<!-- Archivo original: posts/2025-10-06-how-to-build-an-audience-as-a-person.md -->

---
titulo: "How To Build An Audience (As A Person With Many Interests)"
subtitulo: "The real reason why most writers feel invisible on Substack"
fecha: 2025-10-06T19:30:55.250Z
url: https://hussainibarra.substack.com/p/how-to-build-an-audience-as-a-person
audiencia: gratis
palabras: 3100
likes: 30
comentarios: 9
---

# How To Build An Audience (As A Person With Many Interests)

_The real reason why most writers feel invisible on Substack_

[![](https://substackcdn.com/image/fetch/$s_!8rIs!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c2b10bc-ad1c-47df-bee3-c3f6878b50d3_990x616.png)](https://substackcdn.com/image/fetch/$s_!8rIs!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c2b10bc-ad1c-47df-bee3-c3f6878b50d3_990x616.png)

_My statistics for the past 3 months on Substack_

Most writers and creators won’t make it on Substack.

The “set-it and forget-it” digital empire they see marketed to them?

They’ll never reach it.

That’s the sad reality.

Their lack of growth is so slow that it would take them 4-5 years to see any kind of success.

I started on Substack almost 3 months ago.

Since that time I’ve gained over 800 new readers and I’m consistnetly making $5,000/month without having a paid newsletter.

The crazy part?

I didn’t “niche down”.

I didn’t post “value” content.

I didn’t create a different publication for every category that I like.

I didn’t even post every single day.

I stayed nicheless. I talked about what I found interesting:

- Spirituality
- Social programming
- One-person business
- Writing online
- Audience-growth strategies

And I only have 1 publication, The Profitable Micro Business

The growth I have isn’t because I’m “lucky”.

It’s because I gained the skill of audience-building.

So this is what we’ll cover in today’s letter:

- Why most writers can’t grow on Substack (and all the mistakes to avoid)
- How to consistently grow an audience in any niche, experience level, and at any time
- How to turn your passion into profit so you can enjoy building a life of freedom and fulfillment

## **Why most writers on Substack are invisible**

It’s a shame really.

Because most writers I see on Substack are extremely talented and have interesting ideas, beliefs, and perspectives, but they just can’t get anyone to see their content.

They don’t realize that audience-building is a skill of its own.

“Just writing” isn’t going to cut it.

Especially if you’re getting advice on how to build an audience from someone who can’t build one themselves.

Social media is a noisy place. And to make it even worse, the dumbest and least qualified people are the loudest. So beginners fall in the trap of listenting to their garbage advice.

Here are a few mistakes I see people make:

### **Treating Substack like a hobby**

You’re here to build an audience and start a business.

Stop saying you write “poetry from the soul” or “just a guy who shares what he learns about life” or whatever.

Be brutally honest with yourself for a moment and ask yourself: _“Why am I even writing online in the first place?”_

I’ll tell you why.

It’s not because you have a deep passion for your topic. It’s not because you’re Mother Teresa and want to “give value”.

You’re here to make money.

Because if not for money, then you’ll just keep writing in your journal and all will be good.

Take your writing seriously.

I’m not against writing about what you love.

I am all for it.

My entire brand is built around doing what I love. But this doesn’t mean you go on Substack and post once a month and say _“why am I not growing?”_

If you keep treating Substack like a hobby, it’ll stay a hobby.

Never committing to it. Barely making any money. Being complacent with being below average.

Substack rewards consistency.

Be consistent.

Post one Note a day. Publish one letter a week.

Start thinking like you own a business (because you are, whether you like it or not).

### **Not reading the room**

Nobody cares about your “coffee thoughts”.

I’m sorry.

But it’s true.

Substack is a place where writers go deep with their thoughts and ideas.

- Deep dives
- Breakdown
- Predictions
- Anlysis

These types of posts dominate Susbtack for a reason.

The quality of content on Substack is much higher than on other platforms.

This is why writers flock to Substack.

This is the only platform I found that rewards people geeking out on certain topics.

And when you write your posts in the form of personal stories, you’ll stand out from the crowd (just go and read my previous letter and you’ll see me weave in personal stories and perspectives).

Substack is degined for long-form content, go deeper with your idea, geek out, and give your personal take on it.

### **Writing like it’s 2012 (it’s k*lling your reach)**

Most people’s headlines inside their letters are boring.

When they try to “section” their writing by headlines, they’re boring as hell.

- “Drink water”
- “Move more”
- “Create a list”
- “Organize your time”
- “Give yourself space”

BORING.

Maybe that’s the Gen Z that’s in me, but I hate the 2012 blogging era.

You’re not just writing for information anymore, you’re writing for entertainment as well. You can argue about how it’s unfair all you want, but it’s reality.

You can either stay in denial and never make any progress or adapt

People want novelty, drama, and sass. Adding in your personality on top of that and you’ll have a winning formula.

Just take a look at my headlines (and subheadlines) in this letter and previous letters. Almost every single subheadline just makes you want to read more. They spark curiosity.

Even big writers (like Tim Denning & Dan Koe) took note and praised my writing.

The era of just posting “How To’s” and advice content is gone. People want perspective and a unique worldview to try on and see their problems in a new light.

### **Being selfish with your writing**

This is a mistake I used to make when I first started writing online (almost 2.5 years ago).

I was being selfish.

I only wrote about what I enjoyed and didn’t care about my audience.

My reasoning?

_“They’ll follow me for me.”_

But this works only if you’re living in LaLaLand.

Now I have a phrase that I always like to repeat to myself: “You’re not the hero of your own brand, the reader is”.

Now, I don’t just ask myself “what do I love?” but I also ask “what has my audience shown to love?”

Then I write about the ideas that intersect. It’s the perfect recipe for building a brand you love and having people.

Because this is what content is all about, positioning your ideas in a way that you _and_ your audience love.

### **Stop plugging your publication under people’s Notes**

This is crazy that I have to mention this point.

But...

STOP SPAMMING YOUR NEWSLETTER UNDER PEOPLE’S NOTES.

Nobody will join your email list.

It makes you look desperate, and it’s hurting you more than you’d think. You’ll get shadow-banned, your engagement will be nonexistent, and the algorithm will keep punishing you for months for doing it.

So let me show what you should do to build an audience (without having to niche down).

# **How to build an audience faster than everyone (while staying nicheless)**

This guide is evergreen.

What I’m about to give are the principles.

Not tactics or hacks.

Because if you’re looking for a posting schedule, all you need to do is:

- 1-2 Note per day
- 1-2 Letters per week

That’s really it.

Engaging and posting more helps, but it doesn’t really matter. Maybe in the future this will change.

But again, this is why I want to focus on the principles and not tactics or hacks.

Principals don’t change. They are consistent.

So it doesn’t matter if you switch platforms or if the algorithm changes. When you nail down the principles, you become algorithm-proof.

Your brand is no longer at the mercy of the platform. You can earn as much as you want.

These principles helped me attract an audience of 25,000 followers in 12 months.

[![](https://substackcdn.com/image/fetch/$s_!Dm-d!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F23511921-177b-4b96-9224-bde9188528cf_1001x561.png)](https://substackcdn.com/image/fetch/$s_!Dm-d!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F23511921-177b-4b96-9224-bde9188528cf_1001x561.png)

_My total audience across X & Substack_

### **The 4 evergreen skills you need to have to succeed as a writer**

Marketing. Sales. Persuasion. Human behavior.

All good content stems from having these 4 skills.

You need marketing to learn how to get in front of people.

You need sales to get people to pay you money (so you can make money from your writing).

You need persuasion to get readers to pay attention and care about what you have to say.

You need to understand human behavior so you know what kind of language to use and how to articulate your idea that will get people interested in your content.

You can’t just be good at one of them. You need to be good at all of them to succeed.

This is why I like having writing as a skill.

You get to practice the evergreen skills and pair them to any other high-value skill (like video editing, web design, coding, photography).

Drop the mindset of becoming a specialist and start learning other skills.

This is how you become future-proof.

### **Write beginner-level short-form content**

99% of people on the internet are beginners.

So when you write to the experts, the 1% of people, nobody engages with you. Because no one relates what you’re saying.

And posting content with the idea of “_if you know, you know_“ will just make you end up feeling disappointed because no one relates and no one knows.

The thing you need to understand about social media is you don’t control who sees your content.

Which makes writing to experts useless.

Because the majority of people won’t relate and won’t comment, like, or even bother to ask.

But when you write beginner-level content, you capture a wider audience, these people will engage with your content and share it to others, which tells the algorithm to push your posts to more people.

This way you get the viral effect.

Now instead of having an audience of 1,000 followers who are all founders. You now have an audience of 50,000 followers and 3,000 of them are founders.

Another thing is that experts like to be reminded of the basics more than they need to be taught something new.

### **Use proven structures for maximum impact**

I don’t care how authentic you think it is to open a page and start writing.

You’re still new.

It hasn’t worked out for you thus far, so why do you think it will suddenly work?

> _**“Insanity is doing the same thing over and over and expecting different results.”**_-Albert Einstien

The people who are seeing success on social aren’t doing it by sheer luck. It’s calculated.

There are templates and framework that you can use to structure your idea and give it the best possible chance to do well.

Here are some of my favorite frameworks to use:

For short-form content:

- PAS
- AIDA
- BAB

For long-form:

- PASTOR
- AIDA
- my own framework that I created, APPS

And because I posted more than 26,000 times (on X only). I have posts that went and got 100+ likes, 1,000+ likes, and some that went and got 100,000+ likes.

This all gave me data points for when I came to Substack.

So all I did in my first month on Substack?

Posting my best tweets on here.

And because the ideas were validated, the structure was built on copywriting principals, my Notes did better than most and I out-grew almost every single writer on here.

Even last week I had a Note that went and got 1,400+ likes.

I’m not saying this to brag, but I’m trying to explain to you that templates aren’t bad. Especially if you’re still a beginner or someone who isn’t finding the success they’d like (in terms of engagement and growth).

Templates are training wheels for you to get the hang of things.

Hell, I still use templates and frameworks from time to time.

Even some of the biggest creators (with over 250,000 and 1M followers) still use frameworks and templates.

If you want high-performing structures, just take a look at my profile and see how you can fit your idea in.

Or...

You can buy [The Minimalist Note-Taking System](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go) and get access to my personal swipe file with content templates that you can use immediately.

_This note-taking system helped me gain over 76 million views in 12 months._

### **Develop depth and perspective**

The most successful writers I know can change your thoughts on a topic on a fundamental level.

They aren’t shallow. They have a unique view of the world. Their ideas have depth. If you want to succeed on Substack (or as a writer in general), you need depth behind your ideas.

Read broadly, take notes, write about what you’re reading, and see how ideas intersect with each other.

Read philosophy to see how great thinkers articulate themselves.

You are operating in the idea space. You can’t succeed with shallow ideas.

People discover you for the value you post with short-form content but they keep coming back for the perspective and worldview that they see with your long form content.

Short form = capturing attention.

Long-form = Holding & converting attention.

### **Pick a good preview image for your weekly letters**

This is obvious, but so many people get this wrong.

Your preview image is part of your main headline for your weekly letters. If it doesn’t spark curiosity and if it’s not clear, then your post won’t do well.

For this letter, I am still not sure of what I want the preview image to be.

Here are some ideas that I have for it:

- A screenshot of my Substack growth analytics
  - The reason why: A Clear graph that’s going up
- A black and white image with text “How to grow on Substack for beginners (in 2025)”
  - Reason: Very straightforward and clear
- A white and black image of the Vitruvian Man and have a bunch of Da Vinci’s sketches on the sides
  - The reason why: people know Da Vinci as a polymath and as someone who has a lot of interests

Which one will I choose?

I don’t know.

But as a general rule of thumb, I always ask myself 4 questions:

- What’s the big idea of my letter?
- How can I visualize it?
- Can a stranger understand what the post is about without any context?
- Does it look good?

I can’t teach you how to visualize ideas. You’ll have to go and build that intuition yourself.

My advice:

Look at what your favorite, successful writers are doing and see how you can emulate their style.

Notice how I keep telling you throughout the letter to emulate others?

Because that’s how you learn anything in life. You don’t magically become good at writing or building an audience.

You need to see what others are doing, you try to emulate them, then tweak it slightly.

### **Create something of value to not become a starving artist**

Substack is filled with amazing writers.

But most of them suck at business.

They have zero clue when it comes to monetizing. So they rely on platform revenue and paid newsletters to make money.

But those methods will never allow you to make the amount of money you want.

What I like to do is be as independent as possible. I like to be the one in control of my business and how much I can earn.

If your income is tied to a platform, then you’ll always be at the mercy of that platform. One algorithm change, poof, you’re gone. You can get banned out of nowhere, and poof, you don’t have a business anymore.

So what do you do?

Monetize your knowledge.

You can create a low-ticket product to solve a very specific problem. Make it short and actionable. Write a simple landing page for your product. Promote it every week in your letters.

That’s what I did with [The Minimalist Note-Taking System](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go).

I saw people struggle with idea generation and don’t know how to make their writing unique. So I packaged my process of finding ideas and templates that I use for my writing (which helped me gain over 76 million views in 12 months) into a highly actionable, highly curated 15-minute course.

I also added another 2 over-the-shoulder-look lessons on how I use the system to take notes, find ideas, and write content.

I created a template, added my personal swipe files, and prompts.

Boom.

You have a course that’s ready to be sold.

And on the back end, I added a plug to my coaching service. So now I don’t need to always be pestering people in the DMs to join my coaching.

All I need to do is promote my low-ticket in my letters, get people to buy, and have my back-end system handle all the selling for my coaching.

If you don’t know how to structure your course, look at what I did with [The Minimalist Note-Taking System](https://stan.store/hussainibarraabboudi_233/p/one-more-step-to-go). Look at how I did it and implement it for your own product.

The reason why I tell you to look at it isn’t to make money. But it’s because it has an 80% completion rate (when the industry average is 20%). You’ll also get to see how I created my back-end system.

Because here’s the thing:

If you don’t learn how to be independent and take control over your income, you’ll never make it. You’ll always be that talented writer that no one pays attention to.

You need to learn the 4 evergreen skills: marketing, sales, persuasion, and human behavior, to make it as a writer.

## **Final words - You’re a copycat by nature**

How did you learn to walk, to speak, to write, or even to think?

You saw observed how other people moved, the sounds they made, the shapes they drew on the piece of paper, and how they organized their ideas, then you emulated them—because you didn’t know any better and that’s the only starting point you have— then after you understand how they did it, you to carve your own method and innovate.

As a beginner, your goal isn’t to create something unique. Your goal is to take something that’s already working, emulate it, and make it just a little bit better.

**You learn by emulating.**

Follow great writers and creators. Go to your favorite writer’s profile and see their posts.

- What ideas are they talking about?
- How are they writing their headlines and subheadlines?
- Why did they phrase their sentence a certain way?

Start analyzing how the pros do it and see how you can apply it to your own writing.

Then your entire goal is to show up every day, iterating and improving until you succeed.

Thank you for reading.

Enjoy the rest of your day.

-Hussain

**P.S.**

If you’d like to add $5,000/month to your writing business (regardless of your niche or experience level) in 12 weeks or less.

3 spots are left.

Reply to this email with “Writer”.

And I’ll send you the details.


---

<!-- Archivo original: posts/2025-10-27-modern-society-is-designed-to-make.md -->

---
titulo: "How to take back control of your life (in 6-12 months)"
subtitulo: "Create a life of meaning, purpose, and profit"
fecha: 2025-10-27T07:56:18.608Z
url: https://hussainibarra.substack.com/p/modern-society-is-designed-to-make
audiencia: gratis
palabras: 2480
likes: 18
comentarios: 1
---

# How to take back control of your life (in 6-12 months)

_Create a life of meaning, purpose, and profit_

[![](https://substackcdn.com/image/fetch/$s_!-MQI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcef52035-41d1-499e-98d6-0d896890695c_2912x1632.png)](https://substackcdn.com/image/fetch/$s_!-MQI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcef52035-41d1-499e-98d6-0d896890695c_2912x1632.png)

_Credit: Midjourney_

I turned 24 three weeks ago.

_Say happy birthday ;)_

And my mom asked, “What are you doing for your birthday?”

_“You know, just the same old stuff.”, _I replied

Mom: _“You should really go out and enjoy your life while you’re still young.”_

In the past, I took her concern to heart and forced myself to go out.

But every time I did “have fun”, I just wanted to curl back to my place and write.

So for this birthday, I didn’t do anything special.

In fact, what I did was “boring” in other people’s eyes.

I drank my tea, wrote a few emails and finished a section for my newsletter, drafted a few tweets, worked on a product, responded to clients, went to the gym, then went for a run.

The only thing that would’ve made my day better was if Madison Beer woke me up and gave me my tea in bed.

The reason I bring this up is because most people can’t understand that “doing the same old stuff” is exciting.

I genuinely enjoy what I do every day and it brings me fulfillment, meaning, and happiness.

If you don’t enjoy what you do, then why would you keep doing it daily?

But most people can’t comprehend this because they aren’t living the life they want.

# **You were assigned a life that wasn’t meant for you**

Schools were designed by factory owners who wanted obedient workers.

Workers who checked boxes, didn’t question, didn’t challenge the status quo, clocked in and clocked out, and have zero ambition to do anything extraordinary in their lives.

And schools secretly brainwash you into thinking you’re incompetent and you can’t do anything by yourself.

_“Get good grades so you can get a high-paying job.”_

You always need the help of some “savior” — your employer (who’s running a business) — who will come and give you a job so you can live.

Just look at your workspace.

Everyone is talking about the same problems, the same goals, the same mindless thoughts, the same mindless actions, and the same mindless topics.

You don’t have an identity anymore.

And to make it even worse, you now have a routine that was assigned to you.

The voice that’s at the back of your head that’s telling you “you are meant for more”?

That’s the real you telling you to wake up.

But most people choose to stay asleep because it’s easier.

# **Society’s definition of “the good life” is fundamentally flawed**

Wake up at 5 AM.

Hit snooze 4 times.

Drive 1.5 hours to work.

Get stuck in traffic.

Spend the next 8 hours doing unfulfilling work, contemplating your life choices and wondering if this is how your life will be for the rest of your life.

Leave the office.

Get stuck in traffic (again).

Come back home.

Argue with your partner (when all you want to do is just lay down and do nothing).

Walk the pet.

Eat dinner.

Watch Netflix and distract yourself with cheap dopamine to numb the pain of reality.

And when the weekend comes around, instead of improving your life and doing something about the situation you’re in, you destroy it — by drinking, partying, staying up late, drugs, etc — as an act of anger and revenge because you’re mad at yourself.

Most people hate their lives so much that they self-sabotage themselves and they don’t even know it.

That’s not living, my friend.

That’s hell.

How do I know this?

Because I lived it.

It was a never-ending nightmare.

Most people think happiness means being in a constant state of euphoria and ecstasy, otherwise you’re unhappy.

**All they care about is the “here and now”.**

_“How can I produce the highest amount of dopamine now?”_

But when the high is gone and they’re back to reality, they’re left with nothing but emptiness, shame, and disgust.

But what I learned after being “happy with doing the same old” is that happiness actually means feeling calm and indifferent.

This is why I fell in love with Stoicism and Taoism so much. You don’t cling to outcomes and chase endless desires.

Your actions are guided by virtue, purpose, and chasing something that’s greater than momentary pleasure.

Cheap pleasures clouds your judgment. You start self-sabotaging.

But if you want to wake up and live the life you want, you need to take back the control you lost.

# **How to start looking forward to Monday morning**

My daily routine doesn’t change much.

It doesn’t matter if it’s a weekend or a weekday.

_And if I’m being extra honest... I forget what day I’m in most of the time._

It’s always the same.

Wake up. Make my cup of tea. Write (while drinking tea). Finish writing and work on my thesis. Go to the gym. Run. Work on projects (lead magnets, offers, systems, etc).

But I have so much fun doing that routine.

“Hanging out” now feels like a chore to me.

And on the rare ocassions when I do go out with my friends, after 15 minutes I just wanna go back home. All I want to do is write, build projects, explore my ideas, and work towards the life I want.

_“But Hussain, won’t you burn out if you work all the time?”_

How could I possibly burn out?

I feel like a kid whenever I work on my business. Making more money doesn’t change how I live my life. If anything, the more money my business made, the less I care about “looking rich”.

I want to show you how you can build that kind of life (where money doesn’t really change the kind of life you live because you’re already living your dream life).

So it doesn’t matter if you want to build a business, become a writer, or simply you want to get paid to do what you love.

Here’s how you can take back control of your life, and design a day for maximum fulfillment and purpose.

### **You don’t need happiness, you need purpose**

> _**When a man can’t find a deep sense of meaning they distract themselves with pleasure.**__**- Viktor Frankl**_

Create a vision for your life.

Be specific.

What would your perfect day look like if money weren’t a problem?

What would you do if you had all the money in the world?

Then start setting goals that will help you achieve that kind of lifestyle.

Create a routine that helps you actualize your vision.

There’s nothing more exciting than getting to work towards your vision and seeing the improvements on your life.

Every time you complete a task, you know you’re one step closer to achieving the life you want.

When you have a purpose, your feelings become irrelevant. Because you realize that your feelings are temporary emotional waves that normalize with time.

If you don’t know what kind of life you want to live, start self-experimenting. Figure out what you love by trying everything.

Start messy. Allow your curiosity to guide you on what to do and how to do it.

It’s only through trial and error that you’ll gain clarity.

Self-experimentation is the only way you can truly figure out what you want in life.

### **This ancient Chinese concept revolutionized modern business**

Start a business.

_“But what does business have to do with living my ideal lifestyle?”_

Everything.

Business is a vessel for self-improvement.

Every problem you face in your business is solved by self-improvement.

There is a concept in Taoism called “Yin and Yang”.

It’s coexistence.

Just as light cannot exist without dark and dark cannot exist without light.

And where you find flowers, you’ll find bees and where you find bees, you’ll find flowers.

These are all examples of “coexistence”. None of them came before the other. They both came to reality at the same exact time and both disappear at the same exact time.

Business and self-improvement are the same.

Where you find business, you’ll find self-improvement and where you find self-improvement, you’ll find business.

That means if you are doing any kind of self-improvement, then you have a business (you’re just not aware of it).

Because when you work towards your vision, you gain skills, knowledge, experience, and you solve your problems. You can turn that wealth of knowledge you have into a product and sell it on the internet (because other people are also struggling with the same problems you solved).

_**Solving your problems offline is called self-improvement.**_

_**Solving your problems online is called business.**_

And the greatest gift modern soceity gave us is the Internet and AI.

You don’t need to have a million dollars to start. You don’t need a marketing plan. You don’t need a logo, a degree, an assistant, an office, or the million other things you say you need.

All you need is one social media platform, one core message (the vision you’re chasing), and your product (that comes by solving your problems).

It decentralized wealth.

You are no longer bound to the socioeconomic class.

In the past, if you weren’t born into an aristocratic family, then you were doomed to be poor.

But now?

It doesn’t matter who your parents are.

Everyone has the chance to improve your life, make money, and live a good life.

### **Turn your business into a game**

Projects are how you turn the impossible into possible.

Each project is a small piece of your grand vision.

Each one teaches you a set of skills, lessons, and experiences that you can carry over.

After you complete one, you get to “level up”. Just like in a video game, after every time you level up, you get to allocate your points into your skill tree. The more points you have, the better you are in that area

And when you stack multiple projects on top of each other and you reach a major goal.

For example, I have a goal of making my first $15,000 month in January 2026.

Here are the projects that I’m currently working on that will help me get to that $15,000 a month:

- Lead magnet (showing you my system for finding high-performing ideas)
  - **The intention behind it:** Increase my newsletter growth from 150/month to 400/month
  - **The skill:** Audience-building (even though I’m good at it, you can always get better)
- Write 2-3 newsletters a week until 2026 (currently have 5 more drafts that I’m working on)
  - **The intention behind it:** Mention that I’ll be starting a newsletter cohort and build hype for it
  - **The skill I’m learning:** Storytelling.
- Launch PME (my current group offer) one last time in November before Black Friday
  - **The intention behind it:** This is the last time I’ll open the doors until February 2026, where prices will be higher. Students inside will get a 50% off on the newsletter writing cohort.
  - **The skill:** Marketing, sales emails, copywriting, funnels
- Launch newsletter writing cohort in January 2026
  - **The intention behind it:** Add a new revenue stream
  - **The skill:** Offer creation, launching, and teaching

Do you see how my goal, $15,000/month, was broken down into projects?

_And each project teaches me a skill which will help me get to the $15,000 month goal?_

If I had only had the goal of “$15,000/month” I wouldn’t even know where to start or how to prioritize myself.

But with projects, everything becomes clearer. You have deadlines and clear intentions behind each action you take.

The current you can’t live the dream life, but you can reinvent yourself through projects, skill acquision, and learning to _become_ the person who can live that kind of life.

### **Build your life when entropy is low**

If you can spend 8 hours building someone else’s dream, you can spend an hour building yours.

Spend 1-2 hours a day every day until you don’t give a f*ck about your 9-5 anymore.

Yesterday I got an email from my university Chancellor and I accidentally used the wrong title, called him the wrong name, and assumed he was a female when he was a male.

_Not my proudest moment._

But can you guess how long I spent beating myself over that mistake?

60-minutes.

Then I was back to life. Writing, building, and drinking my tea (obviously).

If this had happened to me 4 years ago, this would’ve been on my mind for at least 6 months.

But now?

I don’t care.

The reason?

Because I care about my writing business more than university.

Now, I don’t care if you’re a morning person or not, the first hour of your day should always be directed towards your dream life.

It’s the only way to start the day right.

The world is still sleeping, nobody is demanding your attention, responsibilities aren’t piling up, your mind is clear, and your creativity is at its highest.

Don’t give your most productive hours to your boss who doesn’t care about you.

F*ck your boss.

Use your productive hours on yourself.

### **The comedian’s quote that changed how I see my business**

> _**Life is a tradegy in a close-up, but a comedy in the long shot.**__**-Charlie Chaplin.**_

We’re so caught up living in the “here and now” that we think our lives are over when something doesn’t go right immediately.

But these mistakes and periods become stories you tell your kids, use in future content, and leverage to turn them into a lesson that makes you more successful.

Stop thinking in the short term and start looking at the bigger picture.

I hate sounding cliché, but everything happens for a reason. Your job is to find that reason, learn the lesson, so you can improve and succeed later on.

A phrase I keep repeating to myself whenever I work on my busines or when I’m training for a marathon is I like to remind myself the work that I’m doing now is the reason why I will succeed later on.

If you don’t see results now, it doesn’t mean what you’re doing is useless.

I can promise you one thing:

Whatever you do now, you’ll see the consequences (whether they’re good or bad) after 3-6 months.

That means the kind of life you’ll have in 3-6 months depends on what you do today.

Take back control over your life.

Self-experiment with solutions.

Build projects.

Learn new skills.

Obsess over your goals.

Thank you for reading

Enjoy the rest of your day.

- Hussain

**P.S.**

I am thinking of creating a newsletter writing cohort.

And I want to make sure it’s useful for you.

Reply to this email with the biggest problems you’re struggling with.

Is it finding new ideas to talk about?

Not finding your voice?

Consistency?

Or something else entirely?

Reply to this email, and I’ll get back to you.


---

<!-- Archivo original: posts/2025-11-04-how-to-be-so-productive-it-feels.md -->

---
titulo: "How to be so productive it feels illegal"
subtitulo: "The deep work routine that helped me 10x my revenue this year"
fecha: 2025-11-04T09:48:42.162Z
url: https://hussainibarra.substack.com/p/how-to-be-so-productive-it-feels
audiencia: gratis
palabras: 2252
likes: 26
comentarios: 8
---

# How to be so productive it feels illegal

_The deep work routine that helped me 10x my revenue this year_

[![](https://substackcdn.com/image/fetch/$s_!Vjcg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcf83902c-aa19-4c36-85d0-94b8dfd60c5c_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!Vjcg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcf83902c-aa19-4c36-85d0-94b8dfd60c5c_1920x1080.png)

In the past 8 months, I made 10x more than what I made in 2023 and 2024 combined.

Most people would make more money if they stopped doing 90% of what they think is “productive”.

When I was a kid, I got bitten by the “productivity bug”.

At 13, I would binge-watch Kharma Medic and Ali Abdaal’s videos (back when he was showing his Oxford notes and studying methods), and learning different techniques on how to take notes, study, and memorize.

The idea of being organized, time management, note-taking, getting ahead of others, and optimizing your day for maximum output sounded like heaven for me.

Any little free time I had, I tried to turn it into something productive. I started listening to more podcasts, taking more notes, and was constantly “on the grind”.

- Eating lunch? Put on a YouTube lecture
- Watching a YouTube video? Take notes
- Driving to the gym? Listen to a podcast
- Don’t have anything planned for the weekend? Take a course
- Taking a course? You can be more productive by turning it into a project

This carried on in my first 2 years of writing.

I was constantly writing tweets, taking notes, writing newsletters that I never even got to publish, creating offers that I ended up not launching.

I was working 24/7. Saying “no” to my friends just so I could spend more time on my writing.

I was so obsessed with productivity that I missed the entire point of productivity: Being efficient with your day so you can have free time to enjoy yourself.

But for the past 8 months, I did the complete opposite.

I worked 50% less and I 10x’d my revenue.

It was a wake-up call.

I changed my entire philosophy and approach to be more productive.

# **Productivity porn is secretly ruining your life**

F*ck Monk Mode.

F*ck hustle culture.

F*ck “staying on the grind”.

The people who preach about how hard they’re working are the least hard-working people I’ve met.

Somehow, working 16 hours a day is a badge of honor now.

It’s not.

All it says is _“I don’t know what I’m doing, so I’m relying on brute force to solve all my problems”_.

You’re working 16 hours a day because you like the idea of others saying: _“you’re very hardworking”_.

**Your desire to be productive comes from a need to be accepted and loved by others.**

You want the status that comes with the idea of being productive.

So you bury yourself in work. You sit at your desk for 12 hours staring at a screen because you’re afraid if you’re not working, then somehow you will be exiled. You feel guilty every time you relax.

Ironic, isn’t it?

The very thing you are doing— wanting to be productive 24/7—is the source of your pain and misery.

You wanted to be productive to enjoy your life, but what happened is you’re becoming so productive that you can’t enjoy your life.

Every second of your life has to be filled with something that moves you forward in life.

You listen to podcasts 24/7. You constantly read new books, you keep watching tutorials, and take new courses but never do anything with them.

### **Learning without working on projects makes you mentally obese**

It’s the same as how if you keep eating food (getting energy) and never put it into good use—by lifting weights or exercising—you’ll put on body fat and eventually become obese.

The same thing happens with information.

If you’re always learning and never putting the information you’re consuming into good use—by starting a project or writing about it—there’s no use of it.

You learn, but you aren’t doing anything with it.

> **“Knowing and not doing is the same as not knowing”****- Allan Dib**

You have information, but when the time comes to take action, you don’t know where to start because your entire mind is clogged with information. So you’re forced to start learning again, from scratch.

- You don’t need to read 1 new book a week.
- You don’t need to watch tutorials to learn a new skill.
- You don’t need to listen to 5 podcasts at the same time.

You just need 5 books that you love and re-read them for the rest of your life. Your perspective, ideas, beliefs, and goals change, so when you read the book again, you pick up on information that you were once blinded to.

You only need 3 habits:

A habit that builds your mind.

A habit that builds your body.

A habit that builds your wealth.

# **How to get ahead of 99% of people (without working more)**

Before I tell you how to get more done, in less time, and make more money.

I need to get rid of any preconceived notions and beliefs you have around productivity.

Because it doesn’t matter if I give the exact steps on how to be more productive, if you don’t believe what I say, if you’re mind is closed off and your perspective cannot be expanded, and you don’t let go of your preconceived beliefs of productivity, you won’t listen and take action.

To truly learn, you need to let go of pre-existing beliefs.

Someone can write one viral post on social media, gain tens of thousands of followers and make tens of thousands of dollars by driving them to a product.

Another person can spend grinding 4-8 hours a day engaging trying to build his audience but never makes any real progress.

Someone can write one email to their audience, send them to an offer, sign clients, and make anywhere from $5K-$20K per month doing so.

Another can spend 10 years writing 10 books only for when he launches them he makes less than $1,000.

There are 3 things you need to know about productivity:

- The quality of your work matters more than the quantity of your work.
- We live in an age of infinite leverage. Digital assets, AI, and no-code tools dominate the internet, you no longer need a team of 20 to help you run a business.
- The traditional economy teaches you that your time is linked to money. The permissionless economy teaches you that leverage is how you truly become wealthy.

You only need 2-3 hours a day to get ahead of 99% of people.

So I want to show you how I’m able to be productive (without working all day).

### **Set a very high personal hourly rate**

Most people get bogged down working low-leverage tasks that don’t do anything other than suck their time and energy.

Fighting for refunds. Cleaning their cars. Getting groceries. They are all time-suckers.

One thing that helped me was reading a concept from Naval Ravikant called, Aspirational Hourly Rate.

The idea is you set how much you think your hour is worth. Usually, it’s absurdly high compared to what you think. Because there’s no way for you to level up in the game of life if you keep aiming low.

At the beginning of this year, I set it at $200/hour. It was 5x my actual hourly rate. Because of this concept, I was now forced to only work on high-leverage tasks. If what I was doing won’t make me $200, then I wouldn’t do it.

When you set a high hourly rate, you now have a mindset shift.

You start questioning whether it’s worth it to fight the lady at the counter to get a refund for your item.

Think about it.

It takes you 20 minutes to drive to the store, 15-30 minutes to explain your situation and fight to get the refund, then spend another 15-20 minutes driving back.

You could’ve made an extra $200 in that hour, but you chose to get $40 back.

Was it worth it?

Hell no.

Yet, so many people still choose to do it.

When you set a high personal hourly rate, you start asking: _“Will the task I’m doing make me the money I want?”_

If the answer is no, then drop it or outsource it.

Because of this concept, I stopped cleaning my car or buying my groceries.

Now I almost outsource everything.

I order my groceries online. I call a company to come clean my car. I order takeout (sometimes). I don’t have time to waste on these low-leverage, energy-draining tasks.

Your energy is a limited resource. Your time is a limited resource. Stop wasting them doing the things you hate.

Your goal is to live your life doing the things that bring you the maximum amount of joy, fulfillment, and money.

If you don’t want to do something and it’s less than your personal hourly rate, then outsource it.

### **Use your morning to work on your highest leverage tasks**

Every morning I spend the first 1-2 hours working on my projects.

This can be a newsletter, creating an offer, or writing emails.

It doesn’t matter if you’re a morning person or you’re not.

Your mornings should always be directed towards your future.

- It’s where your creative energy is at its highest
- Your mind is still clear and isn’t clogged by reality
- The world still hasn’t woken up and demanded your energy

You can’t convince me that you’re more productive, have more mental energy, and creative power after staying awake for 12 hours, spending 8 hours working in a creatively draining and soul-sucking job that makes you miserable and all you want to do is just sit on your couch and watch Netflix.

Spend the first hour you wake up on your highest lever task.

If you’re a writer, creator, or a solopreneur, there are 2 levers for you to pull:

1. Building a great digital asset (product, course, or offer)
2. Build an audience

**If you don’t have a digital asset, that’s priority #1. If you don’t have an audience, that’s priority #2.**

Everything else is just pure noise.

The beauty of digital assets is _anyone_ can start building them.

You can apply what you learn to a project. Create a curriculum that will help others get where you are faster. Package it into a digital product (course, masterclass, templates, coaching, consulting, or whatever you choose).

Every 3 months, review your progress and see how you’ve done.

If you’re not making more money, not feeling more energized, or not more organized in your life, then pivot. Try a new method. Start a new project. Hire a mentor. Get a coach.

The point is to iterate and keep moving.

A problem most people make is they are too attached to what they’ve built, too proud to admit they need help, so they never get help and get stuck in life.

### **Let your subconscious mind do the work for you**

We’re no longer in the Industrial Age. We’re in the Information Age.

Your results are no longer tied to your time.

We’re now operating in the idea space. The person with the best ideas wins.

You don’t find great ideas by being mentally obese. You find ideas by being mentally lean.

Listen to less podcasts. Read less. Work less. Ruminate less. Scroll less.

Walk more. Run more. Meditate more. Journal more. Write more. Think more.

Do less work.

This is a concept a lot of people don’t know about. But if you do nothing, your subconscious mind starts to work extra hard. It starts to think.

The ideas you get in the shower?

That’s your subconscious mind at work.

When you “do nothing”, your mind switches from Task-Positive Network (it narrows your focus, turns your attention to external tasks), to Default Mode Network (it expands your mind, you start to wander and think about the past and future).

Your mind is always working towards a goal (whether you’re aware of it or not).

For most, their goal has been set by society, parents, teachers, and colleagues. Their goals are shallow and lead to a mediocre life. And I’m guessing you’re someone like me, being average is your greatest fear in life. You want to be something special and live an extraordinary life. You won’t live that kind of life if your goals aren’t even yours. Set your own goals. This is why I told you to set a high personal hourly rate and create projects. These will slowly rewire your brain to think differently from others.

When you have your own goals, your mind will automatically start moving towards achieving it. And when your mind goes into Default Mode Network, it will start doing the heavy lifting for you.

You get great ideas without having to think a lot, you solve problems without _doing_ anything, they naturally come as an “aha moment”.

Stop obsessing about how many hours you worked.

Stop trying to optimize every part of your life.

There’s beauty in “letting go” and reducing your work by 50%.

The irony is when I reduced my work, I was forced to find new, more effective ways to make more money.

The goal of life is to get paid doing what you love.

- Hussain

**P.S.**

Tomorrow, I’ll be opening the doors to my coaching program for the last time this year.

I’ll be helping 3 people add an extra $5,000 in recurring profit.

Want to get the details early?

1. Reply to this email
2. Say **“I want it”**.
3. I’ll send over the details ASAP.

**P.P.S**

**Don’t comment it, if you do, I won’t respond.**


---

<!-- Archivo original: posts/2025-11-09-if-the-average-person-did-this-for.md -->

---
titulo: "If the average person did this for 90 days, they would be unrecognizable"
subtitulo: "How to launch into a completely new life"
fecha: 2025-11-09T10:32:00.055Z
url: https://hussainibarra.substack.com/p/if-the-average-person-did-this-for
audiencia: gratis
palabras: 2533
likes: 22
comentarios: 7
---

# If the average person did this for 90 days, they would be unrecognizable

_How to launch into a completely new life_

[![](https://substackcdn.com/image/fetch/$s_!-35N!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc5e5f76b-d1b3-4d88-b150-22e23dd4191f_2912x1632.png)](https://substackcdn.com/image/fetch/$s_!-35N!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc5e5f76b-d1b3-4d88-b150-22e23dd4191f_2912x1632.png)

_Credit: Midjourney_

The average person will never live the life they want.

In fact, they’ll never achieve 90% of the things they want. They’re too comfortable in their miserable lives.

It’s painful enough for them to crave a change, but not painful enough for them to do something about.

They numb their minds with cheap dopamine.

And when you tell them that 90 days is enough for them to get in the best shape of their lives, start the business they always wanted, or even get the job they always dreamt about, they think 90 days is too long.

Having those people around you is contagious.

They don’t only ruin their lives, they also ruin yours by putting you down, telling you that there’s no point in trying whenever they see you trying to change for the better.

Now I’m lucky enough to have drastically changed my life in the past ~3 years.

I went from being a broke, skinny college student who didn’t know what he wanted to do in his life, to putting 30 lbs of mostly muscle, building a profitable writing business, an audience of 25,000 followers, and worked with four differnet 7-figure founders.

Here are the best pieces of advice I have if you want to change your life.

### **1) Expand the area of what’s possible**

> **Your life will drastically improve if you understood how limited perspective is and how the area of what is possible is far greater than you initially thought.**

Humans are a goal-driven species.

We’re always chasing a goal. Whether you’re aware of it or not.

Your goals and actions are always aligned with a mental image you have of yourself and it has been shaped by all your previous experiences, conversations, beliefs, ideas, interactions, and thoughts you had in your life.

Your mental image decides what’s possible, impossible, and the perspectives from which you view life.

You might have an idea that others see as crazy. But to you, it’s perfectly rational and reasonable — what decides is the mental image. Your success is limited to it.

You can’t change it by feeding it positive thoughts. You must work on yourself and realize that the current mental image you have of yourself is false.

You do this by collecting _evidence _that proves it’s false. Then you start by finding new evidence that supports the type of person you want to become.

I’m not very into spirituality, but I love to read about it. It expands my perspective and helps me realize just how limited our minds are.

I’m not here talking about chakras, energy systems, or whatever those spiritual gurus like to talk about. But the way they phrase their sentences, the arguments they construct, the perspectives they have, it’s the cogs in my brain turning.

It makes you realize just how powerful your mind is.

When you expand your perspective — the area of what’s possible — you become unstoppable.

You literally become a new person.

When you put yourself in a new situation, you unlock new genetic codes that were stored in you and you had no idea about.

Read philosophy. Read spirituality.

Expand your mind.

Expand the area of what’s possible.

The only thing holding you back in life is your limited perspective.

### **2) Learn the greatest skill of the 21st century (even if you’re interested in business)**

I hated writing as a kid.

I always thought it was reserved for academics and fat, broke, old, grumpy men who lived in a shack, isolated with a smoke pipe in their mouths, talking about how angry they are with the world.

But for the past 2.5 years I’ve fallen in love with writing.

Now, not a day goes by where I don’t write.

It feels like play. You explore ideas you deeply care about. You attract like-minded people to your business. You can reach thousands (if not millions) with just a keyboard.

Writing is the best skill you can have.

- It’s the foundation of all high-income skills
- It teaches you human behavior and psychology
- It helps you think better and regulates your emotions

If you don’t know what to do with your life, start talking about the things you’re interested in on the internet, chase your curiosity, attract an audience, and serve your audience.

And with AI and automations, it makes writing even better.

You write a post on social media, you add a simple CTA for people to join your email list, once they join, your automations kick in, and starts to do all the heavy lifting for you.

Emails and offers are being sent without you doing anything.

Then, it’s just a matter of writing more and getting more people into your list.

**The more you write, the more you earn.**

### **3) Start a business (even if you know nothing about it)**

I never planned to start a business.

All I wanted was to improve my life. To live life on my own terms. To gain complete freedom.

I’m not telling you to start a business to make a sh*t ton of money, move to Bali, smoke Cuban cigars every day, and become a digital nomad.

If that’s what you want in life, go for it.

But the reason I’m telling you to start a business is because it’s a vessel for self-improvement.

You get paid to solve your problems.

- Want to make more money? You’ll need to get over your self-limiting beliefs.
- Need to close deals for your business? You’ll need to get good at social skills (even if you’re an introvert).
- Want to make faster progress? You’ll need to get used to uncertainty, the fear, and ups and downs that come with starting a business.
- Want to live life on your own terms? You’ll need to figure out what you like, don’t like, brings you fulfillment, and meaning to your life, and business allows you to explore these options faster than anything else.

Business is the missing puzzle in your life.

### **4) Build projects & skip tutorial hell**

Most people move too slowly.

It takes them 10 years to make any significant progress.

The reason?

They are stuck in Tutorial Hell, going around in circles like a headless chicken.

If you want to make progress faster, throw yourself in the deep end and start creating projects.

This is why I told you to start a business.

It is the best possible project you can create.

Projects are structured goals with clear and actionable steps for you to take and with deadlines.

Humans are a goal-oriented species.

This means we love goals. It brings us certainty in an uncertain world. It gives you a sense of control when everything around you goes to sh*t.

- If you want to get better at design, create a website for your business.
- If you want to get better at video editing, create videos and edit them for your content.
- If you want to get better at copywriting, create a product for your business and start writing copy.

Projects are how you _actually _learn skills. Not by watching tutorials.

When you encounter a problem, research for a solution, self-experiment until you solve it, and move on.

Stop the unhealthy obsession with “constant learning” and apply what you already know.

You spent 18 years of your life just learning in school. And another decade learning from podcasts, books, videos, and your job, you already know what you need to do.

You don’t need more information.

You need to start a project to organize everything that you already know and give you clarity to move forward.

### **5) Invest in your most profitable asset**

You are your most profitable asset.

It beats every index fund, crypto coin, real estate, and bonds.

When you realize your wealth is directly connected to how much knowledge and skills you have, the more money you’ll make.

Traditional investment (crypto included), promises you to make an extra 5%, 10%, or even 20% per year.

But if you invest in yourself, learn new skills, apply them to your business, you can double or even triple your income.

I spend ~$2,000/month to work with mentors.

This year alone, i spent close to $15,000 in mentorships.

And the results?

I made 10x more money in the last 8 months than I did in 2023 and 2024 comibined.

7 ways to invest in yourself:

- Books
- Cohorts
- Courses
- Podcasts
- Mentorships
- Masterminds
- Communities

The best ones?

Cohorts and private mentorships.

You get direct feedback on your work from someone who has achieved what you want, but also knows your exact problems and what you’re doing.

So now, instead of getting vague advice, you’re getting personalized feedback that are highly actionable to your situation.

You get more clarity, you improve faster, and you make more progress.

Mentorships and cohorts are the secret to making 12 months of progress in 3 months.

- Want to get better at video editing? Hire an editing coach
- Want to scale your business? Hire a business coach
- Want to build an audience? Work with a coach

You think you’re getting information, but what you’re really getting is speed.

Bet on yourself, not the stock market.

### **6) Obsessively work towards your goals**

> _“Sensible people get paid to be themselves”_
> _- Alan Watts_

Most people love to talk about work-life balance.

But I hate the concept of work-life balance. It assumes that you hate the work you do.

That’s the situation of most people. They hate the work they do. They hate it because they didn’t take control over their lives by setting goals that will help them do what they love for a living.

Because if you truly liked what you do, you wouldn’t care about work-life balance. Your work feels like play, and you’d want to keep playing as long as it’s fun.

If you want to live a life that’s different from the masses, you need to become different.

Set goals that others see as crazy. Spend your mornings chasing your goals. Relentlessly execute and don’t stop until you get what you want.

### **7) Work out twice a day**

> _“No man has a right to be an amateur in the matter of physical training. It is a shame for a man to grow old without seeing the beauty and strength of which his body is capable”__- Socrate_s

I’ve been a skinny kid my entire life — 10 lbs underweight.

I was so skinny that it became one of my biggest insecurities. But I’ve been consistently working out for the past 2 years.

Since then I’ve added 35 lbs of mostly muscle.

And I have to say, it’s been the best decision I’ve ever made. Now, I work out _at least_ 8 times a week.

I’ve never felt better, had higher energy levels, more focus, more motivation, and more confidence in my life. Every domain of my life improved after I started working out.

We live in a shallow society.

We DO judge a book by its cover. Someone who is out of shape gets less opportunities than someone who is in good shape. You can argue about how unfair it is, but that’s the world we live in. Get used to it.

Another reason why you should work out is that most of the principles you learn in the gym can be transferred to every other domain in your life.

In the gym, you can’t bench press 225 lbs on your first day in the gym. You’ll need to start with lighter weight and progressively add more weight until you can bench 225 lbs.

The same thing is in business, you won’t build your $1M/year business on your first try —especially if you’ve never started a business before, you don’t have the skills, or learned the fundamentals, or self-experimented.

You’ll need to start by learning a skill. Then landing a client. Then stacking more skills that will help you scale until you reach $1M/year.

You can’t operate at your best if your body is constantly failing you. You can’t focus for more than 5 minutes. You’re constantly struggling with brain fog. You have low energy levels.

The solution is to lift weights and run.

It’s been scientifically proven, there’s no better elixir to extending your lifespan and healthspan than building muscle and being strong.

You protect your brain from atrophy. You protect your body from being brittle. You protect your mental health from deteriorating.

Get strong. Get fast. Get jacked.

Stop letting your body be the limiting factor of what you can do.

### **8) Create a radical sense of urgency**

> _“Successful people have a strong action bias”- Naval Ravikant_

A pattern I noticed in every successful person I met:

They have a crazy sense of urgency.

Their deadline is now.

Not tomorrow. Not next week. Not some random date, they promised themselves they’ll get their shit together.

It’s today.

They see a problem, they take immediate action and they don’t stop until it is solved.

I can’t tell you how many people I've met in my life who have been stuck on the problem for YEARS.

It pisses me off.

Because it just tells me that you’re not serious about your goals. You are comfortable in your miserable life. You enjoy the dopamine hits that you get by talking about them but you don’t actually want to achieve your goals. Telling people about your goals releases the same dopamine in the same way as if you had achieved your goals.

You really want something?

Go get it today.

Don’t start making up excuses saying “I need X, Y, and Z to start”.

You have the internet. You live in the permissionless economy.

You can start a business just by posting on social media.

Want to sign a new client?

Go speak to people on social media and sign one TODAY.

Yesterday I was speaking to my business mentor and he told me I should be speaking to more peopel to get leads.

Guess what happened?

I got a call booked and 8 new leads on that same day.

**The only thing that’s holding you back in life is the limits you put on yourself.**

If you want to drasically change your life, create a radical sense of urgency.

Most people will call you crazy. But most people are average and will never amount to anything in their lives because they’re comfortable in their misery.

You’re not like most people.

You want to create a life that’s extraordinary. A life where only a handful of people get to enjoy. So the advice you get from most people can’t be useful to you.

Find a problem in your life today.

Solve, today.

Move fast.

Break things.

Fix them faster.

Iterate faster.

Thank you for reading.

- Hussain

**P.S.**

Speaking of radical sense of urgency...

The holiday season is coming up.

And with the right plan, you can easily make an extra $5,000/month or even $10,000/month.

Inside my private coaching, I’ll help you achieve that goal in less than 90 days (regardless of your niche and audience size).

Doors close in 24 hours.

Want the details?

1. Reply to this email
2. Say “**Urgency**“
3. I’ll send over the details


---

<!-- Archivo original: posts/2025-11-12-i-gained-49-leads-in-7-days-heres.md -->

---
titulo: "I gained 49 leads in 7 days. Here's how I did it (without cold outreach or paid ads)"
subtitulo: "Copy what I did (and get paid doing what you love)"
fecha: 2025-11-12T10:29:15.548Z
url: https://hussainibarra.substack.com/p/i-gained-49-leads-in-7-days-heres
audiencia: gratis
palabras: 1309
likes: 11
comentarios: 0
---

# I gained 49 leads in 7 days. Here's how I did it (without cold outreach or paid ads)

_Copy what I did (and get paid doing what you love)_

“Already got 2 leads in the past 10 minutes”.

It’s Tuesday.

I’m on a call with my business mentor, and I announced that the doors for my private coaching are open.

At the end, I had a total of 49 leads, 13 of which came in the first 48 hours and the rest were spread across 5 days.

_The only thing that would’ve made it better is if Madison Beer were my girlfriend._

Now this wasn’t luck.

It was calculated.

Every email, every post, every conversation I had was intentional.

And if I had known these 4 pieces of advice (which I’ll share in a moment), I would’ve reached $5k/mo a lot faster.

Starting with advice #1...

# **Email is King**

Out of the 49 leads, 42 came from my newsletter.

Keep in mind, my email list is 1/10th the size of my social media audience.

But still, it made up 85.7% of the total leads I got. And the leads who converted, they all came from my newsletter.

This just confirms what I’ve been saying for months: **Your newsletter is your most profitable asset in your business.**

Going forward, I’ll be doubling down on growing my email list.

Because as a writer and creator, you’re operating in the trust economy.

The higher the trust, the more people invest.

The way you build trust is by knowing who you’re writing to and emailing them often so they can feel seen, heard, and understood.

You don’t need a massive audience to gain freedom.

You just need a small loyal tribe of fans who believe in you and in your mission and they’ll buy everything that’s in front of them (given you’re selling a high-quality product).

If you don’t have a newsletter yet, start one.

The sooner you start, the sooner you’ll start building trust, the sooner compounding kicks in, and the more money you’ll make.

# **Add pressure**

Every launch needs 2 things:

- Urgency
- Scarcity

The scarcity depends more on your offer.

If your offer is a digital product, then you can’t really make it scarce, but if it’s a masterclass, live webinar, or a coaching offer, then it is in your control.

I always like to open 2-3 seats at a time.

This gives me control over the supply. But also, it ensures I can still deliver a high-quality experience for those who joined before.

**Your reputation is everything.**

Letting everyone through the doors to make a quick buck at the cost of quality is a one-way ticket to burning the entire business to the ground — your clients won’t get the attention and support they need, they’ll feel scammed, and never work with you again.

For urgency, it was naturally baked in.

Holiday seasons are coming up (Black Friday, Cyber Monday, Christmas, and New Year’s) and this is the last time I’m opening the doors.

_A note about pressure:_

Never fake it.

If you say it is the last time you’re opening the doors, then mean it. If someone asked for details AFTER the doors closed, they’re not allowed in.

But if they asked for the details before the doors closed, and you forgot to send the offer to them, give them the chance to join. Tell them that you’re making an exception because you forgot to send them the details.

**The best marketing tactic is pure honesty.**

# **The more you pull, the harder the snap**

> _**“People want things that are hard to get”**__**- Daniel Priestly**_

Think of a launch as an elastic band.

The harder and longer you pull, the bigger the snap when you release.

What I used to do in the past is I’d immediately go into open enrollment. I felt like it came as a surprise and it caught people off guard.

For this launch I did something different - I did four days of “pre-launch”.

The goal is to plant the seed ahead of time and get them mentally ready to buy.

The first 2 days I promoted my case study on how I 10x’d my business in 2025 (breaking down my philosophy and building trust). Then I did another 2 days talking about what I’m building (and why it’s important for my readers).

Again, I’m not selling anything in those 4 days. All I’m doing is building tension and getting people excited.

All I did was mention how I’ll be opening 3 seats for the last time to work with me.

The result?

6 people wanted to join the program before I even announced it.

When open enrollment came around, 9 more leads came in in the first 4 hours - in 48 hours that number jumped to 13.

If you want to shorten the sales cycle and increase your conversions, make your product harder to get, build tension.

My previous mentor used to build tension 12 weeks before launching. 12 WEEKS!

The beauty of building tension is you get to target many different problems and see what resonates with your audience.

And when it comes to launch week, well, you already have the data, you just need to write emails talking about _the same_ problems that did well during the tension phase.

Speaking of getting data...

# **Listen to the signal**

Before this launch, all I did was listen to the signal.

Every tweet you post, every email you send, every conversation you have, your audience is voting for what they want.

- What they are interested in
- Why they bought (from before)
- If they didn’t buy, find the reason why (there is always a reason)

Your goal is to pay attention and listen to the signal and deliver on what they already voted on.

For this launch, what my audience wanted was clear: **They wanted clarity and speed.**

So I created a new plan to help them add an extra $5,000/month to their business and turned every step of my business into AI workflows that they can use to help them move faster.

I’m talking about finding your customer avatar, spotting profitable problems in your niche, creating targeted content, case studies, and offers in a matter of minutes.

In every email I sent, I made sure to hammer in this part. Because it’s exactly what my audience wanted — not talking about it is like shooting myself in the foot.

The best part about integrating AI into my business?

I realized just how inefficient I was running my business.

Trying to do everything from scratch every time just added extra workload that I didn’t need.

But now, with the AI workflows, creating a launch takes 1-2 hours of my time (compared to before when it took me 8 hours).

And because of this, I learned a valuable skill, creating systems _with _AI.

In the future, I can turn my AI workflow into a low-ticket product. When you listen to the signal, you can solve problems in your business and turn them into money-making assets that don’t require any of your time to deliver to your audience.

That’s the beauty of building a personal brand.

You get to solve problems in your business, you learn a new skill, and as a result, your clients get to move faster and see results faster.

It’s the perfect win-win situation

Thank you for reading.

Enjoy the rest of your day.

- Hussain

**P.S.**

I’m thinking of creating a new product.

The idea is to give you all the necessary tools you need to start building an audience and monetizing it (as a complete beginner and regardless of your niche).

It won’t be free. But it will be budget-friendly.

If you’re interested in something like that...

1. Reply to this email
2. Say “Interested”

If more than 50 people say they’re interested, I’ll go ahead and create it.


---

<!-- Archivo original: posts/2025-11-17-1m-follower-audience-how-to-grow.md -->

---
titulo: "1M Follower Network (How To Grow As A Beginner Without Relying On The Algorithm Or Going Viral)"
subtitulo: "Why being smart is not enough to succeed"
fecha: 2025-11-17T13:05:51.283Z
url: https://hussainibarra.substack.com/p/1m-follower-audience-how-to-grow
audiencia: gratis
palabras: 2468
likes: 35
comentarios: 10
---

# 1M Follower Network (How To Grow As A Beginner Without Relying On The Algorithm Or Going Viral)

_Why being smart is not enough to succeed_

[![](https://substackcdn.com/image/fetch/$s_!28iq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb35709e-5129-4317-b3ea-7701af3f1233_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!28iq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb35709e-5129-4317-b3ea-7701af3f1233_1920x1080.png)

_Credit: Hussain Ibarra_

Being good at what you do is the fastest way to live a mediocre life.

That’s a truth I discovered early on in my life.

Ever since I was a kid, the people around me, parents, teachers, family members, and adults, kept telling me, _“If you’re good at what you do, you’ll become successful in life”._

But everything that I’ve seen says otherwise.

When I was still in college, the really smart students struggled to get a job when they graduated. When they did get a job, they couldn’t adjust and fit into the team.

When I started working as an engineer, the same pattern showed up.

The smart, skilled, experienced, and hardworking employees are living an average life. But the less skilled, less intelligent, less experienced employees were the managers and executives.

I quickly realized that being good at what you do doesn’t mean that you’re going to be successful.

The average employee is actually smarter than his boss. But because he’s so focused on getting good at what he’s doing, he misses the more important part:

**Promoting just how valuable his work is to others.**

Not just to anyone, but promoting to the people who matter. The executives.

The average person doesn’t know how to promote their work in a way that gets people’s attention and notice just how good he is.

Unfortounately, we were raised in a bubble.

- _“Demanding a higher salary makes you greedy”_
- _“Bragging about how good you are makes you a bad person”_
- _“If you work hard, people will notice you and reward you for it”_

Do you not realize that you’ve been brainwashed by your parents, teachers, and other authority figures in your life?

Has their advice helped you live the life you want?

No.

Are they living the life you want?

No?

Then why do you keep listening to them?

It’s the same as the blind leading the blind.

Sure, they’re trying to be helpful and give you advice, but there’s no point in listening to them because they aren’t (and have never been close) to where you want to be.

You need to update your operating system. Install new beliefs. Expand your perspective. Go against the norms.

The world is filled with people who are less skilled, less intelligent, less experienced than you and have ended up becoming successful - only because they knew how to promote their work and get in front of people.

# **The Permissionless Economy**

The Internet decentralized wealth.

You can now reach anyone and everyone.

Anyone can now build a one-person business today, create a social media account, post content, attract like-minded people, solve a problem your audience has, package it into a digital product, and sell it to them.

With a well-crafted message, you can reach a founder, a celebrity, or anyone who is in a position where you want to be and connect with them.

In the past you didn’t have this.

You had to go to school.

Get good grades.

Get accepted into a prestigious school.

Be extroverted enough to keep going out, making friends, and connections until you find the perfect opportunity.

Opportunities in the past were limited and restricted to those who had wealth and powerful connections.

You were restricted by your geographical location and the societal class you were born into.

But now, opportunities are everywhere.

The post you just read? They need an editor.

The product you just bought? They need a designer.

The comment you saw? They want to get in shape and be happy.

The internet gave you access to 5.4 billion people.

All it takes is one well-crafted piece of content, with the right message, reaches the right corner of the internet, the right person sees it, and pays you for the value you have.

This all becomes easier as you have an audience.

But you don’t want to rely on the algorithm to spread your content and for people to see it.

It’s more predictable (and smarter) to take matters into your hands and spread the message yourself to make sure you find results faster.

This is why networking - as much as I hate to say that word - plays a big part in the success I have with social media and writing online.

# **The Power Of Having A Strong Network**

I have an audience of 25,000 followers.

But because of my network (of only 9 creators), I have access to 6.6 million followers.

Together we pull close to 70-100 million impressions per month.

And when I create a piece of content that I think is relevant to my networking, I’ll send it their way, get it shared, and potentially get in front of 6,500,000+ followers.

That’s the power of having a strong network.

By yourself you’re a small drop of water in the ocean. You don’t have a market. Nobody knows who you are.

But with a strong network, together, you can own a big chunk of the internet.

- You grow together (because now people associate you with each other and if one person grows, the entire tribe grows with him).
- You all start to see success and serve each other’s audiences (because not all of you will be in the same niche, some might be in an adjacent niche which is relevant to your audience).
- You increase your surface area of luck (the more people you know, the more people know you, and the more opportunities will fall on your lap).

**I want to make one thing clear:**

Networking does not mean you have someone who constantly shares your content.

Networking does not mean you have someone do free work for you.

Networking is meeting and becoming friends with other individuals.

Nothing more. Nothing less.

# **6 Steps To Make High-Value Friends (Without Coming Across As “Needy”)**

The process I’m about to give you is what I’ve used for my own business.

It helped me get mentored by 7-figure founders, build a network of 6.6 million followers, and land multiple clients.

Networking is foundational if you’re serious about growth and starting a business. Knowing how to speak to someone in the DMs to develop a connection will open up opportunities to paid work, leverage work, growth, and meeting high-leverage people.

You can use this strategy to:

- Meet and be friends with high-value individuals and create long-term partnerships (even if you have a small audience).
- Get a 500,000 follower account to repost your content which will result in a massive growth spurt.
- Be a part of mastermind groups and begin forming your tribe (that you will grow and learn with for most of your social media career).
- To always be a part of the conversation and have people talking about you. The more people know about you, the more work will be sent your way.

Before we start, this method does not work with the spray-and-pray method of sending 200+ DMs a day.

This approach is more intentional.

You’re more like a sniper who is intentional with each DM you send.

Here’s the 6-step process:

### **Find someone you resonate with**

Most people blast out DMs to anyone they see on their timeline.

But when you do this, you start speaking to people with whom you don’t resonate with and it’s the worst place to be in.

I know this because when I was a ghostwriter, my biggest problem was working with people I didn’t resonate with.

- I was burning out
- I started to hate writing
- I couldn’t come up with new, interesting ideas

But when you work with the right client, it’s the complete opposite. Working feels like play, it energizes you, and ideas come to you naturally.

So why not apply the same concept to your network?

Find someone whom you enjoy consuming their content and resonates with you. This way, you’re becoming friends with them.

Join communities, paid communities, look at the people you follow, is there anyone whose content you enjoy and you find interesting?

And when you find them, move to step 2...

### **Send a specific compliment**

> _“Great content my friend. Let’s connect!”_

This is what most people send as a DM...

I’m sorry, but this isn’t LinkedIn.

You sound like a bot, people will ignore you (because there’s no reason to respond), and you look like someone who’s desperate.

Before you send a DM find a specific post, piece of work, idea, or current project they’re working on and tell them how much it resonated with you.

This requires you to actually be interested in their content and work _**before **_sending the DM.

Here’s an example of a DM I sent to :

[![](https://substackcdn.com/image/fetch/$s_!W0qb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F19d16f1a-5172-4d1b-afd3-47f56f865421_573x593.png)](https://substackcdn.com/image/fetch/$s_!W0qb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F19d16f1a-5172-4d1b-afd3-47f56f865421_573x593.png)

Low pressure. Not coming across as needy and just showing some appreciation.

One way I could’ve made it better is I could’ve asked him what he was doing after he stopped working with Dan.

It would’ve led to a deeper conversation.

### **Be a friend**

A mistake with my DM with Jack is I didn’t follow up with a question after he replied.

Because if you don’t ask them questions and steer the conversation, then they won’t continue talking to you.

You need to be interested in them so they can be interested in you.

This is basic social skills.

_Notice how everything relies on finding someone you genuinely enjoy their content? Because that’s what real networking is about._

Ask them about their goals, projects they’re currently working on, or anything they’re interested in and start a conversation around it (assuming you both share the same interest).

Here’s an example from my DMs with Taylin:

[![](https://substackcdn.com/image/fetch/$s_!lD7T!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc8efefe8-e86b-4855-92b1-042b6d7b7b7c_1416x470.png)](https://substackcdn.com/image/fetch/$s_!lD7T!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc8efefe8-e86b-4855-92b1-042b6d7b7b7c_1416x470.png)

Notice how asked about the meetup?

Because we’re both speakers at the [Creator Economy Convention](http://thelivinginternet.com?via=hussainibarra) next year and it’s a perfect way of starting a conversation.

As I’m super excited about it, I started rambling on about it and then he started rambling on.

### **Deplatform the conversation (optional)**

This is something I wish I had done more of when I first started building:

Getting on a call.

This is one of the most valuable things you can do.

The connection you create with someone on a call is priceless.

There’s only so much you can communicate through DMs.

Your mannerisms, your personality, the way you tell a joke, the way you speak, it is very hard to communicate through text.

This is why whenever I vibe with someone in the DMs, I almost always invite them to get on a call. Getting on calls is more normal than you’d think (especially if they know.

If you want to be extra, you can ask them for their Telegram or phone number. Most of the people I met on X now speak either on Telegram or WhatsApp.

The only reason I bring this up is because a lot of people have their X notifications muted and they wouldn’t know if you DM’d them or not - and most people are already on these platforms and formed groups where they communicate and share strategies together.

### **Don’t pester them in the DMs**

Once the initial conversation ends.

Let it end.

They already know you and like you. There’s no need to feel pressured to keep DMing them and starting conversations for the sake of speaking to them.

It sends a signal that you’re low-value.

People have projects, goals, and tasks they’re working on. They’re not always free. And I’m guessing you also have goals that you want to achieve.

Respect people’s time. Only start a conversation when it is meaningful.

Speaking of meaningful conversations...

### **Always lead with value**

Making an ask before giving them value makes you look needy and desperate.

It also makes the entire conversation feel like you were just trying to make a sale and not really care about the other person.

The goal is to give them something first.

A YouTube video, a swipe file, an article, or a lead magnet you read.

Here’s a DM example you can use:

> _“Hey Hussain. I remember you talking your plans with [PROJECT NAME].I found this and it reminded me of you. I think you’ll like it [LINK]”_

You can even get on a call and talk about their goals/problems and give them actionable advice- again, specificity here is everything.

You don’t want to give generic advice. Give them something that opens their perspective to a problem they weren’t aware of, or how you solved the problem yourself in the past, and how they can do something similar.

When you lead with value, you build reciprocity.

The other person will feel like they “_owe” _you a favor in the future.

### **Create positive-sum games**

Nobody likes to feel they were taken advantage of.

The same principle applies when you ask your network for help.

If you keep asking for favors where you get all the upside and they don’t get anything in return, you’ll come off as needy and they’ll start ignoring you.

This is why you need to create positive-sum deals.

Business, when done properly, is a positive-sum game - you get something you want, they get something they want.

Your goal is to find what they want.

If you want someone to give you advice, what do they get in return?

If you want someone to share your post, how do they win as well?

Creating positive-sum deals is how you win in the game of business. Because now, everyone knows that if they make a deal with you and everyone will be happy. This creates long-term relationships and partnerships.

When you play long-term games with long-term people:

- Opportunities will fall on your lap
- Your friends send leads and clients to you
- You build a reputation so good that people will cut in deals that you never even thought of

My rule of thumb is to never ask someone for a favor unless I know they can also benefit from it.

**Here’s the truth:**

Everyone is selfish. Everyone wants to win. You need to be smart enough to find what they’re interested in and what they want (before they tell you what they’re interested in).

Once you do find it, reach out and ask for your favor, create the deal, and send your pitch.

Until then, keep providing value.

Thank you for reading.

Enjoy the rest of your day.

- Hussain Ibarra

**P.S.**

If you’d like to add an extra $5,000/mo to your creator business (regardless of your niche and audience size)...

You can access all of my systems, AI workflows, and frameworks that helped me 10x my business and gain 76 million views in the last 12 months…

For just $9 today.

All you need to do is copy/paste it over to your business and see results.

[Start scaling your business today.](https://hussainibarra.thrivecart.com/pme-launchpad/)


---

<!-- Archivo original: posts/2026-01-05-60-minutes-is-all-it-takes-to-do.md -->

---
titulo: "60 minutes is all it takes to do a hard reset on your life"
subtitulo: "How to make 2026 the best year of your life"
fecha: 2026-01-05T06:45:54.055Z
url: https://hussainibarra.substack.com/p/60-minutes-is-all-it-takes-to-do
audiencia: gratis
palabras: 2105
likes: 19
comentarios: 2
---

# 60 minutes is all it takes to do a hard reset on your life

_How to make 2026 the best year of your life_

If you don’t know what you want, you’ll be told what to do.

It doesn’t take a genius to go out and realize that most people are living on autopilot.

They hate their lives, work, and even partners.

So the only thing they do is binge-watch Netflix, eat junk food, doomscroll the entire day, watch brainrot content, and numb their minds with cheap pleasure and hope that tomorrow will magically become better.

This is something I realized early on in my life.

Ever since I was a kid, I was observant and paid attention to the people around me and everyone was the same: miserable, fat, and unfulfilled.

I made a promise to myself to be different, but somewhere along the way, I got brainwashed by society.

They etched their beliefs into my mind and that ended up being my self-limiting beliefs.

- _“Money is evil.”_
- _“Life is supposed to be hard.”_
- _“You’re not supposed to enjoy your work.”_

So I when I was in school, I thought the traditional path is the only viable path (because everyone around me took that path and no one decided to take a different one).

Got good grades in school. Studied engineering at a top university. Got a job in a prestigious company. Had a good income. And now I’m getting my master’s in environmental engineering.

But I was miserable.

It was only when I was stuck in traffic that reality hit me in the face again.

_“Is this what life is all about? Waking up tired, working a job you don’t care about, getting stuck in traffic, and coming back home too tired to do anything?”_

I started contemplating my life and asked what I really wanted to do in my life that I was able to start massive strides into improving my life and gaining fulfillment.

Now I’m lucky after 3 years of continuously asking myself, “What the f*ck do I want from my life?” and working every day towards that life, that I can say I wake up every day full of excitement and energy to write for my brand.

And now I’m surrounded by writers and creators who are all changing the world as we speak (in their own respective domains).

It all started because I was able to wake up, realize that I was going down the wrong path, identify the self-limiting beliefs that were passed on to me from society and reprogram my mind to see life in a different way.

# **How to do a hard reset on your mental programming (reinvent your life in 60 minutes)**

This is a process I run through every few weeks.

Whenever I feel like life is being chaotic, out of order, or just feel anxious, I do this exercise.

Time and time again, it brought me more peace and clarity to my work.

Let me be clear, you won’t figure out your entire life in one hour.

This is not what this is.

Anyone telling you that they can fix your entire life in one day, run for the f*cking hills. No one can do that for you.

However, I can say that this process will help you wake up and realize if the path you’re currently on is aligned with you. Realizing that you were going down the wrong path for the last 5 years isn’t a crime.

It is a crime, however, if you realize that it’s a mistake and still choose to do nothing.

Here’s the process that changed my life (in 4 steps):

### **1) Pull out a notebook**

You feel lost because you were operating on autopilot.

You’ve been doing the same things over and over again without much thought behind your actions.

But now you feel horrible and are trying to think your way out of your problem.

Nobody in history has ever thought their way out of a problem.

To solve a problem, you must take action.

First, become aware of what you were doing on autopilot.

The best way to do it is to write more.

Writing exposes your thinking. Writing is how you identify your problems. Writing is how you become aware of your problems.

You can do this with a physical journal or an app.

Because I’m a Gen Z I mostly write on **[an app](https://eden.so/?utm_source=x&utm_medium=social&utm_campaign=eden)**.

Put your thoughts on paper (or a screen). Be honest with yourself.

If you’re ever feeling down, mentally, you can bet your money that writing will help you feel better.

It’s damn near impossible to be sad when you can just write about your feelings and ideas.

Here’s what you need to braindump in the notebook:

- Write about your problems
- Write about how you’re feeling
- Write about what you’re currently doing in your day-to-day life
- Write about every single thing you’ve done in the past week (in detail)

Then move on to step 2...

### **2) Find the energy parasites**

Now it’s easy to identify why you’ve felt lost.

Remove energy parasites and energy-sucking tasks that have snuck their way to your life (and don’t deserve to be there).

These can be apps, habits, or even friends and family who keep distracting you from your goals and make you feel horrible for not working towards them.

It will hurt like hell in the beginning but it’s better to deal with it all at once than to keep pleasing them (which will take a bigger mental toll on you in the long run).

Your mind has limited mental bandwidth.

It’s the RAM of your computer (your mind).

It can only handle so much and stay on top of things for so long. If you keep filling your mind and mental bandwidth with tasks that keep slowing you down, you will stay slow and feel horrible until you make the hard decision to remove some of the background tasks that you don’t need in your life.

### **3) Chase a meaningful goal**

Humans are goal-oriented creatures.

We love goals for many reasons.

They give us a sense of control and certainty when everything feels random and uncertain.

The more goals you set, the more control you have.

But the most overlooked part about goals is they reshape your perspective. Your current goals determine what information you pick up and don’t pick up, it determines your current interests. A person who’s preparing for a marathon is going to be interested in recovery, nutrition, and training plans so they’ll start to notice more fitness content in their lives (when it has always been the same).

Your goals are the lenses through which you see life (which is unique to you only).

#### **Set a week-long plan**

Your goal is to establish order in your life.

When you don’t have order, your world goes into disorder.

That’s entropy.

Entropy is a fundamental law of nature. It is the driving force behind chaos.

Everything in this world drifts towards chaos unless you intentionally and consistently put energy towards it to maintain order.

It’s similar as to if you don’t clean your room and fold your clothes every day, then quickly your room will become disorganized. You’ll have clothes thrown on the floor, your wardrobe will be messy and you won’t find your favorite shirt (unless you put effort into cleaning your room every day, your room won’t stay clean and organized).

This is why the first step is to write everything down.

To reorder your life (and therefore mind), you need to become aware of the disorder that’s causing you pain.

Create a week-long plan.

Write every task you want to work on that will help you reach your goal.

You get to design your ideal life here.

Negotiate with yourself.

If you were to have a perfect week, how would that look like?

To be realistic for most people, you would still need to go to work, but after work, what would you want to do?

What would you like to do on the weekends?

Create a plan.

Take control of your life.

Become the person who’s in charge of their own life and don’t let others tell you what to do.

#### **Create a project**

This is my favorite way of achieving goals.

Because a project is just a series of goals strung together and leads to a major outcome.

You have a start and end date. You have milestones. The path is laid out and clear. You just need to take action.

For me, my project right now is called My Life’s Work.

It’s an outline for a book.

I don’t plan on publishing the book, but it helps me flush out my ideas and connect everything to each other.

I can go deep with my processes and systems, write about them, and take small parts of them and share them as newsletters. Now I get to refine my ideas in public (so if I ever decide to publish a book, I already have validated ideas and processes and know what people want to see).

[![](https://substackcdn.com/image/fetch/$s_!YctN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb18411ec-f55b-42b5-a35b-4895bdcd89c5_997x763.png)](https://substackcdn.com/image/fetch/$s_!YctN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb18411ec-f55b-42b5-a35b-4895bdcd89c5_997x763.png)

_This is a rough outline I have at the moment_

Another project I have is to launch a one-person business 6-week sprint cohort.

Again, most of this cohort is being drafted as I write my newsletters.

When you have projects that stretch your mind and force you to take on challenges that are slightly out of your reach, you get into a state of consciousness called Flow.

Basketball players call it “The Zone”.

This is a state where effort feels effortless, things just click, and time ceases to exist.

You experienced this before when you were playing sports, video games, drawing, coding, lifting weights, or running. I don’t want to get too in depth with this concept and idea (mainly because I have a newsletter that I’m writing about Flow), but when you live in flow, that’s where you find the most amount of enjoyment and fulfillment.

> **More fulfilling does not necessarily mean more pleasant.****- Steven Kotler**

When you think about it, you are already disciplined, you’re just disciplined at the wrong things.

You don’t have any trouble scrolling social media for 4 hours.

If you want to become more disciplined, you just need to

You don’t need anyone to tell you to scroll social media for 4 hours a day.

You don’t need to be forced to play video games all day, you do it naturally.

So you are disciplined, you just need the right project, that you’re so excited about and streches your mind and abilities to their absolute limit to keep your attention.

Life is best experienced when you’re sitting at the edge of your knowledge.

### **4) Iterate until you have the life you want**

At the end of the week go through the same process again.

But this time it’s a little different.

Because now you have more clarity on what you want and don’t want in life.

It’s almost impossible to figure out your entire life in just 60 minutes.

But if you keep doing this process, week after week, you gain more and more clarity on what you want to do.

The clarity you gain is the important piece here. It will naturally guide you to where you want to be. But you won’t gain this clarity if you never go through the process of self-experimentation and discovery.

Keep iterating on the process.

Remove the energy parasites that don’t belong in your life.

Do more of the things that bring you fulfillment.

Restructure, remove, and reprioritize tasks to reduce the load on your cognitive bandwidth (this will help you perform better at the things you love).

To create a new life, you must first create a new person, a new program, a new system of beliefs and a worldview that will help you achieve it.

You don’t magically become successful after reaching a goal. You must first become a successful person (mentally), which will feel cringe at first and you’ll struggle with imposter syndrome, but it will only feel that way until life catches up to you and results start to come in.

Thank you for reading.

Enjoy the rest of your day.

- Hussain

**P.S.**

I am thinking of creating a 6-week One-Person Business live cohort.

It’s everything you need to know about personal branding, building your audience, and making your first $5,000 from your business.

If this sounds interesting to you, reply to this email with “I want it”.

If enough people want it, I’ll go ahead and create it.

If not, I’ll just keep my systems for my high-ticket clients.


---

<!-- Archivo original: posts/2026-01-18-the-most-profitable-niche-in-2026.md -->

---
titulo: "The most profitable niche in 2026"
subtitulo: "If you're a smart individual, don't choose a niche. It limits your growth as a human (and it slows down your audience growth). Here's a better method:"
fecha: 2026-01-18T12:13:18.155Z
url: https://hussainibarra.substack.com/p/the-most-profitable-niche-in-2026
audiencia: gratis
palabras: 3612
likes: 28
comentarios: 4
---

# The most profitable niche in 2026

_If you're a smart individual, don't choose a niche. It limits your growth as a human (and it slows down your audience growth). Here's a better method:_

The average human gets 6,000 thoughts a day.

That’s 159,870,000 thoughts for your entire life.

Your thoughts are shaped by your experiences, perspectives, goals, beliefs, dreams, failures, conversations, and everything that has happened to you throughout your life.

You’ve accumulated knowledge and skills and have a method of doing things that no one else has access to.

After I finished my first internship, I realized that the traditional path wasn’t for me.

I didn’t enjoy engineering as much as I thought I did. I thought I would be building skyscrapers and making sure that everything is of the highest quality.

However, I soon realized that corporations only cared about profits. And the people around me (who were going to be me in the future) were all miserable.

So I started thinking about what I’m going to do with my life.

I went back to teaching myself data science again (so I can land a remote job and avoid commuting).

But that wasn’t going to solve the root problem: **Finding work I actually enjoy.**

So I began to think of a way to start my own business (self-employment is the only way to create a life of meaning and fulfillment).

So I started learning social media marketing. Then I moved to SEO. And that’s when I discovered the idea of personal branding.

I bought my first course for $800.

I went broke for it.

A few months went by and I bought a couple more courses.

But the same problem would always show up:

Choosing my niche.

=====

_**Quick announcement:**_

_The One-Person Business Sprint is currently on a 50% early bird sale._

_It’s a 6-week live cohort where you’ll leave with 60+ foundational posts, gain 5,000+ followers, and make your first (or next) $5,000._

_You’ll also get all of my content creation systems, sales processes, prompts, and AI workflows ready for you. All you need to do is copy and paste them to your brand._

_We start on March 1st._

_**[Start building your brand](https://sprint.hussainibarra.org/).**_

=====

# **Picking a niche is outdated advice**

[![](https://substackcdn.com/image/fetch/$s_!WRlp!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff36059f9-1b01-4945-b2f2-aa48aa1614fd_1188x1188.png)](https://substackcdn.com/image/fetch/$s_!WRlp!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff36059f9-1b01-4945-b2f2-aa48aa1614fd_1188x1188.png)

As a kid, I had multiple interests. I was into fitness, astronomy, history, nutrition, business, architecture, art, philosophy, and psychology.

Choosing a niche felt like I was boxing myself.

It killed my creativity.

There’s only so much you can write about the same topic without repeating the same points.

We’re all humans.

_At least that’s what I hope..._

You have a consciousness. You are aware of your thoughts, emotions, and actions. You can create something from pure imagination.

Doesn’t this blow your mind?

When you look at the world through the lens of a creator, you’ll quickly realize how stupid it is to choose a niche.

You are a human with so much potential and capabilities but most people choose to limit themselves to fit in a box.

This is why I don’t _like _calling myself a writer.

Not because I find it cringe.

But because I’m so much more than just a writer, or creator, or copywriter, or email marketer (like what my business coaches say I am).

I like to lift weights. I like to run. I like to read. I like to launch products. I like to explore spirituality. I like to explore philosophy (even though I don’t understand most of what I read because I’m not at the stage where I could understand the concepts they’re talking about. Some also like to overcomplicate simple concepts for the sake of sounding smart).

So when it came to creating content on Twitter, I took an unconventional path:

I stayed broad.

I didn’t niche down.

I talked about whatever I wanted and found interesting at the time. I wrote it in a way that is compelling and gets engagement.

This allowed me to grow faster than everyone else.

Having a niche limits your growth. Not just in terms of social media growth, but as a human. Growth doesn’t only happen vertically (in one discipline), growth happens both vertically _and _horizontally (you learn about other interests which teaches you skills that you can use in your business and life).

Your niche is malleable. It changes as your goals change. Your goals change depending on what you focus your attention on.

When it comes to monetizing and launching a product, I create a simple 3-5 week content plan to educate my audience on the topic.

I start with a basic newsletter (like this one) for the sake of building people’s awareness. Then, as I come closer to launching, the more direct my messaging becomes in my content.

You can talk about whatever you want without taking a bit financial hit.

If anything, talking about your non-money-making interests _helps you make more money _later down the line.

I’m fortunate enough not to have money problems when I started off as a creator.

But if you’re someone who’s struggling with money, that should be your first priority: solve it (for most people, that means getting a better-paying job). This will free up some of your mental bandwidth and create space and energy to think about your brand and business.

You can’t build a sustainable business if you’re operating in a place of survival.

# **The internet allows you to monopolize yourself**

> **There are almost 7 billion people on this planet. Someday, I hope, there will be almost 7 billion companies.****- Naval Ravikant**

In the next section to give a step-by-step solution to help you create your own niche, but don’t take what I say as gosepl.

I want you to extrapolate their meaning and perspective. Open your mind, read what I’m saying, apply it to yourself and make the conclusions yourself. That is how you learn.

I want you to experiment with my method yourself is because if life taught me anything, it’s that nothing in life is permenant. There will come a time when the step-by-step method stops working. However if you understand the principals, the bigger picture behind, the strategy behind the tactic, you can take what I say and apply it to yourself (regardless of time and location) and still see results.

The last reason I want you to experiment with the advice yourself is because I cannot give you all the answers to guarantee success.

You don’t have my mind, you don’t have my experiences, you haven’t learned the lessons that came from the millions of tiny failures, wins and thoughts that have shaped my perspective (and which is almost impossible for me to articulate because they are so deep in my subconscious mind that I’m not even aware of).

But that is the beauty of it.

You have your own experiences, stories, situations, failures, thoughts, and skills that are unique to you only.

As a result, the creator economy allows you to create a niche of one. A niche that is unique only to you and “niche saturation” becomes non-existent. The creator economy is the only economy I’ve found that can never be saturated. No one has the same exact experiences, lessons, perspectives, failures, thoughts as you, and you haven’t lived anyone else’s life.

“But Hussain, I don’t have anything interesting to say”.

That’s not an excuse.

You haven’t reflected hard enough on your life.

You spent decades on this earth. You are already sitting on a wealth of knowledge that you haven’t yet tapped into because you never put yourself in the position to create. Once you start creating and getting involved in the creator economy, you’ll realize just how much you know (and how many people want to learn from you).

If you still can’t think of anything to talk about, go do something interesting and talk about it.

Real-time storytelling is one of the best ways to build an audience.

# **Create your niche of one - The holistic approach to building a business**

> **Smart people get paid to be themselves.****- Alan Watts**

Most people belong to a very specific and narrow niche.

They just don’t realize this yet, so let me explain:

You have many interests, you follow many creators who talk about your interests and you have accumulated information and experienced life in ways no one else can ever imagine. All of this puts you in a category so specific to you, which makes “picking a niche” dumb.

When people tell you to pick a niche, it is to capture your Customer Avatar’s attention and solve a very specific problem they have. But all of this falls apart when you use yourself as the Customer Avatar. Because you have many interests.

Do you only consume one type of content? Do you only watch content about a specific topic or do you watch about many different topics?

2 people can start posting on social media, one will take the conventional path of niching down and the other will take the other approach of becoming the niche, by 12 months, the first one would gain 2,000 followers and the other would have an auidence of 20,000. Give it 3 years and they’ll be at 10,000 followers and the other is at 100,000 followers.

The first one can’t grow as fast because their content is relevant to so few people that the average person (which is 99% of people on social media) can’t understand and so they don’t share it.

But the second creator, because he’s no relevant, he can tap into a wider range of people, they understand his content, like it, share it, and this help spread his message (and reach his Customer Avatar).

Boxing yourself in a niche won’t make you grow faster.

Sticking to one topic won’t help you build more authority.

Being in a niche won’t help you sell more.

At best, you’ll be a glorified search engine.

“But Hussain, those 100,000 followers won’t buy from me”.

That’s shallow thinking.

1. **You are too desperate for a sale.** This tells me you have a bigger problem in your life and you need to solve that first before becoming a creator. Because starting a one-person business is hard, and you can’t build anything sustainable while you’re in a place of survival.
2. **You underestimate the power of a strong network.** Let’s say every person in your audience new 2-5 people who would be interested in your offer, you’ll have a potential market of 200,000-500,000 people (compared to a mere 20,000-50,000).
3. **It is your job to **_**create new customers**_**.** Educate your audience on your topics and interests, raise their levels of awareness, and bring a new perspective to their lives. You might not make $1M in your first year, but if you focus on educating your audience and increasing their state of consciousness, over the course of 5 years, you’ll make $1M (and that is still life-changing money). Not all of your audience is ready to buy now. Educate them. Nurture them. Build trust with them.

At this point, it should be astronomically clear that creating your own niche is the only viable way to create a brand that is both profitable and sustainable.

Here’s how you can create your own niche (and profit from it):

### **1) Outline a book - Your life’s work**

A book is a big project.

This makes it the perfect vessel to document your life’s work.

When you document your life’s work, you create your niche of one.

Your mindset, perspectives, and worldviews should be communicated in a persuasive manner (one of the best ways to do this is to create a mission and use tactical exaggeration to illustrate a point) to attract like-minded individuals, but they are a few steps behind you so you can help them.

Create the outline that will structure your book.

**If you were asked to write a book that will be passed down to your kids, what would you want to include in it so they can live a happy, fulfilling, and meaningful life?**

Your outline will be use to order your mind, heighten your awareness to spot unique and novel ideas for your content.

Use the outline as a guide to consume information.

Use your outline as a content plan for your brand for the next 6-12 months (because that’s how long it takes for your audience to get familiar with you).

Now all of your interests are all interconnected, and any new interest, hobby, or idea you get in the future can also be connected to your book. Your outline will serve as the building block for most of your content, newsletters, threads, carousels, Instagram Reels, TikToks, tweets, and everything else and in between.

The majority of my newsletters and content for this year will be mainly taken from my own book.

With this structure in mind, write to those who are 1-2 steps behind you so you can guide them to a more fulfilling life.

### **2) Write your story**

Your story is your brand.

Your story is what makes you unique.

No one in this world has experienced life the same way as you have. Other had similar experiences, but no one has your upbringing, your education, perspectives, lessons, failures, worldview, philosophy on life, and every tiny thought that has shaped you to who you are today.

You must get clear on your story because you will use it to frame your content.

You can start every piece of writing with a personal story (like I have done in some of the sections of this newsletter).

This alone makes it unique and not shallow (like the majority of the people who try to write actionable content that can easily be generated with AI).

**How to get clear on your story:**

- What made you want to start?
- What were your struggles?
- Where did you reach rock bottom?
- What were the biggest turning points in your life?
- What have you achieved that others see as desirable?
- How did you get there (what were the interests, skills, and perspectives that got you there)?

### **3) Create a mission**

People want to be part of something bigger.

Bring them on the journey you’re going.

The end destination is your goal. The end goal is your ideal lifestyle. That’s where you’re trying to go and lead people towards.

If you don’t know what kind of future you want to live, then try things. Try everything. Try digital nomading. Try the traditional 9-5. Try being this psychotic entrepreneur who works 18 hours a day.

See what you like and don’t like.

Take notes.

Document what you’re doing on the internet.

You won’t know the kind of life you _truly want to live_ until you experience the type of life you _don’t want _to have.

It’s easier to know what you don’t want (from experience) than to guess what you want (from imagination).

What is the bane of your existence? What is the future and lifestyle you want to avoid

What is the life you’re trying to lead people towards?

A mission gives people purpose.

A clear end goal that they can strive for (because that’s the only way humans function). If you don’t have a goal right now, your mind will create problems and give you new goals to chase (we’re wired that way).

### **4) Develop your life’s philosophy**

You need to get people on the same page as you.

Just because you have a mission and a clear end goal, it doesn’t mean you’ll be successful.

You need to persuade people to join your niche.

You do this by creating a persuasive message.

You need to develop a worldview. A philosophy. A way of living a good life.

You must constantly illustrate the importance of your philosophy.

Think back about your favorite creators (not influencers who do silly TikTok dances. I mean creators who educate you and imporved your life), why do you like them so much? How do they make you feel? What kind of message are they preaching?

A philosophy is how you create a movement. And every brand in some way or another is creating a movement.

Your philosophy is your movement; it is the lens through which people will view their world from.

**Your philosophy is the answer to the question “How does one live a good life?”**

1. **Describe your ideal life in detail.** If you had all the money in the world, what would you be doing? What kind of lifestyle are you leading people towards? How is your energy throughout the day? How is your mood?
2. **Create a public enemy**. If everything went wrong in your life, how would your life look?
3. **Lean into your beliefs.** What beliefs do you have that others see as extreme, offensive, or delusional?
4. **List all your topics.** What are the topics, interests, skills, and goals you’ve learned or achieved to help you on the way toward your lifestyle?

This will require you to self-reflect.

Take your time answering these questions. They will serve as the foundation for all of your future content, products, and ideas.

At first you’ll find it hard to articulate your philosophy. It means that you haven’t experienced or thought deeply about the things you’re trying to articulate.

Self-experimentation is your solution. Draw inspiration from personal experiences and give your reasoning.

Facts and information are second-order when compared to personal experience.

When you go through this exercise you’ll quickly realize just how many ideas 1) weren’t yours to begin with, 2) beliefs and perspectives that kept holding you back in life 3) what you actually need to do to self-actualize your life.

This part is what makes you and your brand unique.

### **4) Focus on these 3 things when you’re creating content**

When I first tried to “create my niche”, I would write content that I was only interested in.

Which isn’t bad on its own, but I was missing the bigger picture and that was how my content is related to my audience.

So at the beginning I struggled with slow audience growth, poor engagement, and just posting into the void.

But when you focus on these 3 pillars, your content starts to get more engagement:

**Focus On Education**

You need to raise people’s awareness level.

You do this through education. Educate your audience on their problems. Educate your audience on your solutions. Educate your audience on your way of life.

There’s a reason why every creator starts out with the typical “How To” content. Because it works.

**Focus On Gaps**

Understand the gap that exists between the knowledge you have and the lack of knowledge your audience has.

What do they need to do?

What do they need to know?

What are they struggling with?

There is this concept in copywriting called “meeting your readers where they’re at”.

What you’re doing is you show them that you understand their current struggles.

You relate to their problems and you understand them.

This will also help you focus on what kind of problems you need to constantly illustrate.

**Focus On Importance**

People always need a reason to act.

Your audience is overwhelmed with advice. They already know what they need to do.

But what they’re missing is the reason to take action.

You need to find that motivator. It is the ignition that starts the car. This is easy to find when you look back on your life and figure out what is the driver behind you doing this.

Again, reflect back on your mission.

What is the reason that got you to start in the first place?

Where do you want to go in life?

Why do you want to go there?

Answer these questions and relate them back to the reader.

### **5) When in doubt, zoom out**

If you feel overwhelmed or anxious, stop working.

Your mind has narrowed its focus and you have lost perspective on the bigger picture.

Zoom out.

Go for a walk.

Go for a run.

Lift weights.

Get your body moving.

Reset your perspective.

I’ve never created anything of value when I was operating in survival mode.

Just yesterday, I couldn’t even put two words together when I was trying to write this post.

My mind narrowed its focus and I couldn’t think.

But when I went for my run and pushed myself to the absolute limit.

Ideas started flowing. Clarity struck me like a motherf*cker.

You want to create and operate from a state of calmness and creativity.

Here’s an exercise that helps me reset my perspective:

Imagine seeing yourself in 3rd third-person view.

What advice would you give to a friend? What should your friend be doing? How should your friend do it?

Now zoom out even further, to the point where the Earth is just a dot.

Do you see just how everything is irrelevant? Do you see just how all of your problems are not real problems and they only exist in your mind? Do you realize just how insignificant we are compared to the entire universe?

Reset your perspective my friend

Master your mind.

Thank you for reading.

Enjoy the rest of your day.

- Hussain Ibarra

**P.S.**

The One-Person Business 6-week Sprint is now on a 50% early bird sale.

If you want to create a profitable one-person business in 2026, this is for you.

It’s a 6-week cohort where you’ll leave with 60+ foundational posts, gain 5,000+ followers, and make your first (or next) $5,000.

And, you’ll have all of my content creation and sales automated so you can just copy and paste it over to your brand and start seeing results.

We start on March 1st.

**[Enroll here.](https://sprint.hussainibarra.org/)**


---

<!-- Archivo original: posts/2026-01-24-full-guide-how-to-start-a-profitable.md -->

---
titulo: "Full Guide: How to start a profitable one-person business (in 2026)"
subtitulo: "If I had to start from scratch again, this is exactly how I'll attract an audience and make a living..."
fecha: 2026-01-24T20:48:08.170Z
url: https://hussainibarra.substack.com/p/full-guide-how-to-start-a-profitable
audiencia: gratis
palabras: 3938
likes: 55
comentarios: 4
---

# Full Guide: How to start a profitable one-person business (in 2026)

_If I had to start from scratch again, this is exactly how I'll attract an audience and make a living..._

> _“It is possible now to start a one-person company that would be worth more than $1 billion.”_- Sam Altman

Look around you.

Normal, everyday people, who are no smarter than you, not more talented than you, not wealthier than you, are starting businesses and making a killing from (and they didn’t have any experience in running a business).

3 years ago I saw a guy making $100k/month on X as a one-person business.

He was a normal dude, working 4 hours a day, writing self-improvement posts.

What blew my mind even more is that he wasn’t a special case.

There were many others on X also making $30k, $40k, and $50k as a one-person business.

_“If everyone is making this money, then it must be easy”_, that’s what I told myself 3 years ago.

So I started my one-person business while being a full-time graduate student.

What I didn’t know was that I had no skills, no experience, nothing to brag about.

So understandably, I made only $350 in my first 3 months.

I bought courses, learned new skills, and built a decent sized-audience. Then at the end of my second year, I scaled my brand to $4,000/month.

Last year, I made over $50,000 at ~93% profit margins.

And this year, I’m already expecting to make multiple 6-figures.

The best part about it all?

I get to make a living doing something I love. I don’t run my one-person business because I have to. I do it because I love it.

I wake up every day excited.

Just last week, I was able to go on a trip to Spain. While on this trip, I made $1,000 (without doing any work).

So here’s what I want to share with you today (and honestly, this is the framework that changed everything for me).

First, I’m going to expose why “passive income” is actually keeping you stuck (and why the people selling it don’t understand how humans actually work).

Then, I’ll show you the one skill that makes you irreplaceable in an AI world—the skill that determines whether you thrive or get left behind.

But before any of that works, we need to talk about your mind.

Because if you’re not continuously solving problems, you’re degrading.

Everything (and I mean everything), begins and ends with how you direct your consciousness, and if you can’t get it working for you, it’ll work against you.

And finally, I’ll walk you through the exact framework I use to build a profitable one-person business from scratch. The kind where you get paid for solving your own problems and improving your own life.

# **Your mind needs problems to function**

[![](https://substackcdn.com/image/fetch/$s_!6s94!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa370bb9f-4595-4ba8-9c05-17e819effc6f_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!6s94!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa370bb9f-4595-4ba8-9c05-17e819effc6f_1920x1080.png)

_Flow State is the state of consciousness where meaning, enjoyment, and fulfillment are found._

Problems are infinite.

Once you solve a problem, a new one shows up.

It doesn’t matter how advanced we become as a species, even if we automate all of our work and you have no work to do, your mind will still create problems so that you work.

Our needs will transcend from the physical plane (food, water, and reproduction) to the metaphysical (meaning, love, fulfillment, creativity, enlightenment).

This doesn’t mean that solving them is pointless.

If anything, it’s a good thing.

A good, meaningful, and happy life is lived when one is constantly solving their problems and contributing to society.

When you don’t solve problems, you stay the same.

There’s a concept called entropy.

It is a law that governs the Universe.

It says all processes and systems naturally descend into chaos and disorder, unless external energy is put in system to maintain order.

It is the reason why the world we live in will eventually come to an end.

But there’s also mental entropy.

When you don’t identify problems, set meaningful goals, and improve your life, you are falling into chaos.

Your life becomes boring and meaningless.

Problems give you meaning, a sense of purpose, a way to learn new skills, acquire new knowledge, expand your perspective, and live a good life.

When you solve a problem in your life, you reach a new level.

Problems get more interesting, challenging, and harder.

But you are also a new person.

You have new skills, knowledge, and experience that you can pull from, which makes solving problems fun, exciting, and easy.

It’s similar to a video game.

Completing a level 1 dungeon when you are level 100 is boring (because there’s no challenge. You’re just one-shooting everything) . The opposite is also true. Completing a level 100 dungeon as a level 1 is impossible (it creates anxiety, rage, and frustration).

You need to play at your level, acquire gold, buy new gear, and gain experience so you can level up and take on harder and more interesting dungeons.

The loot is better, the reward is better, the achievement is better.

This is all to say that you need to create your own system (because that’s how you guarantee that it has your best interest at heart).

You create your system by chasing your curiosity, identifying a problem, setting a goal, diving into the unknown, finding a solution, creating products and distributing the value you gained in exchange for money.

Learn to hunt.

Learn to solve.

Learn to build.

Learn to earn.

_===_

_This is getting a bit long, so it feels like a good place to mention a cohort I’m starting..._

_On March 2nd, I’m running a 6-week live cohort where I’ll show you how to start, grow, and scale your one-person business (even if you’re a beginner)._

_It’s currently on a 50% early-bird sale._

_There’s more information about it at the end of this letter._

_[Enroll here.](https://sprint.hussainibarra.org/)_

_===_

# **Chasing passive income is keeping you miserable**

The idea of passive income sounds like a dream.

You sit all day, play video games and money keeps coming in.

But this is the worst thing you can do.

Because you’re human. And humans are problem-solving machines. You’re not designed to sit around all day and do nothing.

Your ancestors were problem solvers.

You are coded by nature to be a problem solver.

If you make passive income and live comfortably, you’ll quickly get bored and start to think of interesting problems to solve. That’s just your mind works.

Your mind is a problem-solving machine.

You always need to have a meaningful problem or goal to chase.

This is the secret to creating work you love, making a living by solving your problems, and living a meaningful and enjoyable life.

Your current problem is that you hate the work you’re currently doing. So you’re trying to make money from other ways so you don’t have to rely on your employer.

The solution is to create work that you find meaningful, enjoyable, and profitable so you don’t have to dread the idea of work.

You find work you enjoy by solving the problems that exist in your life.

# **The one skill that AI can’t replicate (and why it matters now)**

The current educational system we have doesn’t serve us anymore.

It’s too slow at teaching, dogmatic, and most of the skills you’re learning will be replaced by AI in a few years.

If that’s the case, why did we adopt this model?

And more importantly, why don’t we change it?

The current education system we have was by the Prussians to create obedient and disciplined factory workers. Some people from the U.S. went there, saw it, and liked the idea, then they created standardised tests, grading systems, and different school years dictated by age.

You spend 22 years in Tutorial Mode, thinking you’re gaining skills and knowledge, but when you get thrown into the real world, you realize that most of it is useless.

Here’s a thought-provoking line for you:

**The education system doesn’t have your best interest at heart.**

I don’t say this to be controversial or to get a reaction from you. I say this because a system is designed to serve its master.

Since you are not the one who has created, funded, or keeps the system running, then it doesn’t serve you. The system serves those who are at the top, the ones who have the power. Schools and universities are designed to create workers for businesses and governments to keep running.

And businesses and governments don’t want to change it because they want to take advantage of you.

Just look around you.

AI and LLM are taking over the entry-level positions. The skills you learn at university, an AI can do it faster and better than you ever could.

Now, anyone who knows how to write (or even speak) coherently and clearly can write a complex piece of code, design an app, and create a website.

Back in the day, this would have taken a full team of employees made up of a product manager, a software engineer, a UX/UI engineer, a web developer, a web designer, and more.

But all of that is now gone. One person can now produce the same, if not more, than what took a team of 10 a decade ago.

This means fewer job openings, less hiring, more competition, and more layoffs.

For the average person, this is a nightmare.

Why?

Because the average person has low-agency individual.

This is how the average person lives their life (and how I predict their life will look like in the future if they don’t change):

- They get assigned work, they get told what to do, and they don’t create their own goals.
- They can’t identify problems, they can’t set goals for themselves, find solutions, and create a product that serves them and others at scale.
- They always need a master. Someone who tells them what to do. They are nothing but a tool to someone who has more agency than them.
- As AI gets more advanced and skilled, more people will be replaced by them. Unemployment will rise. Governments will start writing universal checks.

Unemployed individuals will live off of the government’s welfare system and the universal checks that it will write. And they’ll get to decide how you live your life (because you didn’t create the system that’s keeping you alive).

That is the path of the low-agency individual.

Low-agency individuals are the same as AI in the context that they both need a master.

Someone who tells them what to do, assigns goals and projects for them.

High-agency people are the complete opposite.

They see the Internet, AI, and LLMs as an opportunity. You have both the minds of Eisntienand Da Vinci in your pocket. With a quick search, you can find any piece of information you need to solve a problem you have.

The Internet and AI are tools for you to gain knowledge, explore the unknown, pursue your life’s work, and make a creative living (in the long run, you’ll make more money than you know what you can do with).

The future belongs to those who create their own systems.

High-agency people identify their own problems, set a self-driven goal, dive into the unknown, search for a solution, error-correct through trial and error (which is a mark for intelligent systems) until they solve the problems, package their solution and contribute back to society.

Then repeat the entire process again when a new problem shows up.

# **The 4 pillars of a profitable one-person business**

[![](https://substackcdn.com/image/fetch/$s_!vXmX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba6fe162-d165-40f9-83ac-78aa3cff4d89_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!vXmX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba6fe162-d165-40f9-83ac-78aa3cff4d89_1920x1080.png)

> _“You can go on the internet, and you can find your audience. And you can build a business, and create a product, and build wealth, and make people happy just uniquely expressing yourself through the internet.”__- _Naval Ravikant

The only way to create the life you so desperately want is to become an entrepreneur.

To become a problem-solving machine.

If you aren’t conscious of your own actions and actively pursuing self-generated goals, then you’re working towards someone else’s goals (which don’t have your best interest at heart).

> _“If you can spend 8 hours building on someone else’s dreams, you can spend 1 hour building your own.”__**- **_Dan Koe

The best way to continuously improve your life is to identify problems in your life, solve them, and share your solution with the world.

You need to learn how to hunt.

You need to learn how to solve.

You need to learn how to earn.

You need to become an independent, self-sustaining, and high-agency person who takes

Again, the best way to do this is to start a business.

Not just any business, you need a one-person business.

Why?

- It is the only business model that takes a holistic approach to life.
- Your business evolves as you grow as a human (which forces you keep solving problems).
- It doesn’t require any startup capital, employees, or fancy office (all you need is an internet connection).
- You get paid to solve your own problems, set your own working hours, and decide how much you earn (yes, you are always in control of how much you’re earning).
- It is impossible to become saturated (because every person is unique and when done right with the steps I’ll give you in the next section, a niche can never be too saturated).
- With AI and no-code tools, you can create a website, design thumbnails, create products, content, film, and edit videos without having any employees (and you don’t need to know how to write a single line of code or use an editing software or even know anything about design). You can choose a template and start editing it.

In the past, individuals had to rely on established institutions to promote their work for them.

Authors relied on the publisher.

Musicians relied on a music label.

Startups relied on venture capital.

But the internet changed the game. It brought the power back to the individual.

You can create content on social media, talk about a specific problem to attract people who struggle with the same problem, sell your solution to them directly without relying on anyone.

When you have traffic:

- You can publish a book without having a publisher.
- You can create music without having a music label.
- You can launch a software company without having outside investment.

The new way of doing business is starting a one-person business.

Here’s how to start one (as a complete beginner):

## **1) Branding**

Branding is who you are, what you do, and who you do it for.

This can all be summarised by creating a vision and anti-vision for your life.

**For You:**

- **Vision:** What is the ideal lifestyle you’re trying to live? If you had all the money in the world, what would you be doing, how long would you be working, what would you be working on? How do you speak, walk, feel, and think? Be specific.
- **Anti-vision: **What is the kind of life you don’t want to live? What is the bane of your existence? How much are you earning? How do you look and feel? If you keep going down the path you’re currently on, how would your life look? Are you happy with how it looks?

**Your Brand:**

- **Vision:** What is the ideal lifestyle you’re trying to help people achieve? How would they achieve it?
- **Anti-vision:** How would

A vision becomes a goal for others to follow and it gives them a clear path on how good life can get.

The anti-vision creates a public enemy. Something that people can rally behind. You need this because humans are a tribal species. It gives them the “Us vs Them” feeling.

This is all important because that’s what makes a brand magnetic.

Your content, posts, newsletters, editing, and colour grading don’t matter if the essence of your brand isn’t magnetic.

You can put lipstick on a pig, but it’ll still be a pig, as the saying goes.

Your brand changes as your goals change and depending on where you are on your journey. This is important because people follow leaders. Strangers on the internet need to see you as a leader. You can talk about

People follow leaders.

Leaders usually follow other leaders.

## **2) Content**

Content is how you attract like-minded people to your brand.

It is the new method of gaining attention (because attention is what everyone is now fighting for).

If you don’t have attention, you don’t have people who look at your content. If people aren’t seeing your content, they aren’t seeing your product. If they aren’t seeing your products, they aren’t buying them. If people aren’t buying your products, then you’re just a starving artist.

The best place to create content is on social media. More than 5.52 billion people are on social media. It’s where all the attention is.

_“But Hussain, I don’t know what content to create?”_

This statement has two components to it, the first is not knowing the format to which you can create your content (video, audio, or written), the second is not having content ideas.

To answer the first question, going a writing-based content path is better, easier, and has a lower-barrier to entry for most people. You don’t need any fancy mics, cameras, or expensive lighting to start. Everyone is a writer. You write daily. You text your friends, you journal, you outline, or write notes so you’re already a writer and you didn’t have an English degree to do all of that, so why would you think you need one now? Even if your interest is more technical, something like coding, writing has nothing to do with writing, writing helps you with your interests. It will help you outline, think, and plan for the future.

Writing is a meta skill.

It is the foundation of every other high-income skill you can think of it.

- Ads = writing
- Tweets = writing
- Newsletters = writing
- Video = Written script
- AI prompting = writing
- Podcasts = better done with a written outline

To answer the second part, your entire life is filled with content ideas.

The girl who rejected you. The exam you failed. The race you won. Every part of your life can be turned into content if you’re aware of your thoughts, actions, and behavior.

The best content is one that talks about a pain point your Customer Avatar has.

Here’s a process I like to use:

- Where is my reader at? What problem are they struggling most with?
- Where do they want to go? What is the solution to their problem?
- What path can they take to reach their goal? How can they apply the solution?

If you’re paying attention, what I just described is a story.

That’s all what content is, storytelling. You’re telling the story of your Customer Avatar on where they are now and where they can be.

Writing one tweet won’t change someone’s life.

But if you write 30,000 tweets and use this storytelling structure every time, you have a very good chance of building a large audience and monetizing it.

## **3) Product**

You need to create a product ASAP.

You don’t need to wait 2 years before you start monetizing. Frankly, it’s stupid if you wait “until you have more proof” before you start monetizing.

Why?

1. You won’t create a $1M product from your first try. But you can definitely iterate on it and get paid from the start.
2. To someone who is two steps behind you, they already see you as the expert. And to make it even better, you already know what they’re struggling with, so you are the perfect person to be helping them.
3. Having a product will help you create better content. Because now, you’ll have an idea on what you can talk about, this will help you nail your messaging in your content (which will lead to faster growth).

A product is nothing other than a systematic solution to a problem.

If you don’t know what product to create, sell a personal system.

- A filmmaker who uses certain lighting presets can sell them as templates.
- A content creator might have a method that helps him beat creative blocks and so they can sell their method to their audience.
- A bodybuilder might have a specific way of approaching training, nutrition, and recovery to fit their own needs and goals, so they can sell their approach to their audience (who also have the same goals as him).

Your personal system can directly help your Customer Avatar (in this case it’s you from 2 years ago) to solve a problem they are struggling with.

If you want to take this a step further, you can add information, worksheets, checklists, and film yourself, increase the value of your product, and charge more.

You can sell the tool and the guide (so people can make the best use out of it).

Smart people sell their sawdust.

## **4) Marketing**

Marketing is persuasion.

- It is how you get people interested in your interests.
- It is how you distribute the value you created to society.
- It is how you get people to take the first step into improving their lives.

Marketing is not evil.

That’s the social programming holding you back.

If improving someone’s life for the better is your definition of evil, then you need to take a hard look at yourself and ask, “Where did this self-limiting belief come from?”

**Marketing is communicating the benefits of whatever you do.**

Marketing is how you get strangers to care.

Marketing is how you get supporters for your work.

Marketing is how you attract higher-quality opportunities in your life.

You used marketing in your life before.

When you told your friends about a book you read, or a movie you saw, or a restaurant you went to.

That’s marketing.

It didn’t feel evil because you were genuine. It should feel the same with marketing your brand, content, and products.

The difference between persuasion and manipulation is your intention.

Persuasion is creating a win-win situation. They receive value, you receive money.

Manipulation is creating a win-lose situation. You get money, they get scammed.

You need to understand that people don’t care about your product. They care about how your product can change their lives.

In other words, what is the transformation of your product, content, or brand?

Pull out a notebook and reflect on these questions:

- How has your product impacted your life?
- If you’re selling a skill, why did you learn it?
- How does your life look after you’ve learned it?
- How did your life look before you learned it?

Make a list of all the benefits you gained (and others will potentially gain) from whatever you’re talking about.

This is your entire marketing plan.

All you need to do afterwards is talk about the problem, then lead people to heaven (the ideal lifestyle).

Use your personal philosophy—the main driver behind why you’re doing something—as your marketing and messaging as to why other people should do it and listen to you.

Thank you for reading.

Enjoy the rest of your day.

- Hussain Ibarra

**P.S.**

The One-Person Business Sprint is currently on a 50% early-bird sale.

After 6 weeks, here’s what you’ll have:

- The exact content system I use (that generated 76 million views in 12 months).
- How I went from 0 to 25,000 followers with no experience.
- The non-sleazy sales system (which helped me add an extra $5,000/mo in recurring revenue to my business as a full-time college student).

And on top of that, you’ll also get my custom AI workflows and prompts to help you move faster and automate your business.

We start on March 2nd.

[Get your 50% today.](https://sprint.hussainibarra.org/)


---

<!-- Archivo original: posts/2026-01-31-i-grew-my-substack-from-0-to-2800.md -->

---
titulo: "I went from 800 to 26,000 followers in 13 months. Here's how (146 lessons learned):"
subtitulo: "Everything I learned after growing my audience to 26,000 followers and 2,800 subscribers."
fecha: 2026-01-31T21:57:27.435Z
url: https://hussainibarra.substack.com/p/i-grew-my-substack-from-0-to-2800
audiencia: gratis
palabras: 2914
likes: 46
comentarios: 2
---

# I went from 800 to 26,000 followers in 13 months. Here's how (146 lessons learned):

_Everything I learned after growing my audience to 26,000 followers and 2,800 subscribers._

In July 2023 → September 2024, I had 800 followers.

October 2024 → November 2025, I had 26,000 followers (across platforms).

Now I’m growing by 1,000 followers/month.

- I don’t use paid ads.
- I don’t send cold DMs.
- I don’t pester people in the comments and spam them with my posts.

How am I doing this?

That’s exactly what I wanna share with you today.

First, I’ll show you how I approach writing and get into the writing mindset (because everything starts with the mind. If you approach writing with the wrong mindset, you’ll struggle as I have for 16 months).

Then I’ll give you advice on how to grow your audience faster and what strategies I use.

Later, you’ll discover how you can turn your writing into income so you can earn a living and live a meaningful life.

And I’ll finish off on how you can automate your processes so you can play this game for the long-term and do this for decades to come.

Don’t take my words as gospel.

What has worked for me might not work for you.

Why?

Because you don’t have my knowledge. You don’t have my experience. I don’t know where you are in your current journey. I don’t know your current situation. I don’t have your skills and you don’t have mine. You don’t have all of my tiny little failures that have shaped my mind, and I don’t have yours.

You are a unique individual.

And that’s what makes you special.

Take what I say, sit with it, experiment, dissect it, and come to your own conclusions.

I had to go through this process myself. I invested over $13,000 in courses and mentorships until everything clicked for me.

I hope this Substack post will help you gain clarity and take a few steps forward to the results you want.

_===_

_Before we begin..._

_If you’d like to get personalized help on how to finally get noticed by the algorithm, get more engagement, followers, and monetize your personal brand._

_Inside the One-Person Business Sprint, I’ll work directly with you to guide you through the entire process._

_You’ll get my systems, frameworks, templates, prompts, and AI workflows to help you scale to 5,000 followers and $5,000/mo in 6 weeks._

_It’s 40% off._

_[Enroll here.](https://sprint.hussainibarra.org/)_

_===_

Let’s begin.

# **How to create a writing system that works (1-39)**

People struggle to find any sort of rhythm in their content and brand because they don’t know how to approach writing.

They think you just sit in front of a computer and write. But that’s only a small part of the writing process.

The majority of my writing is done away from the screen, on my walks, runs, or when I’m lifting weights.

1. Create a folder with your best-performing posts
2. Create a folder with posts, Notes, and Tweets that captured your attention. Use them as inspiration.
3. Writing is mostly done when you’re away from the screen.
4. The act of writing isn’t writing. Writing is a process. The ideation, outline, research, articulation, and writing acts are all part of the process.
5. Set 1 hour a week to write your Notes and short-form content.
6. Don’t choose a niche. Choose a mission instead.
7. Your mission is the ideal lifestyle you’re leading people towards.
8. When you have a mission, every interest, idea, skill, and experience you have can be positioned in a way to help your Customer Avatar.
9. Use yourself as the Customer Avatar.
10. Give your previous, current, and future self advice with your content.
11. You’re struggling to write because you don’t have enough clarity on your idea. Spend more time on ideation and research.
12. Specificity is what separates creators who get noticed from those who don’t.
13. Being a writer and creator is a lifestyle.
14. Working less will help you
15. To have great ideas, you need to consume great content.
16. You don’t need 100 different ideas, you only need a few to build a profitable business and grow an audience.
17. You won’t have a great idea from the first time.
18. Iterating and refining bad ideas is how you create a great idea.
19. Always publish your work. No matter how “imperfect it is”.
20. Give yourself the permission to fail in public.
21. When you publish your work in public, you get feedback. This helps you become a better writer and creator.
22. Your Substack newsletter headline should be your main topic.
23. Break your main topic down into 3-5 sections. Break each section into 1-2 ideas. This is how you create a unique perspective and create Your Niche of One.
24. Use your Substack newsletter to flesh out your ideas.
25. When writing a Substack newsletter, compress big ideas into Notes and short-form content.
26. Create a feedback loop between your Notes and Posts.
27. Read books and take notes.
28. When you feel inspired, write.
29. Write your first draft without judgment.
30. Don’t bury your lead. Start every Note and Post with a bang.
31. When you’re stuck in your writing, think of a quote, a metaphor, a story, a problem, a personal story, or a new perspective.
32. Formatting matters more than you think. Use lists and vary sentence length.
33. Follow copywriting structures. They’re psychology on paper. Here are the ones I use: PAS, BAB, PASTOR, “What, How, Why”.
34. Lean into your beliefs.
35. Don’t be afraid to piss some people off because of your beliefs.
36. If you write to everyone, you write to no one.
37. Create a cornerstone of your “main ideas”.
38. You only need a few winning big ideas to create a magnetic brand.
39. **Underrated way to stay inspired:** Write a book that you want to pass down to your kids.

# **Growth & how to make it consistent (40-75)**

My growth doesn’t come from engaging all day and relying on tricks or templates.

These are band-aid solutions to your problem.

Growing consistently is a skill that you need to learn. You do this by understanding the principles of content creation.

The growth spikes I had were because I was consistently creating great content. If I don’t go viral, I’m still growing. But when my time comes around and I go viral, then the growth becomes exponential.

You don’t want to be chasing trends (because you’ll end up building a massive audience but none of them will buy from you). Your goal is to create great content that speaks to your Customer Avatar and consistently reaching them and building your relationship with them.

1. Content creation is relationship building at scale.
2. Growth has always been hard.
3. Stop trying to be on all platforms at once. Focus on one and once you reach 10,000+ followers, think about going to another platform.
4. Don’t rely on viral Notes.
5. Going viral is digital crack coca*ne
6. High-quality ideas > engagement
7. The people with the highest engagement are often times the most broke
8. It’s not about the size of your audience, it’s about the quality of it.
9. Had a great post? Repurpose it. Write it in 100 different ways.
10. Use Notes to capture attention. Use newsletters to hold and convert attention.
11. The goal of Notes and short-form content is to build an audience.
12. The goal of newsletters and long-form content is to build trust.
13. If you don’t have time to write newsletters, skip them. Focus on short-form and medium-form.
14. Engaging and commenting are the worst ways to grow your audience.
15. Restacking is the new retweets. Find a good performing Note and restack i,t and add your perspective on it.
16. Make use of your previous Posts. Restack previous articles and keep driving traffic to them.
17. Your newsletters are long-term assets. Restack them often.
18. Storytelling is the secret to building an audience and monetizing.
19. If you want to grow fast, leverage your network.
20. When you’re networking, always lead with value.
21. Learn persuasion, human behavior, and psychology. They are the foundation of writing, marketing, and sales.
22. If you have a bad idea, it doesn’t matter how great your writing is, it will fail.
23. If you have a great idea, it will gain attention, engagement, and lead to sales.
24. When you find a great idea, don’t let it go. Talk about it every day until it stops working.
25. Always start your content with your idea. If it is validated and high-performing, go ahead with it. If not, skip it.
26. To write a great post, you need to have a great idea.
27. Review your content at the end of the week. Find what worked and what hasn’t. Cut out what didn’t work, double down on what did.
28. With your content, lead with value.
29. Give information. Sell implementation.
30. Never be loyal to one specific platform. They are all tools for us creators to grow our business.
31. Restack previous Substack Posts. They are long-term assets for your business.
32. Write Notes related to a Substack Post and mention your Post.
33. Don’t promote your Substack publication under people’s posts. You’re destroying your reputation.
34. Audience growth is a skill.
35. Big ideas >>> Following trends.
36. Use lead magnets to accelerate your Substack Publication growth.

Inside the One-Person Business Sprint, I’ll show you my system on how I’m consistently gaining 1M views and 1,000+ followers per week.

[It’s 40% off.](https://sprint.hussainibarra.org/)

# **Turn your writing into income (75-127)**

Growing an audience is one part of your brand. Monetizing it is the second part.

In 2023, I made $20.

In 2024, I made $4,000 with my brand.

In 2025, I made over $50,000 with my brand as a full-time college student.

**Harsh truth:**

**Getting better at what you do won’t make you more money. Getting better at sales will help you make more money.**

Most people’s monetization problem comes from the lack of traffic they have (audience and growth). Once you nail growth and build your audience the right way, monetizing becomes easy because you already have people who are aready to buy from you.

Monetizing is nothing other than solving your audience’s problems and positioning your products as the solution.

**These are the 46 lessons I learned after having 9 launches in 2025:**

1. If you solved a problem in your life, you’re qualified to sell it.
2. Authority is relative. As long as you have more experience and knowledge than your reader, you are an authority.
3. You need to create a product ASAP.
4. To make sales, you need an audience.
5. If you don’t have an audience, you can do manual outreach (warm or cold DMs).
6. The more conversations you have, the more conversions you’ll make.
7. You can sell through DMs or sales calls.
8. The conversion rate with sales calls is higher but they take more time. The conversion rate with DMs is lower, but they take less time. Both work. Choose one and go with it.
9. Validate the problem with your audience before building a product.
10. Create your transformational promise before
11. Solve one problem, in one way, for one specific person.
12. Specificity sells. One problem, one solution, one person.
13. If you don’t know what to sell, sell your sawdust. Look at your daily workflow and ask yourself: “What is something I use every day in my work?” Then sell your process.
14. Your product should help your Customer Avatar achieve their goals faster.
15. Your product can be templates, LUT packs, courses, masterminds, cohorts, paid webinars, tutoring, consulting, coaching, or a service.
16. Add value to your product by building assets. Worksheets, guides, walkthroughs, resources, examples, etc.
17. Test and refine your product with beta-clients.
18. Your beta-clients will give you the testimonials you need to build social proof.
19. If you don’t have social proof, turn yourself into a case study.
20. You are your best case study. Your readers see themselves in you.
21. After every product iteration, increase your price by 20%.
22. Break down your high-ticket coaching into smaller, lower-ticket digital products. Your goal is to create an offer suite and serve your audience across all levels.
23. When creating your product, write the curriculum first.
24. If you don’t explicitly tell your audience to buy from you, they won’t.
25. Just because you have a product, it doesn’t mean people will buy it. You always need to promote it.
26. Track how many posts you wrote, how many CTAs you made, and how many people bought from you last week.
27. Once you have a product, it’s all about traffic - how many people see your product.
28. You are in control of how much you make.
29. Don’t quit your job until you’re making at least 50% of your income with your business.
30. Build your landing page before you build your product.
31. Give yourself 4 weeks to build your product. In those 4 weeks, promote your product.
32. Always reward early buyers.
33. Shorter 4-7 day launches are more profitable than longer launches.
34. In launch week, send daily emails.
35. Always build tension before you go into launch week.
36. Launches are like an elastic band. The longer and harder you pull, the bigger the snap.
37. The more tension you build, the more you make.
38. The more emails you send during launch week, the more money you make.
39. Shorter, personal-story-driven emails are better for sales than 5,000-word newsletters.
40. The goal of a launch is to make as much noise as possible. Promote everywhere. On social media, emails, and DMs.
41. If people are surprised that you’re launching, you failed at marketing.
42. Launch 1 product per month. MINIMUM.
43. Monetizing your Substack newsletter is the best way to stay broke.
44. If you don’t sell your own product, you will be at the mercy of a platform.
45. If you don’t know how to sell or how to build a product, [invest in your self-education.](https://sprint.hussainibarra.org/)
46. The writers who make the most are the ones who have one great product.
47. 1 great product >>> 100 bad ones.
48. To make money fast, sell a service. To make money while you sleep, sell a digital product.
49. Never say, “How can I make more money?” Always say, “How can I build more leverage?”
50. When monetizing, you’re always making a decision between money now or more money later.
51. If you solved your problem, you are qualified to sell the solution.
52. You don’t need anyone’s permission to monetize.
53. The internet is permissionless leverage. Create products, build leverage, help people, and make money.

If you’d like to create a simple, yet hyper-profitable product in 2-3 weeks, I’ll show you how to do it inside [The One-Person Business Sprint](https://sprint.hussainibarra.org/).

# **Systemize everything (128-146)**

I would have lost my mind if I had to always start from scratch. This is why for the last 2 months I’ve been obsessively creating systems and templates for every part of my work to help smooth the process, move faster, and reduce friction.

But before you think of systemizing anything in your business, always try to eliminate it. There’s no point in being efficient at something that is pointless. Your goal is to free up as much time as possible so you can do the things you enjoy.

1. Create SOPs for your writing process and monetization.
2. Create a content schedule.
3. Set a weekly newsletter cadence.
4. Turn your clients into case studies.
5. Record every call you have with your clients.
6. Let AI use the transcript of your calls to find problems your clients have.
7. Build assets (prompts, workflows, and systems) for your business. You can later sell them or give them to your clients.
8. Focus on removing tasks as much as possible.
9. You only need to do 2 things every day: Write content and promote your product. Everything else is noise.
10. For your launches, write out the dates for every email you need to write.
11. Batch write your emails. You don’t want to wake up in a panic to write an email.
12. If you did the same thing twice, find a way to eliminate, automate, or delegate the task.
13. Create prompts and templates for everything in your business.
14. Always ask your audience about their problems (in your welcome email, every article, inside your products). The more data you get, the better your message becomes.
15. Don’t ask your clients for testimonials. Turn them into case studies. Transcribe your call with them, then ask AI to create a case study for you.
16. Spend time learning how to create great prompts.
17. Set aside 1 hour a day to respond to client work.
18. Set aside 1 hour a week to respond to emails and reply to comments.
19. Plan out your launch. Write out the dates for each post and prepare ahead of time.
20. Don’t outsource your creativity to AI. Outsource mundane tasks.
21. If you outsource, you need to be okay with a drop in quality.

# Final words

The problem most beginners make is they try to do everything at once. You can’t. Apply these lessons one by one. Identify your biggest problem - is it growth, monetizing, or creating systems? - then try to solve it.

Only once it’s solved try to apply a different lesson.

Otherwise, you’ll be working a lot, creating a lot of spin, but there’s no movement, no progress, and you’ll burn out.

And if you’d like to skip the entire journey of trying to figure it out on your own and want to skip beginner’s hell.

You can enroll in The One-Person Business Sprint.

It’s a 6-week live program where I’ll help you scale your brand to 5,000 followers and $5,000/month.

You’ll get my templates, systems, AI workflows, prompts, and personalized help the entire time.

It’s currently on a 40% early-bird sale.

[Save your seat here.](https://sprint.hussainibarra.org/)

We start on March 2nd.

Enjoy the rest of your day

- Hussain Ibarra


---

<!-- Archivo original: posts/2026-02-14-how-to-turn-your-personal-problems.md -->

---
titulo: "You have a $100K product stuck in your mind (here's how you can extract it)"
subtitulo: "The problems you've already solved are worth $100K"
fecha: 2026-02-14T12:15:38.076Z
url: https://hussainibarra.substack.com/p/how-to-turn-your-personal-problems
audiencia: gratis
palabras: 3481
likes: 31
comentarios: 3
---

# You have a $100K product stuck in your mind (here's how you can extract it)

_The problems you've already solved are worth $100K_

Most people treat jobs as a survival mechanism.

They do it to pay the bills and live. Nothing more. Nothing else.

That’s the observation I made when I was a kid.

Everyone around me hated their jobs and wanted to quit. They wouldn’t say it, but their actions confirmed it. They come home tired, don’t have the energy to

It was clear to me that getting a normal job isn’t the way to living a fulfilling life. Certainly, it’s not the path to wealth like what everyone told me when I was a kid (because none of them got wealthy from their jobs).

So to avoid falling into the same loop hole that everyone else so seemlessly accept and refuse to do something about it, I started creating content on social media in 2023.

My first 16 months were hell. I invested over $5,000 in courses and made less than $1,000.

(_Not exactly how I imagined the path to wealth would be like._)

But then in 2024, I became a ghostwriter for health coaches. I was making $4,000 a month while being a full-time graduate student. The time I used to spend creating my own content and building my own audience was now spent creating and building other people’s brands.

I found myself trapped in a new, glorified job.

Instead of working paycheck to paycheck, I was working invoice to invoice. Worked on projects I didn’t care about. People I didn’t align with. For the money that was “okay”.

I wasn’t very different from the average person.

So in the beginning of 2025, I shutdown my ghostwriting agency and created my own products.

I made ~$50,000 that year, operating at ~93% profit margins.

No employees. No bosses. No headaches.

I had complete control over my time, work, and freedom.

Even for this year, I have a goal of making $120,000+/year.

Hopefully this paints the picture that this isn’t a get-rich-quick scheme, where I’ll promise you to make $1,000,000 overnight as a complete beginner.

Now, if your goal is to start an agency with 50 employees and scale to $1M/year, and only take home with you 10%, then by all means, go ahead and do it.

I’m not interested in that kind of business. I’m building my business around one key concept: Freedom.

So if you are one of the people who want to:

- Be in complete control over how much they’re earning
- Create value and, in return, become valuable in the world
- Set their own hours, create their own projects, and pursue their life’s work

Keep reading this letter.

Because to do so, you’ll need to have complete control over your time, earnings, and work.

It’s liberating once you realize that if you can make $1, you can make $1,000. If you can make $1,000, you can make $10,000 or even $100,000 with a simple product.

I might have self-limiting beliefs by not saying that you can make $1,000,000, and that’s something I need to work on, but you get the idea.

Your life will change once you realize the amount you’re making right now is completely fair. Because you are always in control of how much you can earn. If you stack skill, create value, and distribute your value to society, then you can always make more money.

=======

_Before we dive in..._

_Doors for The One-Person Business Sprint close in 16 days._

_It’s a 6-week live cohort with personalized feedback and guidance to help you gain 5,000 followers and make $5,000 (even if you’re a complete beginner)._

_You’ll be getting my exact systems, prompts, and workflows that helped me gain 80M+ views, 26,000 followers in 13 months._

[Reserve your early-bird seat](https://sprint.hussainibarra.org/)

=======

# How To Build & Sell Your Product

> _“Learn to build. Learn to sell. If you can do both, and you’ll be unstoppable.”- Naval Ravikant_

Everything around you right now is a product.

In fact, you’ve already purchased hundreds, if not more.

That means you’re overthinking it.

From the chair you’re sitting on. To the phone you’re currently using. The app you’re using to read this letter. These are all products created by businesses (some can even be one-person businesses).

Now, I’ll assume that you’re a complete beginner, and you have never created a product or even successfully marketed one before.

In my eyes, this is the best progression anyone can take (and one I took myself):

- Start by building an audience (because it’s a free and high-leverage source of traffic)
- Become an authority in your space by pointing out the problems and showing why they’re stuck.
- Create a “personal system” that solves their problems and you can test it on other people.
- Take notes and feedback from beta-testers.
- Turn your “personal system” into a digital product
- Iterate on your product until you’re making, $10,000, $100,000 or $1M

The key question here is, what is a “personal system”?

A personal system is your unique take on an idea, addressing a problem, or solving a problem.

A good example of this is my cohort, The One-Person Business Sprint.

It’s my way of tying my entire brand together. From my Customer Avatar, to writing content that build an audience, to an offer that I can easily sell and market to them, collecting social proof, and getting the flywheel turning.

My system can easily be turned into a high-ticket ghostwriting service, a 1-on-1 coaching, group coaching, or even products that I can sell to executives, founders, health experts, coaches, and not just writers and creators.

Since we’re not doing services, all you’re left with are educational products.

Because just giving people your system is not enough. You’ll need to also educate them on how to best use the system so they can get value from it and solve their problem.

You want to teach people how to fish _and _give them the fishing rod as well. This is how you help humanity as a whole take one step forward and make a positive impact in the world.

Many people have a bad stigma with courses, but they don’t realize that education is the cornerstone of a good life. Education is an important aspect of your personal development. It is how you prepare yourself for a future that schools can’t keep up with. Education that is not found in school is the source of wealth not found in traditional employment.

In the past, we used educational products (schools, universities, books) to pull people out of poverty.

In today’s modern world, we also use educational products (courses, seminars, workshops, cohorts, communities, and bootcamps) to continue learning, increase our earning potential, and make our lives easier.

The Creator Economy is decentralized learning.

It is the new school system.

Learning is voluntary.

Consumers (viewers and followers) vote and choose who they give their attention to. They decide what they want to learn, how fast they want to learn, and how often they learn. Value Creators are decentralizde teacher. Creators, not influencers, creators who use their skills, unique perspectives, and personal experiences to create new paths and pass down their knowledge that allow you to take advantage of new opportunities.

I can write an entire book on the importance of education (in all forms, not just traditional) and answer all your objections, but I’ll let you think it through and discover the answers yourself.

Educational products are the future, in my opinion.

Why?

- People will always want to solve their problems.
- To build a business or gain a promotion, you need to educate yourself, learn skills, and be able to apply them to succeed.
- With AI, new knowledge, technology, and tools are being created every day, and it is the new way to future-proof yourself from being replaced by AI.

Educational products come in the form of courses, cohorts, or software.

They are the ultimate high-leverage products. You build once and sell them as many times as you’d like.

## Your Personal System Is Your Product Idea

The Creator Economy is actually the Economy of personal systems.

Everyone has their own unique method of solving the problem and consumers buy from those whom they like, trust, and can relate to.

The problem is that most people try to solve problems they don’t know anything about.

Smart, successful, and profitable creators sell their sawdust.

That means they always sell something they’re already doing and know other people want it.

Look at your workflow:

- What do you do on a daily basis?
- What is something you always use?
- How do you work?
- What does your process look like?

If you’re a filmmaker, you might have presets and templates for your video editing.

If you’re a website designer, you might have a template for creating landing pages for yourself.

If you’re an athlete, you have a training, nutrition, and recovery schedule to help you stay on track and keep making progress.

If you’re a programmer, you might have certain libraries that you always use for any project you start.

If you’re in sales, you might have a sales script, a method to handle objections, and you can teach them to others.

In other words, to create a profitable product, solve a problem in your life, create a system to help others solve the same problem, teach them the system in the form of a digital product, course, cohort, or coaching.

The future belongs to those who can create and distribute value to society.

When you do this, you can control your time, your work, and how much you earn.

Here’s how you can create a product:

## Nail your marketing strategy

To create a product, you don’t start with it. You start with marketing.

### 1) The Big Problem

Every profitable product solves a problem.

Most people solve “nice to have” problems. These are problems that aren’t painful enough. So as a result, they keep getting the usual response of “This looks nice, I’ll think about it.”

But if you were solving a problem painful enough, your audience wouldn’t care about the price, and they’ll buy as soon as they see it.

So how do you know what problems to solve?

**The 3 Eternal Markets**

This is where the most burning and profitable problems exist.

- Health
- Wealth
- Relationships

These problems will always exist. It doesn’t matter how good AI gets or how smart we become, or even if you solved all of the problems in your life, your mind will just create new ones (because solving problems is an infinite game, and it is the only way to live a fulfilling and meaningful life).

### 2) The Big Desire

People want to go from pain to pleasure.

You addressed the pain.

Now is the time for pleasure.

In my experience, I found people are always after 3 things in life:

1. **Power:** People want to influence and command others.
2. **Status:** People want to be known and respected in their society.
3. **Wealth:** They want to increase their wealth to enjoy the pleasures that come from life.

This is what every human on earth is after. This is what our ancestors used to chase to signal success. It’s always power, status, and wealth.

Your product always gives your audience one of these 3 domains.

When I started selling my ghostwriting service, I thought I was helping people grow an audience, but prospects didn’t really get what I was doing. Keep in mind, these people were professionals. Decades of experience and 1,000s of hours in clinical practice. But when they tried posting on social media, they felt like they were beginners. They weren’t being heard or valued.

And that’s when I figured out my problem. I was selling audience growth to people who wanted status. In real life, people knew who they were, but on social media nobody knew them or even cared about them. That was my entry point.

Your product should do the same as well.

The way you frame your desire is entirely dependent on who your customer avatar is ([you can read this letter to find your customer avatar](https://hussainibarra.substack.com/p/the-most-profitable-niche-in-2026)).

This is why I highly suggest speaking to your audience.

Because you can go ahead and spend 2-3 weeks creating a marketing plan all by yourself without any real data, but you’ll be disappointed when you realize that your audience doesn’t want it.

I recently got on a call with a friend who was doing market research and his goal is to interview 50 people. 50. You don’t need to do any interviews, if you don’t want to (but they are highly effective), you can just send 50-100 DMs to people in your network or audience and ask them about their problems and desires. They will tell you exactly what they want. All you’ll need to do is go ahead and create it for them.

### 3) Building Your Curriculum

This is where it’s very easy to go wrong.

In my case, back in December of 2024, when I was still a ghostwriter, I tried to create a social media writing course. The idea was simple: help creators and writers build their audience on Twitter. The goal was to cover tweets and threads (since those were the 2 main forms of content back then). But it quickly got blown up into a mega course. Before I knew it, I was covering branding, engagement, copywriting, tweets, threads, newsletters, long forms, products, and launches.

It was a mess.

A common misconception people have is they think they need to _add more _to create value.

But if your product is too long, nobody will follow through with it. And if they don’t finish your product, then they don’t get the transformation you promised.

No transformation, no value.

So the goal isn’t to add more. It’s to give them exactly what they need and nothing more.

The easiest to do this is to break down the transformation (from pain to pleasure), into 3 major steps. These are your modules. Each major step gets broken down to 3-5 smaller steps. These are your lessons.

If you’re struggling to find the major steps, reflect on your personal system.

- If you had to start over as a beginner and build it from scratch, how would you do it?
- What would you do differently to get to where you are now faster?

Anything that doesn’t fit into the transformation directly gets turned into bonus material, a new product, a lead magnet, or content.

Bonuses are there to help with speeding up the transformation. As I said, you don’t want more information. People want speed, save time, money, and effort.

Bonuses can be (but are not limited to):

- Prompts
- Tutorials
- Examples
- Checklists
- Templates
- Workflows
- Swipe files
- Worksheets

### 4) More Marketing Firepower

In a perfect world, you will only need to talk about Hell and Heaven. Big problem and big desire. But we don’t live in a perfect world. Your product usually solves many problems at once and gives you many pleasures at once. This is where everything that doesn’t really fit into the big problem or big desire goes to.

This will be especially helpful for your marketing and content creation.

Because if you just talk about the same topic without any novelty, it’ll become boring and people will stop consuming your content. But if you attack the problem from different angles and perspectives, now you can attract more people to your product and change people’s lives.

This section is the easiest to fill because all you need to do is reflect on your life.

- Where were you before applying to create your personal system?
- How did your personal system change your life?
- What made you want to change in the first place?
- How did you discover your personal system?
- What results have you seen?
- Why are you still doing it?
- How does life look now?
- Why should others also do it?

You can go as deep as you want but you get the point.

You won’t necessarily use these for your product itself, but this will give you more marketing firepower to help with your launch, content, and create more persuasive messages that attracts people to your product.

Speaking of launching...

## Launching Your Product

Most people spend 2-3 months building a product only to make $0.

Why?

Because they never talked about their product or even launched their product the right way.

You were silent the entire time. Made only 1 post on their timeline, then wonder why nobody bought.

This is why I take the opposite approach.

I start marketing the product _as I’m building it (or even teaching it)._ My first cohort, The Modern Creator, I was creating the curriculum as I was teaching it. All I had was the outline and the idea.

The reason I take this approach is that it’s better to have the feedback of knowing if it will be a success or not before you go ahead and spend 2-3 months of your life building a product that nobody wants.

To launch a product successful, you need to understand your audience’s awareness level (and where the majority of people are at).

### The 5 stages of awareness

[![](https://substackcdn.com/image/fetch/$s_!68kU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F68860bd3-df0a-431d-a133-73b52ebdb0b7_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!68kU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F68860bd3-df0a-431d-a133-73b52ebdb0b7_1080x1080.png)

1. **Problem Unaware**: These are people who don’t even know they have a problem.
2. **Problem Aware:** They know they have a problem, but don’t know that a solution exists
3. **Solution Aware:** They know they have a problem and a solution to their problem exists.
4. **Product Aware:** They know that you have a solution that can solve their problem.
5. **Most Aware:** These people are the most likely to buy from you. They know you. They like you. They trust you. They are just waiting for the right chance to buy from you.

80% of your audience is in the Problem Unaware and Problem Aware stages.

Your goal is to edcuate your audience on the problem and topic you’re solving to increase their awareness level. This is how you maximize the amount of sales you make.

For the sake of brevity, I’ll keep this section short. Since you already have a lot to do.

Start promoting 3-5 weeks before the start date of your product (or when doors close, however you wanna look at it).

Write beginner-level newsletters introducing your audience to your concept. You need to meet them where they’re at. That means you’ll assume they’re a complete beginner (because that’s where the majority of your audience is).

You wouldn’t start by teaching someone quantum physics if they don’t know anything about physics or math in general. You’ll start with basic maths, then calculus, then classical physics, electricity, magnetisim, until they’re skilled enough and have the knowledge base to absorb and comprehend what you’re talking about, you can talk about quantum physics.

Soft promote your product in your newsletters in the first 1-3 weeks--you can do it right after the intro and/or at the end of the newsletter (like what I’m doing in this one).

Here’s a simple structure you can use:

> _“If you’re struggling with PAIN 1, PAIN 2, PAIN 3.PRODUCT NAME is currently on a 40% early-bird sale.Sales ends on CERTAIN DATE.Enroll here.”_

Then plug the newsletter everywhere, under your best-performing tweet for the day, at the end of your threads, carousels, or reels.

Your goal is to make as much noise as possible.

In the last 7 days, go full price, send daily emails, and make direct calls to action to buy your product. Send DMs if you need to. Make sure you always have some sort of scarcity and urgency baked in to add additional marketing firepower.

**Trust the f*cking process.**

In your first week, sales will be slow. The second and third, sales will start to pick up. But the majority of your sales will come in the 7 days. In fact, in the last 48 hours, you’ll question your sanity by the amount of sales you’ll make.**

_Obviously, this depends on the size of your audience and the amount of traffic you are able to generate._

This is why I say learning how to go viral, build an audience, and generate traffic is the greatest skill you can have (because when you have a product, your ability to make $1,000, $10,000, or $100,000 per month entirely depends on how much traffic you can generate).

> **If people are surprised to hear that you’re launching, then you failed at marketing.**

This is how I’ve been able to make $5,000 in my current cohort (and still, I have 2 weeks left before doors close).

Thank you for reading.

Enjoy the rest of your day.

- Hussain Ibarra

**P.S.**

Want me to help you create and launch your product?

The One-Person Business cohort starts in 16 days.

In 6 weeks, you’ll gain 5,000 followers and make $5,000 with your product.

Early-bird sale ending in 9 hours.

[Enroll here.](https://sprint.hussainibarra.org/)


---

<!-- Archivo original: posts/2026-03-16-most-high-income-skills-will-be-irrelevant.md -->

---
titulo: "Most high-income skills will be irrelevant in 10 years (learn these 4 skills instead)"
subtitulo: "How to future-proof yourself and thrive in the next decade"
fecha: 2026-03-16T18:21:51.124Z
url: https://hussainibarra.substack.com/p/most-high-income-skills-will-be-irrelevant
audiencia: gratis
palabras: 4160
likes: 4449
comentarios: 265
---

# Most high-income skills will be irrelevant in 10 years (learn these 4 skills instead)

_How to future-proof yourself and thrive in the next decade_

> _“AI will replace 50% of white-collar jobs in the next 2-5 years.”Dario Amodei, CEO of Anthropic_

I’m genuinely scared.

I can’t help but notice how good AI has become.

And I know, many people are sick of hearing this to the point where they started tuning out and not pay attention anymore.

But now things are different.

Software engineers outsource their entire work to AI. Normal, every day people are building million-dollar tech startup companies without knowing how to code. Accountants are getting replaced by AI.

This opens up the questions: “What do we do then?”

If AI can write any code, create any software, solve any math problem, and create any art, what do we do then?

How will the structure of our society (that was built around work and the identity we adopt through our work) change?

How will humans find meaning in their lives when they don’t have anything to do?

After all, most people derive their worth and sense of identity from the work they do.

And that is what I wanna share with you today.

Why AI is different now compared to 3-4 years ago (and why you need to start paying attention to it).

The jobs that are currently getting replaced (we’re talking about white-collar jobs that we thought were impossible to get replaced but are the first ones to go). And how high-income skills are no longer valuable.

Then I’ll share with you the 6 domains that humans use to generate meaning in their lives.

Lastly, we’ll end with 4 skills that you can learn to future-proof yourself.

Let’s dive in.

# Why AI is different now

The first time we got to use AI was back in 2021-2022.

ChatGPT just came out, and it was mostly a gimmick.

It would hallucinate, make mistakes, and overall, it just wasn’t that smart (at least the average user didn’t know how to make it work).

But in the world of AI, 4 years is ancient.

To truly understand this, you need to understand just how much progress we have made in the last few years.

[![](https://substackcdn.com/image/fetch/$s_!LS0B!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1238634c-2869-4299-b8e3-06eec10a658d_896x1190.png)](https://substackcdn.com/image/fetch/$s_!LS0B!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1238634c-2869-4299-b8e3-06eec10a658d_896x1190.png)

_Credit: [ourworldindata](https://ourworldindata.org/technology-long-run)_

- 2018: GPT-1 basic language tasks
- 2020: GPT-3 high school level reasoning
- 2022: GPT-4 90th percentile on SAT, LSAT, and medical exams.
- 2025: GPT-5 got the IMO Gold Medal

But what’s scary is something that happened in Feb of 2026. OpenAI, the company that created ChatGPT, has released its newest model, ChatGPT 5.3 Codex, and when they released it, this is what they said:

[![](https://substackcdn.com/image/fetch/$s_!g1D5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5e6b871-1905-4d93-abf5-5993493f009b_726x142.png)](https://substackcdn.com/image/fetch/$s_!g1D5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5e6b871-1905-4d93-abf5-5993493f009b_726x142.png)

_Credit: OpenAI documentation_

**This is the first time we saw an AI model create itself.**

Jensen Huang predicted this back in 2024:

> _“The future of coding language will be our native language.”- Jensen Huang, CEO of Nvidia_

If AI is so smart, then why should you learn how to code? Why can’t you code with just plain English, Chinese, or German, or whatever language you speak?

With how smart AI models have become that’s finally possible.

Now, software engineers outsource their entire work to AI. And it makes sense why they would do it.

AI can write code faster than humans. It makes fewer mistakes. It remembers a lot more things than software engineers. The cost of producing code is now cheap.

This is exactly what happened now with the coding industry. We’re seeing a boom in “Vibe Coders”, people who know nothing about coding or tech, but they have an idea for a product and speak to AI in plain English about their idea and the AI handles all the technical parts.

The Vibe Coding industry is now $3 billion and experts predict that it will reach $30 billion in the next 6 years.

Coding as a skill is no longer valuable. A skill that is far more valuable now is marketing. Getting your product in front of more people. Tech companies are now shifting their budget away from the engineering departments and giving more money to marketing and PR. Because their bottleneck is no longer a product problem, they now need more customers.

Hell, I’m using AI to help me with my thesis, I’m talking about finding key points, spotting insights that I’ve missed, and even writing my code.

Even [my last thread](https://x.com/HussainIbarra/status/2032838342103150703?s=20) was written 80% by AI.

I had the idea and the general outline in my head when I was on a run. Gave AI simple instructions on what to do and boom. A first draft written in 2 minutes. Then I spent another 30 minutes editing it (but that’s just because I’m a perfectionist).

The idea of “will AI replace humans?” isn’t even a question anymore. It’s a matter of _how fast AI will replace humans._

# What’s happening with AI isn’t something new

> _“You won’t lose your job to AI, you’ll lose your job to somebody who uses AI.”- Jensen Huang, CEO of Nvidia_

What’s happening now isn’t anything new. It’s always been part of our history.

When the printing press was invented, monastic scribers (people who were highly skilled and whose entire job was to hand-copy books to preserve them) were the first ones to be replaced. These were highly trained people who spent years mastering their skills. It was also a very prestigious job. But when the printing press became a thing, they were no longer needed. All of a sudden, you can now copy in a matter of seconds.

[![](https://substackcdn.com/image/fetch/$s_!2OV5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2c540700-3941-4094-b63d-10b77e72b843_1024x576.jpeg)](https://substackcdn.com/image/fetch/$s_!2OV5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2c540700-3941-4094-b63d-10b77e72b843_1024x576.jpeg)

The same thing happened with the mechanical reaper, thresher, and plow. They dramatically reduced the number of workers on the farm. What required dozens of people could now be done by a handful.

Later, we saw a similar thing happen with industrial work. Humans were replaced by machines that never ask for a day off, a pay raise, or complain about too much work.

And now it’s happening with AI. People are getting replaced by technology.

- **Customer service & call center agents:** AI chatbots handle these at a fraction of the cost
- **Data entry & administrative roles:** highly repetitive, easy to automate
- **Paralegals & legal researchers:** AI can review documents and case law faster and cheaper
- **Junior analysts & financial roles:** pattern recognition and report generation are AI strengths
- **Radiologists & medical diagnosticians:** AI already matches or exceeds human accuracy in reading scans
- **Copywriters & content creators:** generative AI produces text, images, and video at scale

Technology has (and always will) replace humans. It’s part of our evolution. As long as there are tasks and things we don’t want to do, humans will find a way to outsource them or automate them.

That’s what we do. We are problem-solvers to our core.

One thing I learned when I was researching about this topic is humans are f*cking resilient.

Sure, 50% of the white-collar jobs are getting replaced. But we’ve always found a way to get past this trouble in the past and nothing will be different from now.

If anything, technology only enables those who have high sovereignty.

People who set their own goals, solve their own problems, and don’t rely on others to give them what they want.

AI will help accelerate the progress these highly sovereign individuals make. AI will help them increase productivity, create more, think harder, take on more interesting and creative challenges that weren’t possible before.

We’re moving away from technical work.

Being a specialist is meaningless now.

# The future of society when work is meaningless

There’s a massive flaw in the AI story.

A quick recap on the AI story that’s currently being played out:

- Humans build technology
- Technology makes our work easy
- Humans have more time to build better technology
- Eventually, humans built AI
- AI starts doing low-level admin work
- AI gets smart enough to do high-level work
- Humans get replaced with AI
- AI does all the work, humans have no jobs

That’s basically how the story ends.

Humans have no jobs and that’s it.

But if you think about it, the story stops at the most important part.

What happens _after humans get replaced?_ How will we survive? How will countries and economies flourish?

Because after all, the reason why our economies continue to grow is because we have money to spend. But if we have no jobs, how can we earn money?

My prediction is that we will see 2 groups.

Group 1: Sovereign individuals who set their own goals and create all the wealth in societies.

Group 2: Ordinary people who will rely on the universal basic income that governments provide

The problem is, Group 2 has no agency. They don’t have a say in how they live their lives, the work they do, or the goals they achieve. Because they can’t rely on themselves. Being in group 2 sounds amazing until you realize that this system (universal basic income) doesn’t actually serve your best interest. Because you’re not the one funding it, Group 1 is the one funding it (they’re paying the most in taxes).

If your entire life is dependent on someone else, then that person has the say in what you do and must obey.

If you don’t set your own goal today, you will be assigned new ones in the future and you’ll believe them.

If you do not solve your own problems, you will be told what problems to solve.

If you do not set your own routine, you will be assigned one.

If you don’t know what you want to do, someone else will come along and tell you what to do.

The world is an efficient place.

There is no place for “useless” people.

If you think you are useless, other people will come and make you useful to them.

### The 6 stages of human life

[![](https://substackcdn.com/image/fetch/$s_!UHsv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe9666066-6642-4493-88f4-9baaebe0fc0b_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!UHsv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe9666066-6642-4493-88f4-9baaebe0fc0b_1920x1080.png)

Traditional jobs aren’t all bad.

For the majority of people, a normal 9-5 is the most logical path. It nails all 6 domains of life that is required to live a good life.

**1) Identity**

When you ask someone, “Who are you?” or “What do you do?” almost everyone will reply with what they do for a living.

Engineer, artist, doctor, lawyer, accountant.

Their identity is rooted in their jobs. Work is now the core of how you see yourself and how society sees you.

**2) Structure**

This saddens me a bit, but work also gives people a routine to follow. Work from 9-5. 5 days a week. 2 days rest. Repeat for the next 40 years. Everyone has a routine. For most, it’s the traditional life I just described. For others, their routine is having no routine. Nonetheless, a routine helps organize your mind, life, and goals. It structures your day in a sequential order, something to always look forward to (or do). But the problem is that most people don’t enjoy the routine they were assigned (from their jobs). Which is why when they retire, they find it psychologically hard to do nothing. If you don’t create a routine you love, you will be assigned one.

**3) Social Connection**

Work is where most people find their tribes. When you were still in school, you had a ton of friends. But when you become an adult, making friends becomes extremely hard. The reason is because when forming friendships, you need to be in close proximity with the same people consistently. In school, you were forced to be around your classmates for 8 hours. In a way, you were “forced” to form connections -- this is also why run clubs are becoming so popular for dating. Every week, you go and run with the same group of people, and over time, you’ll form a connection with them. The same thing happens with your workplace.

**4) Status**

Status is important because it determines your place within your social hierarchy.

We used status back when we were hunter gatherers.

Who is Monkey #1 and who is Monkey #2? Who is the leader and who are the followers?

The higher your status is, the more opportunities, resources, protection, and influence you have.

Your brain responds to status as it is a physical thing. That means if someone attacks your status (says you’re not as good-looking or smart as they are), your brain sees that as a physical threat.

**5) Contribution**

Everyone loves to feel like they are useful and respected within their society.

_(We’re still just monkeys trying to fit in our tribes)_.

When we contribute, it gives us a sense that we have something valuable to provide to the world. When you look at people who are depressed or miserable, you’ll almost always find that they don’t feel like they’re useful or they have a place in the world.

This is why work is so valuable. It makes people who don’t feel useful, useful. It gives them something to focus on and strive for.

It provides a goal for them.

**6) Meaning**

I discovered this as I was building my brand.

Meaning is the next step in evolution after contribution. You go from “I can be useful” to “This is what I am meant to do”.

Meaning is a feeling that you have inside you that is constantly pushing you towards a bigger goal you have. This goal is usually to serve others.

Your meaning is the thing you want to be remembered for. It’s the fingerprint you want to leave in this world.

For me, my meaning in life comes from helping people improve their lives. Usually, that’s by helping them start a one-person business. From my experience and life, I realized that business is the best vehicle for self-improvement. You’re forced to grow, rewire your mind, uncover and overcome self-limiting beliefs, and know that every problem you have in your business is a direct result of a problem in your personal life.

### The 3 drivers to generate meaning in your life

In the future, when AI does everything we want it to do, what’s the point of meaning?

How can humans develop meaning in their lives?

After all, humans are a goal-striving species. We set goals because they give us something to work towards and achieve. And when our goals are much bigger than ourselves, that’s where meaning is developed.

Without a goal in your life (meaning) to work towards, you’ll become miserable and depressed.

Just look at anyone who has recently retired. They’ll still find ways to make themselves busy and work towards something (sometimes they work even harder than when they were employed).

But if AI can do everything, how can humans have meaning?

**1) Curiosity**

Your brain sends you a signal through dopamine telling you to follow a specific path.

Curiosity is how you start to formulate self-generated goals. Not goals that are given to you by your boss (which don’t actually serve you because you’re not the one who set them).

When you set your own goals, you start to become the creator of your own destiny.

But curiosity alone isn’t enough. You need to sustain it with something.

This is where the next step comes in.

**2) Struggle**

[![](https://substackcdn.com/image/fetch/$s_!6n76!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3cb87526-ed9c-4e71-a74c-62551906a022_1000x1000.png)](https://substackcdn.com/image/fetch/$s_!6n76!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3cb87526-ed9c-4e71-a74c-62551906a022_1000x1000.png)

_Credit: @thedankoe_

If what you were trying to achieve was easy, then you wouldn’t be interested in it.

The reason why a chess grandmaster keeps playing and wants to improve is because he’s competing with other chess grandmasters. But if he were forced to only play against beginners, he would get bored.

The same thing happens when a beginner plays with a chess grandmaster.

He’ll feel anxious.

But pit him against someone who is just slightly better than him, and he’ll be engaged and determined to improve and win.

Struggle forces you to narrow your focus on a problem, learn new skills and create new knowledge.

If you don’t choose a struggle, others will choose something for you to struggle for.

When you choose your own struggle, it means you care.

Life is most enjoyable when there is a meaningful problem to solve.

**3) Contribution**

Humans are a social species.

We love being a part of a tribe and knowing that we are useful. When you see the fruits of your labor, it fuels you.

Contribution is sharing the value and knowledge you gained back to society and helping others improve their lives.

The best way to do this is by starting a business. Because with business, you’ll learn marketing, sales, and persuasion. These are fundamental to learn if you want to become AI-proof in the future.

You need marketing to get your work in front of people’s eyes.

You need sales to get people to trust you enough to buy your product or service, so they can see value.

You need persuasion because it is the underlying skill to instill new ideas and behaviors in people’s minds (which will help them live a better and more fulfilling life).

Meaning the consistent act of identifying your problems, solving them, and passing down your knowledge to society.

Self-generated goals lead to meaning, self-discovery, and fulfillment.

Goals that are assigned to you by others lead to frustration, chaos, and entropy.

# How to future-proof yourself

> We’re going to see ten $1B one-person companies pretty soon… In a group chat I have with my tech CEO friends, there’s a betting pool for the first year that there will be a one-person $1B company.– Sam Altman

This is an exciting time to be alive.

If you’re someone who has always dreamed of building and creating cool projects and had wild dreams, you were born in the best time in history. Because now, with AI, no-code tools, and the Internet, we have infinite leverage at our fingertips.

> “An army of robots is freely available - it’s just packed in data centers for heat and space efficiency. Use it”- Naval Ravikant

You can create amazing products, attract an audience, help change people’s lives, and make a ton of money in the process just by sharing what you’re deeply passionate about.

In my eyes, one-person businesses are the future of businesses. This is what every high-value individual will use to become future-proof and make a meaningful living in their life

## Learn these 4 skills to dominate in the next 10 years

Most high-income skills will be replaced by AI in the next 24 months. I’m talking about research, programming, web design, animation, etc. Because AI is already great at most of them (and will be excellent at all of them in 24 months).

So if AI can learn faster than you ever could, be better than you at everything you do, and make fewer mistakes than you, what should you focus on?

I found 4 skills that will be in more demand in the future.

These skills can’t be taught in schools or universities. Because if someone can teach you how to do it, they can teach a robot. You’ll need to go through your own personal experience and develop it yourself, through self-education, self-experimentation, and self-reflection.

### 1) Agency

Most people can’t get anything they want out of life. They say they have big goals and dreams but they never achieve them because they don’t have the agency to achieve it.

A good example of someone who has high agency is Elon Musk. Whether you like him or not, you need to give him credit. The man wanted to make electric cars mainstream and then he built Tesla. It took him close to 10 years until they saw success but he made it happen. The same thing with SpaceX. He is someone who has the ability to say he wants something and goes out to get it.

The UAE (or Dubai, as many people know it as), it is a country that has a lot of agency. If you told people 50 years ago that a small desert country with no technology, no buildings, no wealth was going to become one of the world’s most luxurious places in the world, they would have called you stupid or delusional.

And that, I guess, is part of agency. You need to be slightly delusional (in other people’s eyes) to get what you want. You need to have the ability to get the things you said you wanted and not rely on other people to do the work for you.

Learn to hunt (identify problems), learn to solve (use AI to help with the technical side), learn to earn (build solutions for others to use).

Once you have agency in your life, AI can’t replace you because AI then becomes a tool for you to build what you want.

### 2) Taste & Perspective

Being intelligent is no longer an advantage.

When everyone has access to the same models and intelligence, the advantage you once had ceases to exist. In other words, if everyone has the same advantage, it is no longer an advantage.

This is where your perspective and taste come in.

The tiny experiences, thoughts, lessons, beliefs, and ideas you’ve experienced throughout your life have shaped a unique version of you in this world. There is no one else in this world who has the same knowledge and has lived the same life as you.

Leveraging that part of you becomes your unfair advantage.

### 3) Judgement

> Judgment is knowing the long-term consequences of your actions- Naval Ravikant

We now live in a world with infinite leverage.

You have an army of AI robots at your fingertips. You have an audience that you can reach at any time (social media & emails). You have no-code tools to help you build amazing products and sell them.

But when you have leverage, what should you do then?

Keep in mind, with leverage, you can outproduce and outwork a company that has 100 employees.

An average employee with leverage can outproduce and outwork a great employee that has no leverage by 1,000x and sometimes even 1,000,000x.

The rate of return is exponential.

This makes your ability to make good decisions that much more important.

If you can make the right decision, you win. If you make the wrong one, you lose, not by a little bit, but by a lot.

Warren Buffett is so wealthy because of his judgment. He has leverage (capital/money). Even if you take all the money away from him, investors will still flock to him and give him billions to invest because they trust his judgment.

You can’t outsource decision-making to AI.

AI can only handle the technical part of the work and maybe give you some information. But the final decision on whether to continue something or shut it down comes back to you.

The best CEOs and founders are great decision-makers. They have the ability to shutdown a project before it even launches because they have the judgment (which comes from experience and knowledge in that domain) to know that the project won’t succeed.

It also happens the other way.

They have the ability to continue building a project that seems stupid and unprofitable now, but they know that the project has the potential to succeed.

**Judgement is the skill that gets you paid purely on the quality of your thoughts.**

### 4) Deep generalism

AI is great at specific and technical tasks.

But it still lacks cross-domain synthesis. It still needs a master to guide it and tell it what to do. This doesn’t mean that this skill is “irreplaceable” but it will buy you time. The more skilled you are across different domains and know how to use AI to your advantage, the better off you’ll be.

Look at every successful founder or CEO, they are great at a lot of things and are exceptional at a few.

The best startups are the ones that have 2-3 founders who are all exceptional at a few things but at the same time, they have a lot of cross-domain knowledge.

They know how to build software, market their products, attract customers, sell their products, and scale.

They have the ability to operate on a high-level across different domains and still succeed.

To develop this skill, you need to broaden your areas of interest. Read more, learn more, experiment more, build more. Cultivate the ability to spot the dots between two seemingly unrelated topics and create something meaningful.

A common pattern across all these 4 skills is the same:

You need to develop the ability to think for yourself, build for yourself, and earn by yourself. And not rely on your job to give you the life you want.

**AI is a tool that humans will use to replace other humans.**

That’s all for today.

Thank you for reading,

Enjoy your day

- Hussain

**P.S.**

I’m finally back after a month's break.

_Also, writing this letter took me close to 3 weeks to finish._

So starting next week, we’re back to weekly deep dives and bangers.

Let me know if you enjoyed reading this one in the comments!


---

<!-- Archivo original: posts/2026-03-31-how-to-make-the-greatest-comeback.md -->

---
titulo: "How to make the greatest comeback of your life in 2026"
subtitulo: "5 steps to become a completely different person"
fecha: 2026-03-31T18:56:31.714Z
url: https://hussainibarra.substack.com/p/how-to-make-the-greatest-comeback
audiencia: gratis
palabras: 4125
likes: 58
comentarios: 9
---

# How to make the greatest comeback of your life in 2026

_5 steps to become a completely different person_

**Most people are addicted to failure and don’t even know it.**

It doesn’t take a genius to realize that most people are miserable in their lives.

They try to act like they’re happy.

Partying every weekend, going to Bali in the summer, buying designer bags, and driving an expensive car. But deep down they’re empty. They’re numbing their internal pain with external pleasures.

> _“When a man can’t find a deep sense of meaning they distract themselves with pleasure.”-Viktor Frankl_

Their pain is a result of them knowing the fact that they can be so much more in life but they’re not.

Most people will never reach their potential.

In fact, they never even come close to it.

I’ve met countless people who are ambitious, smart, and talented, but are stuck in the cycle of setting big goals, planning, learning, but never making any progress.

They are stuck in the mental masturbation cycle of doing a lot of work, but not making progress.

I’m not here to talk down on you or to make you feel horrible about yourself. I’ve quit more goals than I have achieved. That is part of life. Not all goals should be achieved. Sometimes, you set a goal you desperately want only to find out halfway that it’s not what you wanted all along and pivot to something else.

That is part of human evolution.

This is how we, humans, discover ourselves and create meaning in our lives.

Your goals start because of a superficial reason of gaining status or making money. But as you start working towards it and gain domain knowledge, you start to develop a philosophical sense of mastery and meaning.

I started going to the gym because I wanted to look good. But after 3 years of working out, I have the body I always wanted, I’m no longer skinny, I feel confident in my own skin, but I still workout 8 times a week. Because I realize to keep improving and keep the body I have, I needed to develop a deeper sense of mastery.

The same thing happened with my one-person business. I started because I wanted to make money. But now, I do this because I find it enjoyable. Helping other creators and writers find success is what makes me wake up excited.

If you want to change your life, reach your potential, and become the person you’ve always wanted, you need to set goals.

Goals are the lenses that you use to view the world, process information, and evaluate what tasks are important or useless.

But most people only set goals during New Year’s. They start off the year with a bang, but quit once February comes around. I’m not a fan of New Year’s resolutions because if you want to change your life, you can start today. However I do understand that for many people it gives them a hard date to start changing their habits.

The reason why most people fail their New Year’s Resolutions and fail to reach their potential is because they don’t understand the mechanism that they need to follow to change their lives.

This puts them in a Hell Loop:

Setting big goals. Planning. Taking action. Quitting 2 weeks later. Feeling depressed. Getting fed up with the lack of progress in their lives. Setting goals. Repeat.

It’s a sad loop because you want to change but are never able to.

So if you want to start a business, hit the gym, get into a healthy relationship, or create meaningful work, I want to share with you the process of what’s truly keeping you stuck, how to rewire your mind for success, and 5 steps to change your life.

This will be a deep dive.

It is comprehensive.

Filled with actionable advice and ideas that will change your life.

This is something you will want to bookmark, take notes on, and come back to in the future.

Let’s begin.

# The cycle of motivation

[![](https://substackcdn.com/image/fetch/$s_!eIZi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F90d4a685-f305-4c4a-aed8-d5b15c1fff35_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!eIZi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F90d4a685-f305-4c4a-aed8-d5b15c1fff35_1080x1080.png)

_Credit: @hussainibarra_

Most people think the path to change looks like this:

**Feel inspired → Take action → Results → Happiness**

But this is fundamentally wrong.

When you look at their lives, you notice a different pattern. It goes something like this:

- **Dissatisfaction:** You feel stuck, unhappy, or behind in life.
- **Inspiration:** You watch a video, read a book, come across a post, or reach “rock bottom”.
- **High action:** You set goals, wake up early, eat clean, hit the gym.
- **Encounter a roadblock:** The old you starts resisting. Old patterns come again. You “slip” once and it starts snowballing.
- **Collapse:** You quit. Back to square one. Only now, you feel worse because you “failed again”.

Your amygdala (the part of your brain that is responsible for emotions like fear, anxiety, danger, and depression) sees the unknown as a threat. So when you try to change your life, you’re venturing off into the “unknown”. You are creating a new identity, a new set of habits, beliefs, and skills. And your brain sees that as a threat.

So what does it do?

It subconsciously tries to sabotage every opportunity you have for change. It wants to keep you where you are because it is familiar, and familiar is safe.

The bigger the change you’re trying to make, the more active your amygdala becomes and the bigger the alarm is going to be.

Your brain prefers known pain over unknown pleasure.

Even neuroscience proves this. Your nervous system is addicted to your current emotional state. Even if it’s miserable.

Your body craves the chemicals of stress, shame, and anxiety because they’re familiar. This is why people self-sabotage even when things are going well.

The problem is that you’re trying to override a system with a fuel source that was never sustainable (motivation).

There are 3 forces that create motivation:

**1) Push Motivation**

Push motivation comes from negative emotions. Scientifically speaking, negative emotions are the most potent motivators we have.

Pain makes you pull your hand off the stove.

Fear makes you run from predators.

Shame makes you change your behavior so the tribe doesn’t reject you.

Every negative emotion you have is sending you a signal: “This situation is unacceptable, change it.” That’s why they hurt.

Shame, for example, is the most potent motivator.

You’ve heard this story multiple times before. Guy tries to approach a girl, but he gets rejected. He feels ashamed. Guy decides to become successful and wealthy just to prove to her that he can be successful. In other words, shame makes you think you are fundamentally wrong and that is why you need to change. And that’s what makes it so powerful.

I’m someone who struggles with ADHD. My entire academic career is based around me procrastinating until the last minute. It doesn’t matter if you give me 3 months or 3 days to finish a paper. I’ll always wait until the last minute. Because there’s no real urgency to get it done earlier. But once the fear of failure kicks in, I finally have the drive and ability to sit down, focus, and get the job done. Most of my friends think I’m a psychopath because of how much stuff I can get done when there’s big risk.

But the problem with using negative emotions is they’re not sustainable.

I’ll use numbers for my next example to drive the point home.

Say you need 100 points of shame for it to become a motivator. The problem is, before you reach 100, say you had 99 points, at this stage, you feel depressed, self-sabotage, feel like a loser. You feel stuck. But once you reach 100, you become the most productive person in the world.

That’s the problem with negative emotions. They’re binary. It’s all or nothing. There’s no middle gear. You’re either burning with the need to prove yourself or you’re empty.

This is why people who are driven by their traumas have these cycles of intense periods of productivity, then collapse. They are driven by their trauma and don’t even know it.

And the funniest part about all this?

When they heal from their trauma, their motivation disappears. Because their motivator -- trauma, shame, guilt, fear -- is no longer there and is no longer the driving force.

_The fuel burns hot. But it burns out._

**2) Pull Motivation**

Pull motivators are positive emotions. Creativity, curiosity, passion, love. They’re not as potent and powerful as negative emotions, but they are more sustainable. It’s not so binary as negative emotions. Even if you’re just at operating at 20%, you can still be productive.

Negative emotions, you can’t. It’s either 100 or 0.

**3) Future Prediction**

Think of gambling.

Most people know they will lose. But why do they keep going back?

Because they keep saying: “Maybe next time I’ll win.”

They keep predicting the future but keep failing.

They can be wrong a hundred times but they only need to be right once to get hooked. The dopamine that is produced by “prediction-error” is gigantic which makes gambling so addictive.

The same thing is with social media.

The scroll feature that you think is normal is the same as a slot machine.

You don’t know what the next post is going to be about which makes you want to keep scrolling.

It also happens with people who are constantly daydreaming. When you think of achieving your goals, your brain produces the same dopamine as if you achieved it. It’s also true when you tell people about your goals. This is why so many people tell you to keep your goals for yourself.

Because if you get dopamine (which is the reason you want to chase your goals in the first place) by talking about your goals, then you would have no drive to keep working towards your goal.

Your entire motivational system is dictated by dopamine and future-reward prediction.

**If there is more upside than downside, then you will feel motivation and take action.**

# The Ego vs. The World

[![](https://substackcdn.com/image/fetch/$s_!Plnm!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c15dbd5-30d6-43da-a015-0adcf6a1bcdb_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!Plnm!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c15dbd5-30d6-43da-a015-0adcf6a1bcdb_1080x1080.png)

_Credit: @hussainibarra_

> “A thoroughly socialized person is one who desires only the rewards that others around him have agreed he should long for -- rewards often grafted onto genetically programmed desires. He may encounter thousands of potentially fulfilling experiences, but he fails to notice them because they are not the things he desires. What matters is not what he has now, but what he might obtain if he does as others want him to do. Caught in the treadmill of social controls, that person keeps reaching for a prize that always dissolves in his hands.”- Mihaly Csikszentmihalyi

When I was growing up, I was told that I’ll either be a doctor, a lawyer, an engineer, or a scientist.

So whenever I went to family gatherings and people asked me what I wanted to do when I grow up, I told them engineer.

“You will be a very successful engineer”, they replied.

I went to college, got my engineering degree, started working with the biggest developer in Dubai as an engineer, and I hated my life.

Because I realized that I wasn’t living my life for myself. I was living it to please the people around me.

What I really wanted?

Creating content and making an impact on people’s lives. So it didn’t take long before I quit my job.

The problem is many people in life never ask themselves what they want. They live their lives to please others. They get a job they don’t care about, drive a car they don’t have money for. Get married to a partner they don’t really love because society expects them to get married at a certain age. They get a life-long mortgage because “it’s what they need to do”.

And then they wonder why they’re not fulfilled and happy in life.

Because when the world tells you something, you take it, and then internalize it.

When you internalize it, it goes from being “outside” to “inside”.

Once you internalize it, your ego comes into play.

This now becomes a discussion between you and yourself. Nobody can tell you what is right and what is wrong.

To make the right decision, you need to truly know yourself.

## Discovering who you really are

In Western psychology and philosophy, they say that your ego — the real you — is buried under societal conditioning.

> “You don’t do anything to be free, you drop something. Then you’re free.”- Anthony De Mello

Just like how a block of marble gets slowly chipped away until a statue appears. The same thing is with your ego. Society has projected its beliefs, ideas, thoughts, and perspective on to you. Now you’re carrying them with you thinking that it’s you when it’s not.

If you sit by yourself and start questioning your ideas and beliefs, you’ll quickly realize that 99% of what you thought was you turns out to be just what society has conditioned you into thinking.

Eastern philosophy has a different take on this.

They say your ego is more like a river.

In Western philosophy, your ego is static:

- I am an engineer
- I am a father
- I am a designer
- I am a writer
- I am a parent

It’s static, but it’s also very limiting.

Are you _only a father?_

Are you _only an engineer?_

Are you_ only a parent?_

Well…

No.

You are all of these things at the same time. Your ego is everything that makes you, you. It’s all encompassing. It is made up of all the tiny experiences, ideas, conversations, beliefs, perspectives, wins, and losses that you have seen in your life. Even if you change your name, your ego is still intact. You can change a river’s name and the river will still be there. You can change the direction of the river stream and the river will still be there.

The same thing is with your ego.

You can change your name. You can change your hairstyle. You can change your job, diet, habits, and everything about you, and your ego will still be there.

When you look at yourself from a 3rd person’s point of view, which one are you?

Are the body or the observer?

You’re not your body because you can see it. So who is the observer?

And here’s where it gets interesting: **you can never **_**see **_**the observer. The observer is you. That is your ego.**

Your ego is always present.

To “find yourself”, stop trying. Be more open and welcoming to new experiences and allow your ego to rise up.

The more you listen to you it, the more aligned you’ll feel, the more motivated you become. Because you no longer operate from the state of “need” but rather you operate from a state of “wanting”.

# How to engineer your greatest comeback (step-by-step)

[![](https://substackcdn.com/image/fetch/$s_!f1u3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc11a44b1-38c5-48ac-9c48-685f16a783de_1080x1080.jpeg)](https://substackcdn.com/image/fetch/$s_!f1u3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc11a44b1-38c5-48ac-9c48-685f16a783de_1080x1080.jpeg)

_Credit: @visualizevalue_

> _“The joy of life is finding new novel experiences”- Andrew Huberman_

Most people are trying to fix symptoms but ignore the root cause of the problem.

They try to be more productive at a job they hate. More disciplined in a life they didn’t choose. More motivated toward goals that don’t serve them.

If you don’t set your own goals, if you don’t choose what work to create, if you don’t have control over how much you earn, then are you really in control of your life?

If your actions are dictated by other people, and your actions dictate the kind of life you’ll live, then by definition, your life and future is decided by other people.

Wake up.

Reject the normal path.

Start trailing your own.

Educate yourself, read new books, open your mind to new perspectives.

Stop looking at the same places that got you to where you are now.

If you want to live an extraordinary life, you need to look where most choose to ignore.

Here’s how to make the greatest comeback of your life:

## 1) Get absolutely fed up with where you are now

I made the most amount of progress in my life in periods when I was absolutely fed up with the lack of progress I saw.

Anger is raw energy. It is the fuel that you need to propel you towards the life that you want.

Grab a notebook and write down everything that is wrong with your life.

- Write about what you do on a daily basis
- Identify the toxic parasites that are draining your energy (this can be friends, family, and apps).
- What are the bad habits that you want to break?
- Why do you hate your current job?
- Where will you end up in the future if you don’t change a thing?

Identify all the negative parasites that are in your life causing you to be in this state of mind.

Most people are stuck in this limbo of being miserable, but not miserable enough to change. The only way to break out of it is to get angry at where you are in life and realize that you are meant for more.

## 2) Direct your negative energy to launch yourself into a new life

Anger is a potent motivator.

That means if you don’t know how to use it, it will destroy you.

The way you control it?

By directing your anger towards a meaningful future.

Go back to your notebook and write down the kind of life you want:

- How much you’re earning.
- The car you drive
- Where you’re living
- What you do on a daily basis
- How you look, act, and speak
- The relationships you have
- If you had all the money in the world, what would you do as “work”?
- How long do you want to work per day?

Be specific with your life.

Then, outline the skill sets you need to achieve that life.

My advice?

Start a project. It will teach you multiple skills at once and you will have something to work towards every day.

Identify the 3-5 levers that move the needle forward. Do these tasks in the first hour of your day.

It drives me crazy to see how many people decide to break their backs at work for 8-9 hours every day but refuse to spend 1 hour building their future.

Your boss doesn’t care about you.

Don’t you realize that?

You need to become the creator of your future. Nobody became successful by accident.

## 3) Reinvent yourself

[![](https://substackcdn.com/image/fetch/$s_!tCKY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F65c8d64d-8933-4962-9fc3-d66593cc5781_1080x1080.jpeg)](https://substackcdn.com/image/fetch/$s_!tCKY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F65c8d64d-8933-4962-9fc3-d66593cc5781_1080x1080.jpeg)

_Credit: @visualizevalue_

> “No great improvements in the lot of mankind are possible, until a great change takes place in the fundamental constitution of their modes of thoughts.”- J. S. Mill

Here’s something you don’t want to admit: **You’re addicted to failure and you don’t even know it.**

Most people have programmed themselves into thinking they’re a failure. Every time you have a memory of the past, your body re-lives it. Your body produces the same chemicals as if it were actually happening.

That means no matter how much you try to force-feed positive thoughts, your subconscious mind will always find a way to self-sabotage.

Your identity (the story you tell yourself about who you are) determines:

- What goals feel “realistic” for you
- What actions feel natural vs forced
- What you believe you deserve

If your identity is “I’m not the kind of person who [insert whatever self-limiting belief you want here]” then no amount of motivation or hard work will override that belief.

All your actions serve one purpose: **Confirm the identity you believe is true for yourself**.

When you procrastinate, you’re not being lazy. You’re protecting an identity that feels threatened by change.

When you refuse to speak to the girl you like, a part of your identity believes that you’re not worthy of love.

**Your body does not create a new system while another one works. You have to break free from the old system, then there will be a need, and that’s when your body starts creating a new system.**

To start seeing new results, you need to become an entirely different person, mentally.

You must first _become _the person who’s capable of achieving the goals and living the life you want.

- You must first see yourself as an entrepreneur and founder before starting a business.
- You must see yourself as someone who is healthy before you lose any weight or get in good shape.
- You must first see yourself as someone who can focus.

The saying “Fake it till you make it”?

It works. There is truth behind it.

“But Hussain, I’m just an average person, there’s nothing I can do.”

Don’t you see what I’m trying to say?

That’s your old identity trying to sabotage you.

You must go to war with your mind and emerge victorious.

You will feel like an imposter, like you don’t belong, and even stupid at first, but that’s only for a brief moment.

Once you start seeing results come in, you will no longer feel like an imposter.

There’s a lag effect between the work you put in and the results you get. You must be persistent enough. Most people quit too early. They expect their results to match their efforts.

But that’s not how life works.

You put in the work for months before you see any form of success.

Your external life is a delayed reflection of your internal identity.

**Your life 6 months from now is decided by what you do today.**

## 4) Sustain your new identity through self-generated goals

Thinking alone isn’t enough.

The world is filled with people who think they’ll suddenly wake up and lose 100 pounds of fat or make a million dollars.

Relying on motivation alone is for average people.

Motivation is a feeling, and feelings are just temporary emotional waves that normalize with time.

You can act regardless of how you feel.

You don’t need to be inspired to write. You don’t need to feel “on” to hit the gym. You don’t need to feel anything to act.

In fact, the act of _doing_ is the reason why you feel anything.

Successful people make their new identity part of their daily routine

- You can’t be disciplined 50% of the time and expect things to change.
- You can’t eat clean and hit the gym twice a day and expect to get in shape.
- You can’t work on your business 1 day a week and expect to make millions.

You must do it daily.

You cannot allow your old identity to creep back in and bring you down anymore.

How much longer would you want to be in the same life?

Don’t you want a better life?

I guarantee you one thing: **Life is tough.**

And the only way you’ll get what you want is if you learn how to hunt for yourself.

You must give yourself goals to chase. Nobody can do it for you. Once people start telling you what goals you should and shouldn’t work towards, that’s when society starts programming you again.

Educate yourself. Expose your mind to new information

- Read books
- Listen to podcasts
- Enroll in a new course
- Change your circle of friends
- Curate your algorithm so it serves your goals

While you’re learning, you will **understand** the fundamentals, **gain** clarity on what you want to do, and **have** the motivation to execute.

Self-generated goals and repetitive action are the secret to _becoming _a new person.

## 5) Your life is determined by these 2 things

- How much uncertainty you’re willing to handle
- Your ability to persist

The more uncertainty you’re willing to handle, the better your life is going to end up.

I can guarantee you one thing:

This process will be difficult.

You will be tested. You will want to quit. This will be the hardest thing you will ever do.

But that’s exactly how it is supposed to be.

It isn’t “supposed” to be any other way.

Go to the gym and look like an idiot.

Approach the girl you think is out of your league.

Start a business with no experience.

Launch the product that you know will fail.

Be stubborn enough and delusional enough to think you can succeed even when all the evidence tells you otherwise.

**You must become a failure before you can become successful.**

Everyone had to go through the same process.

Invest in your portfolio of failures until you can afford to succeed.

This is the only way to get what you want out of life.

Thank you for reading.

Enjoy the rest of your day.

- Hussain

**P.S.**

I have a lot more ideas I wanted to share but I had to cut this letter short (so I don’t overwhelm you).

If you enjoyed this and want to see more in the future, let me know in the comments.

It’s the only way I can know for sure.


---

<!-- Archivo original: posts/2026-04-12-the-world-economy-is-fcked-right.md -->

---
titulo: "The world economy is f*cked right now (here's what you can do about it):"
subtitulo: "How to become recession-proof."
fecha: 2026-04-12T08:42:51.481Z
url: https://hussainibarra.substack.com/p/the-world-economy-is-fcked-right
audiencia: gratis
palabras: 3165
likes: 80
comentarios: 1
---

# The world economy is f*cked right now (here's what you can do about it):

_How to become recession-proof._

**The world is f*cked right now.**

Gas prices are through the roof.

Oil was trading close to $120 a few weeks ago.

And according to experts, at $150, we will see a global recession.

> _“Oil at $150 per barrel could push the world into a recession.”- Larry Fink, CEO of BlackRock, the world’s largest asset manager of $12.5 trillion._
> [Source.](https://www.reuters.com/markets/us/blackrock-ceo-warns-oil-rise-150-could-trigger-global-recession-bbc-reports-2026-03-25/)

Inflation is at an all-time high.

10,000 Baby Boomers are selling their assets to keep funding their retirement life.

Millennials and Gen Z People can’t afford to buy houses anymore.

Oracle recently laid off 30,000 employees.

Jack Doresy, the former CEO of Twitter, recently laid off 50% of his employees.

The traditional path that was marketed to us as “safe” is the least safe path there is in today’s current economy.

Jobs look “safe” because you have money coming in every month but it’s the worst that can ever happen to you.

You get used to it.

They pay you just enough so that you can get by and nothing more.

Miserable, but not miserable enough to change.

They have the power to take it all away tomorrow if they want.

They drain your most productive hours (and years), make you work on useless and mind-numbing tasks, so when you come back home, you’re too exhausted to do anything meaningful, watch Netflix, sleep, and repeat.

It blows my mind just how people are willing to spend 8 hours a day working a job they hate, but they refuse to invest 1 hour of their day into something meaningful.

If your livelihood is dependent on an employer giving you a job, then your future is literally in their hands.

You don’t have a say in what happens to your life. Because you’re not the one funding it, it’s your employer.

You can go from making a comfortable living to $0 overnight and you can’t do anything about it.

The best way to future-proof yourself is to start a business.

I know, so many people are tired of hearing this to the point they just tuned out.

But I’m not here to tell you or show you how to turn a car washing business, or to mow the lawns, or help your local dentists to book more appointments, or build “passive income”.

Frankly, I never started them and I’m not interested in building them.

And I’m guessing you don’t want to either.

If you’re anything like me, you want to get paid doing something you love.

_Aren’t we all trying to do that?_

So that’s what I wanna share with you today.

I wanna show you the business model I used to make $60,000+ as a full-time graduate student doing something I love (talking about self-improvement), operating at ~91% profit margins.

I don’t have any employees.

I don’t come from a wealthy family.

I’m just an average 24-year-old who took the internet seriously.

The best part about it?

It costs you nothing to start and anyone can do it.

You don’t need to be crazy talented or have decades of experience (although it helps).

With 1-3 hours a day of focused work, you can turn your one-person business into a full-time income within 1-2 years.

Let’s dive in.

## What is a one-person business?

> _**“Capital and labor are permissioned leverage. Everyone is chasing capital, but someome has to give it to you. Everyone is trying to lead, but someone has to follow you.”**_
> _**- Naval Ravikant**_

The one-person business is a life philosophy.

It’s about designing a life where your work is an expression of who you are.

Your Mondays feel the same as Saturday morning.

This is a business model that allows you to create and run a hyper-profitable business by yourself.

You leverage your unique skills, interests, experiences, and digital leverage to build a business. This is the only business model I found that grows and evolves as you grow as an individual.

In a one-person business, you use:

- Social media to attract like-minded people to your work
- Use AI and no-code tools to build digital real estate through digital products, websites, and an email list (that social media platforms can’t take away from you).
- The intersection of your interests, perspectives, and experiences to create a brand that no one else can replicate (because no two experiences are the same).
- Lifestyle design as your north star and compass to create a work schedule that best suits you.

> _**“The best jobs are neither decreed or degreed. They are creative expressions of continuous learners in free markets”**_
> _**- Naval Ravikant**_

The limits that come along with employment, a salary cap, a fixed schedule, assigned work, building someone else’s vision all cease to exist when building a one-person business and taking the internet seriously.

The tools are available. The platforms are free. The knowledge is accessible to everyone.

So why don’t people start a one-person business?

A few reasons why:

- You think business is only reserved for “successful” individuals who have real experience.
- You think educational businesses that teach you a real-life skill you can use to make yourself high-value are pyramid schemes, but you don’t have any problem with universities charging 10x more to teach you an outdated degree.
- You believe you’re not qualified enough to teach or sell. But you fail to recognize the value of the life you’ve lived.
- You struggle with Shiny Object Syndrome. Constantly chasing new ideas or business models instead of committing to one.
- You think your life is boring to profit from, which is funny because the most successful people I know are the ones who value depth, knowledge, and perspective. The ones who care about looking the best and being famous? They’re struggling the most.
- You don’t know how to make your interests interesting for other people so they don’t care.
- You don’t listen to feedback and stubbornly stick to what isn’t working.

I can keep going but you get the idea.

The common problem here is the self-imposed limiting beliefs you have.

The only way to break them is to obsessively solve your own problems.

To solve problems, you must prioritize self-reliance, self-experimentation, and self-education to learn skills, build projects, and rewire your mind to see a new perspective in life.

## The 4 pillars of a one-person business

> _**“No one can compete with you on being you. Most of life is search for who and what needs you the most.”**_
> _**- Naval Ravikant**_

If you want to turn your passion into profit, traditional marketing and business advice will lead you down the wrong path.

Traditional businesses focus on the bottom-line profit and nothing else.

You solve problems you don’t care about, work for people you hate, just to feel exhausted by the end of the day.

It’s not different than having a job.

It’ll suck your soul dry.

But with the one-person businesses, the profit you make comes as a byproduct of chasing your genuine curiosity and providing value to the world.

You use yourself as the starting point.

The content you create, the problems you solve, the products you build, the marketing, it all starts with you.

You create the vision of the life you want, you start working towards it, encounter a problem, solve it, build a product to show people how they can solve it as well, and profit from it.

This way, you can help people who are on a similar path to you.

You don’t need to spend countless hours doing market research. You know the problems that are in your life.

All you need to do is focus on solving them and using the internet to attract people to your work.

Your personal brand becomes a storefront for your business.

### I) Branding

Your brand is who you are, what you stand for, and want you want to achieve, and the mission you’re on.

It’s everything that makes you, you.

- The life you’re trying to create becomes the goal you try to lead people towards.
- You use yourself as the Customer Avatar to attract like-minded people who are on a similar path.
- Branding is _communicated _through your content and products, not through explicit statements.

Your brand is not something that is static.

This is why, when done correctly, the one-person business model can never be saturated.

Because every human is unique in their own way. No two experiences can ever be the same.

Your goals evolve with time.

Your ideas change.

Your beliefs change.

And so with it, your brand changes.

It’s an ever-flowing river with twists and turns.

Your brand grows and evolves as you grow.

The more knowledge you gain, the more skills you learn, the more equipped you become to solve harder problems.

This allows you to take on more interesting challenges.

Your one-person business is the bridge between self-improvement and business.

Your brand becomes the vehicle that fuels your entire business and life.

It’s how you set goals, identify problems, experiment with solutions, package your knowledge in a product, and distribute it with no marginal cost of replication or product fulfillment.

You solve your own problems and distribute the value you gained to society in exchange for money.

### II) Content

> _**“Talk about whatever you want, but learn marketing, sales, and persuasion”**_
> _**- [@thedankoe](https://substack.com/@thedankoe?utm_source=global-search)**_

Luck is a percentage that increases with the number of people who know you and the work you do.

Content is how you attract like-minded people to your brand and garner support for your work.

Social media is the new town center.

- Your future employer is on social media
- Your future customers are on social media
- Your future business partner is on social media

Treat your Twitter, Instagram, or Substack account as a place for sharing your discoveries and talking about your interests in a persuasive way.

You’re writing the story of your transformation and inviting others to join.

Create content around your problems, goals, progress, and share lessons that would have helped you in the past.

### III) Product

I’m tired of people gatekeeping and telling you to wait until you reach a certain milestone before you start monetizing.

You need to create a product from day 1.

Not with the goal of making a million dollars (although that is possible if you stick out long enough). But to have that product frame your content and have something to iterate on.

If you don’t know what product to create, start with your own problems. The problems you’ve already solved are the ones you’re most qualified to help others with.

- Lost 30 pounds? You can create a weight loss program for others.
- Built a writing habit? Build a course around it.
- Solved your ADHD problem and now you can focus? You can sell a Notion template, helping others stay organized.
- Have a long-term stable relationship? Create a coaching offer helping introverts get over their social anxiety.

The best products are personal systems.

These are your wisdoms, ordered and packaged as digital products, so society can benefit from them.

With the one-person business model, you don’t sell commodities. You sell your perspective, your system, your transformation.

The unique intersection of everything you’ve lived, learned, experienced, and struggled through becomes your unique competitive advantage, which no one can replicate.

### IV) Marketing

> _**“Learn to build. Learn to sell. If you can do both, you’ll be unstoppable”**_
> _**- Naval Ravikant**_

With AI now being able to handle most of the technical parts of a business, companies are now shifting their budgets away from engineering teams and more towards marketing teams.

Because it does not matter if you have the greatest product in the world, if nobody sees it, no one will buy it (and therefore, no one will gain value from it).

You need to learn marketing because that’s how you get people to care about your interests (and turn your passions into profit).

You don’t need to learn tricks or hacks.

All you need to do is talk about the benefits of what you’re doing.

Your entire marketing strategy is literally the reason why your brand exists in the first place.

- Why do you care about certain topics?
- Why do you want to solve a certain problem?
- Why do you do what you do on a daily basis?

That’s literally all what marketing is.

It’s communicating the benefits of what you do and the potential benefits that can also give your readers.

The best marketing strategy is pure honesty.

## The most valuable currency of the 21st century

[![](https://substackcdn.com/image/fetch/$s_!8eTO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fccfc5cbf-f246-4e54-9971-e3f4fda2492f_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!8eTO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fccfc5cbf-f246-4e54-9971-e3f4fda2492f_1920x1080.png)

_Source: @hussainibarra_

> _**“If you can’t code, write books and blogs, record videos and podcasts”**_
> _**- Naval Ravikant**_

Attention is the new oil.

When you have companies spending billions to get you to spend the most time possible on their platform. Or even when you have AI where you could do almost anything you ever wanted, your attention is now more valuable than ever.

Building an audience is all about knowing how to direct people’s attention.

You build an audience by posting on social media to attract people to your work. This is how you get support, fans, and customers for your business.

An influencer creates content on social media for the purpose of entertainment.

A Value Creator builds on social media to provide value.

- They solve problems, shift your perspective, and give you a new goal to chase.
- They solve their own problems. Dive into the unknown to create new knowledge.
- Verify what they’ve discovered through self-experimentation.
- Redistribute the value they have discovered back to society through content and products.

If you don’t have an audience, you don’t have a business.

I see so many people on social media preaching about how you need to do cold outreach to sign clients.

But if you have an audience that knows what you do, you can simply create products for your audience and sell to them.

Your audience is your own distribution channel.

When you own your distribution:

- You don’t need to do cold outreach
- You don’t need to spend money on ads
- You don’t need to rely on referrals to get more customers

When you have an audience, you control your income.

But when you need to know how to build an audience.

### Generate attention

Use short-form to generate attention.

Tweets, Substack Notes, Instagram Reels, TikToks, YouTube Shorts.

Your goal with short-form is to stay on top of mind and test ideas.

My advice?

Create on Twitter/X. Here’s why:

- You can post multiple times a day without getting punished.
- **The feedback loop is extremely fast:** You can have an idea now, post it, and within 24 hours, you’ll know if people like it or not. This helps you know what ideas work (which you can later use in your longer forms of content).
- **Tweets are highly repurposable:** Go on Instagram, and you’ll find people screenshotting tweets and going viral that way. Substack Notes are also very similar to how tweets work. That means you can just copy/paste your tweets and post them as Substack Notes without any edits.
- **You become more articulate:** Because Twitter has a 280-character limit, you are forced to be concise and add punch to your ideas. This will later help you with medium-form and long-form content.

To write good short-form, write beginner-level content.

Why?

Because 99% of people on social media are beginners. They don’t know anything about your topic. So to generate attention, you need to target beginners.

Even experts need to be reminded of the principles.

If you don’t know what to write about, reflect on your life and write to your previous self.

You know their problems, struggles, hopes and dreams.

When you write to yourself, you write to millions (because they are also on a similar path to you).

### Capture attention

Medium-form content is the most consistent way of getting people’s attention.

It’s the perfect balance between being short enough to get in front of a wide audience but also long enough to build authority and trust.

Think of Twitter threads, 8-15 minute YouTube videos, Instagram carousels, and long Substack Notes.

Types of medium-form content:

- How To’s
- Frameworks
- Step-by-step solutions
- Listicles

The goal is to show depth, demonstrate expertise, and drive traffic to your long-form (newsletter).

99% of my growth came from writing threads.

You can write a simple thread in 30 minutes and go viral.

Here are 3 examples from threads I wrote last month:

[![](https://substackcdn.com/image/fetch/$s_!sWlN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F18f8523e-54b8-4041-9a3a-6fd5f1ad55a7_1206x412.jpeg)](https://substackcdn.com/image/fetch/$s_!sWlN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F18f8523e-54b8-4041-9a3a-6fd5f1ad55a7_1206x412.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!D7Im!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7668a00f-39f7-411a-90c4-392c550e5815_1206x476.jpeg)](https://substackcdn.com/image/fetch/$s_!D7Im!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7668a00f-39f7-411a-90c4-392c550e5815_1206x476.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!aNVE!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07d593e4-1764-4081-a667-ab34c1360044_1206x544.jpeg)](https://substackcdn.com/image/fetch/$s_!aNVE!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07d593e4-1764-4081-a667-ab34c1360044_1206x544.jpeg)

Even if you go to your favorite YouTube and look at their most viral video, you’ll also see it’s either a listicle, a step-by-step, or How To’s.

And it’s almost always beginner-friendly.

When you go viral, you can easily add 200-500 new subscribers to your email list.

### Hold attention

The **Creator Economy** is actually the trust economy.

The person who has the most trust wins.

You build trust, nurture relationships, and sell your products through long-form content.

Podcasts, newsletters, guides, and YouTube long-form.

You get to show people you actually know what you’re saying (because a beginner won’t be able to be so persuasive and demonstrate such a high understanding of the topic like you).

You also get to build trust because you share personal perspectives with your audience. This will repel a few people but will attract a lot more.

I worked with “less successful” mentors just because of the trust I had in them.

Their content and perspective were aligned with what I thought about the world which is why I was happy to invest $3,000, $4,000, and even $5,000 with them for just a few months.

### Convert attention

It blows my mind just how many people rely on platform ad revenue to monetize their brands.

If your entire monetization strategy is letting platforms pay you for the views you generate, then you have a new employer.

“But Hussain, I don’t want to be another course seller”.

Then don’t be.

Create a genuinely helpful product (one that you wish had existed before in your life) and ask your audience, those who have the same problem as you, to support you and your work by buying your products.

You’ll make more money and have more control over your income and lifestyle than relying on a platform that doesn’t care about you.

**Productize yourself.**

Thank you for reading.

Enjoy the rest of your day.

- Hussain

**P.S.**

The threads I just showed you?

Each took me 30 minutes to write.

Next week, I’ll run a live masterclass to help you build your audience faster with AI.

It’s the same process I used to gain 6,300,000 views, 1,200 followers, and 750 new email subscribers.

You’ll get all the prompts, templates, and systems to help you get started.

Stay tuned.


---

<!-- Archivo original: posts/2026-04-20-how-to-become-disgustingly-creative.md -->

---
titulo: "How to become disgustingly creative in 2026"
subtitulo: "The 5-step framework I used to generate 86M+ views and attract an audience of 29,000 followers"
fecha: 2026-04-20T03:12:20.365Z
url: https://hussainibarra.substack.com/p/how-to-become-disgustingly-creative
audiencia: gratis
palabras: 2550
likes: 97
comentarios: 17
---

# How to become disgustingly creative in 2026

_The 5-step framework I used to generate 86M+ views and attract an audience of 29,000 followers_

Humans process 185 million bits of information over the course of their entire life.

With that, you can become:

- A writer
- An artist
- An athlete
- A musician
- A historian
- A politician
- A philosopher
- A bodybuilder
- An entrepreneur

Or all of them together.

But the problem majority of people don’t even come close to using all 185 million bits.

They waste it.

The reason?

They’re living on autopilot. They come back from their jobs and numb their minds with cheap dopamine and stop learning. They think education stops once they graduate from college.

So they limit themselves to only operating in the “known”.

But that’s the most dangerous place to be.

> _Living safely generally means living in imitation and therefore in fear.- Jiddu Krishnamurti_

When you limit yourself to what is known, you stop making novel discoveries. Life becomes repetitive, years pass and you start to degrade.

The result?

Feeling lost, meaningless, and a lack of purpose in life.

No motivation. No goals. Nothing to look forward to. Just boredom.

So the average person cures their boredom by numbing their mind with cheap dopamine.

They use their daily cognitive load on tasks that don’t mean anything. Then they complain about how they lack motivation and productivity.

You don’t lack anything.

In fact, you’re highly motivated and highly productive.

You’re always doing something — scrolling, playing video games, watching Netflix — these are not “nothing”. They just _amount_ to nothing.

Your cognitive load is limited.

It’s just like the RAM in your computer. You can fill up your RAM by opening a million tabs and apps that you don’t use. Or you can have one tab open and use the entire RAM to complete that task. This will allow you to complete more tasks, become more creative, make novel discoveries, make more money, and work less.

# The greatest skill of the 21st century

We live in an era where AI can do almost anything.

It can write any content, draft any marketing plan, code any app you want, create any product you want.

Focus — your ability to know what to work on, how to work, and what to avoid — becomes the greatest skill you need to develop.

Because now, with the amount of leverage you have available at your fingertips, your decisions are not 1:1 anymore.

They’re 1,000x more crucial.

You can work on the right product and build a successful business, or spend 3 years building something that nobody wants.

What you focus on is what enters your consciousness.

These can be biological (like feeling hungry) or societal (other people telling you what you _should _be doing) instructions.

However your focus is a limited resource.

There are only so many things you can think of, memories to recall, comparisons to make, options to evaluate, and decisions to make.

These all make demands on your mind’s limited capacity.

Some people leverage this resource efficiently (by only consuming what is useful and being intentional).

Others, waste it by doomscrolling, ruminating, watching Netflix, porn, and numbing their minds with cheap dopamine.

But focus can be trained.

- A musician trains her ear to listen to the subtlest of sounds to find the right note for her music.
- A perfumer trains his nose to pick up on the faintest scents.
- A goalkeeper can tell where the striker will shoot just by looking at their body language.
- A surfer who can adjust their feet based on the smallest changes of the wave to not fall.
- A good clinician can diagnose your mental condition from your choice of words.

These are all examples of people who have trained their focus to pick up on the smallest details that the average person can’t see and thus giving them a competitive advantage over the rest.

> _Attention comes when you are deeply interested in something, for then you love to find out all about it; then your whole mind, your whole being is there.- Jiddu Krishnamurti_

Focus is what determines what will or will not appear in your consciousness.

What does this have to do with creativity?

Everything.

Creativity is your ability to see what others can’t.

It is how you connect two seemingly unrelated topics and make them fit perfectly together.

It is how you articulate ideas that makes people go: _“How the hell did this person say it?”_

It is how you can create great products, start trends, and light up a movement.

Creativity is a skill you developed through focus and intentional practice.

You cultivate creativity by chasing your genuine curiosity and doing it for the sake of doing it.

Not for money. Not for fame. Not for recognition or status.

You do it because it is fun.

As a result of following your genuine curiosity, you become more creative. This helps you make novel discoveries which then helps you attract supporters to your work without even trying.

# 5 steps to become disgustingly creative

Everyone is inherently creative.

In the 1960s, NASA did a study. They found that 98% of kids aged 4-5 were considered geniuses.

But when they became adults, only 2% of them were geniuses.

2%…

Schools and society beat creativity out of you.

Their job is to create obedient workers. Not creatives. Because being creative is too dangerous for the boss.

Throughout history, the most creative people — artists, philosophers, writers, musicians, and thinkers — were the most dangerous.

Because they challenged societal norms and refused to fit in. That’s what makes them so dangerous.

Nobody can “teach” you how to be creative.

Because if they can teach you, then it ceases to exist. People can only give you their methods and show you their processes, but they can’t teach you how to think. If they do, then it’s no longer your thoughts, it’s theirs. And so you’re not being “creative”.

[![](https://substackcdn.com/image/fetch/$s_!NQ1a!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F52efe586-a4f5-4b00-9cfa-dbf9452eea9a_1000x1000.png)](https://substackcdn.com/image/fetch/$s_!NQ1a!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F52efe586-a4f5-4b00-9cfa-dbf9452eea9a_1000x1000.png)

_Credit: @thedankoe_

You need to start a one-person business. Not just to make money. But because it will force you to expand and learn new things.

Creativity does not exist if you’re never challenging yourself.

Creativity comes as a result of being in flow state. The state of effortless effort, where hours pass and they feel like minutes, where you get so consumed with your ideas and work that everything around you ceases to exist.

This only exists if you take on new, interesting challenges.

But there’s a sweet spot.

If the challenge is too high, you become anxious.

If the challenge is too low, you become bored.

You need a challenge that is _just_ outside of your skill level. This forces you to learn, hunt, and experiment with new knowledge to find what works and what doesn’t.

The goal is to stretch, not snap.

In that process, creativity shines.

Creativity, when you dissect it, is the ability to think out of the box to achieve a desired outcome. It is you doing both modes of thinking, divergent and convergent thinking. You use divergent thinking to find new knowledge and explore new paths. You use convergent thinking when you find a method that works and personalize it to fit your specific needs and goals.

The good, meaningful, and creative life comes from taking on interesting challenges. This leads to personal growth, fulfillment, and happiness.

Again, this is why I preach a lot about one-person business and writing.

Because these are the vehicles that will drive your personal growth.

You can explore your curiosities, build products, write about amazing ideas, meet amazing people, have life-changing conversations, all from something that costs you $0 to start and run.

So, I wanna show you how I use my one-person business as a way to become more creative and grow as a person.

What I’m about to give you is the general framework I use to generate ideas and write my content.

You will have to do your own work here and come to your own conclusions. Just like I have, and many other people have as well.

But the beauty of this method is that everyone will have a different starting point and will go on different paths.

Enough yapping from my side.

Here’s the framework:

# 1) Pick 2-3 topics or interests you want to talk about

I can’t help you much with this step.

You should already have something in mind.

Whatever these three topics are, write them down.

You don’t need to be the best at them.

Because when you combine all three interests, you can become the most qualified person in the world. Nobody can be as good as you at all three at the same time.

# 2) Go up one level & dig deep

Most people make the mistake of being too niche.

I’m sorry, but not many people are interested in learning about "molecular plant biology”.

Even worse, there’s only so much you can talk about before you start repeating yourself (or without boring your audience to death).

Go broad.

Think big picture and big umbrellas.

This will give you room to think of new ideas.

For ideas to exist, you need space.

If you box yourself in a small niche, you’ll find it hard to keep finding new ideas.

For example, one of my main interests is writing online.

But that’s too limiting.

So when I move up one level, I see that writing falls under One-Person Business.

_It can fall under many different things, like mental health, but I’m not interested in mental health._

When you go to a higher level, you start to notice that you can talk about many different topics at the same time.

To continue on with the example, with the one-person business, I can talk about sales, marketing, offer creation, audience-building, writing, psychology, and so much more.

When you go to a higher level, this is what I like to do:

- Break it down to 3-5 subtopics.
- Break those subtopics even further.
- Write down 3-5 people I look up to in each space.
- Write a list of books you have read/want to read.
- Write the different podcasts that you like to listen to for each interest.

This is an example of what my Brand Domains are like:

[![](https://substackcdn.com/image/fetch/$s_!u-2g!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc679108e-eb24-47da-a4fb-9684a505f07b_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!u-2g!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc679108e-eb24-47da-a4fb-9684a505f07b_1920x1080.png)

Immerse yourself in each domain and gain specific knowledge.

To have great ideas and unique content, you need a high-quality source of content.

You need to be constantly consuming content.

High-quality input = high-quality output.

# 3) Consume with intention

> _“When you take stuff from one writer, it’s plagiarism, but when you take from many writers, it’s called research”- Wilson Mizner_

Most people are consumers.

They watch content for the sake of entertainment and nothing more.

It’s mental masturbation.

You’re clogging your mind with

They only consume content for the sake of entertainment.

You think what you’re doing is finding inspiration, but what you’re doing is just clogging your mind with junk.

**Consuming content for the sake of entertainment is mental obesity.**

What should you do?

Being intentional with what you listen to, read, and watch.

Always be on the hunt for great ideas.

When you find a great idea, stop consuming and start writing about how it made you feel and why it caught your attention.

For example, this letter was inspired 2 books I’m currently reading:

1. _Flow by Mihaly Csikszentmihalyi_
2. _Think on These Things by Jiddu Krishnamurti_

Now they didn’t specifically talk about how to become creative.

In the book, Flow, the author talked about intentions and psychic energy.

In the book, Thing on These Things, the author talked about education.

I liked what they were talking about. I wanted to find a way to relate their ideas to one-person business.

That intersection turned out to be creativity.

_**Original ideas are a result of curation.**_

That’s all what content really is.

You consume from multiple sources, across different domains, pick ideas you’re interested in, and tie them together with your perspective.

# 4) Look for new experiences

> _“All ideas are second-hand, consciously and unconsciously drawn from a million outside sources.”- Mark Twain_

Every human is unique.

Every interaction, thought, experience, conversation, idea, and emotion you had has shaped you into the person you are today.

Just like I can’t give you all the tiny lessons, failures, and wins that I have learned unconsciously,

Your lived experiences are the “original” part of your ideas.

AI can’t fake your experiences or perspectives.

I can give AI everything it needs to know about me and write a newsletter that sounds just like me, but it’s not me. It does not have my experiences, perspectives, beliefs, emotions, and feelings. Which makes it not me.

No matter what the AI bros tell you. AI can’t replace the human element in writing.

This is your unfair advantage when it comes to the modern world. When everyone is moving towards volume and outsourcing their writing, thinking, and creativity to AI, the people who leverage their unique experiences will win.

Authenticity is a rare commodity in today’s economy.

Write about ideas you care about. Share perspectives you believe are true. Talk about ideas from your personal experiences.

If you think your life is boring, then go do something.

Move abroad with no money. Quit your job with no plan. Travel the world. Start a business with no experience. Launch a product knowing that it will fail. Approach the girl who’s out of your league. Live in the woods for 6 months. Learn to become a monk.

I don’t care what you do, just do something.

Collect experiences and reflect on your life so you have something to talk about and useful perspectives to share with the world.

# 5) Refine & Iterate

> _“The idea of the tractor couldn’t exist until the shovel was built”- @thedankoe_

How much time have you wasted searching for the perfect idea?

You need a bad idea first to have something to iterate on.

I see so many people depriving themselves of the chance of creating because they don’t have a “good idea”.

I’ll let you in on a secret:

**Most of my newsletters feel like incomplete and shitty ideas.**

But I don’t let that get in the way of posting.

The beauty of writing is that you can always come back in the future and rewrite it.

It gives you something to keep working towards and something to build off of.

You don’t become a great painter by watching YouTube tutorials.

You must pick up the brush and draw on the canvas.

You’ll be shit at first.

But as you direct your focus on becoming better at it, you’ll start picking up on the subtle changes that will make you a great artist.

The same thing is with writing, drawing, designing, and everything that has to do with being creative.

Creativity is a muscle.

The more you practice it, the better you become at it.

Thank you for reading.

Enjoy the rest of your day.

Hussain

**P.S.**

If you want to grow your Susbtack, I re-opened the doors to my private community, Passion & Profit.

The goal?

Build your audience and help you make $5,000 from it.

You’ll have access to all my frameworks, systems, and prompts that helped me generate 86M+ views, build an audience of 29,000+ followers, and make $65k+.

Doors close in 96 hours.

[Claim your 2nd Founder’s price.](https://hussainibarra.thrivecart.com/passion-profit-copy-1/)


---

<!-- Archivo original: posts/2026-05-17-the-meaning-crisis-why-your-life.md -->

---
titulo: "How to stay relevant in the next 10 years (do these 4 things)"
subtitulo: "How to make the most out of your 20s"
fecha: 2026-05-17T17:36:32.853Z
url: https://hussainibarra.substack.com/p/the-meaning-crisis-why-your-life
audiencia: gratis
palabras: 4092
likes: 51
comentarios: 5
---

# How to stay relevant in the next 10 years (do these 4 things)

_How to make the most out of your 20s_

We’re living in a crisis now and no one is talking about it.

There has been a rise in people in their 20s and 30s feeling like they’re behind in life.

They don’t know what to do with their life. They feel lost, anxious, and unmotivated to do anything.

So this letter is for those who want to do great things in their life but don’t know how.

If you’re someone who wants to do great things, want to wake up again feeling motivated, or simply have something to look forward to, read this.

It doesn’t take a genius to notice the problems that we’re struggling with nowadays.

We’re addicted to our phones. Disconnected from our families. Stopped going out in nature. We’re further away from god than we’ve ever been. No one is enjoying their work. Young adults and teenagers are dating less. The education system no longer works (because no one can get a job anymore). Inflation is making normal, everyday living almost impossible. Throw AI into the mix, and you’ve got a perfect recipe for a meaning crisis.

People have more free time on their hands than they know what to do with. This makes their minds wander and question everything they’re doing and they only come to one conclusion:

_“Is this it? Is this what life is all about?_“

> **“Older people talk a great deal about all these inessential things that have no importance in life; so gradually they communicate to the children their own anxieties, fears and superstitions, and the children naturally repeat what they have heard.”- Jiddu Krishnamurti**

Far too many people have become victims of inherited stupidity.

People adopted beliefs, ideas, and traditions from their parents that have been passed down from generation to generation without any questioning.

Now everyone thinks it’s the law. And if you try to question it, then you’re labeled as a troublemaker.

My advice?

Question everything.

- Question the traditions.
- Question the ideas.
- Question the methods.
- Question what you think is possible and impossible.
- Question what you think is true and what is false.
- Question the path that everyone has taken without giving it a second thought and see where it’s leading them.

Just look around you.

Everyone is either at work or they’re dreading the idea of getting up tomorrow and having to go to work again. There is very little desire to experience the great and beautiful experiences that life has to offer. They are too busy numbing their pain with cheap dopamine.

Scrolling. Drinking. Partying. Drugs. Disconnection. Dissociation. Depression. Isolation. Anxiety. Lack of stability. Survival mode. Fear of being left behind. Fear of being alone. Lack of motivation.

These are all signs of the meaning crisis.

So what do you do?

How do you find your meaning in life?

Is it possible to create a life where meaning, wealth, and creativity all intersect?

That’s what this letter is all about today.

Let’s dive in.

# The Meaning Crisis (How the hell did we get here?)

> **“Anything truly revolutionary is created by a few who see what is true and are willing to live according to that truth; but to discover what is true demands freedom from tradition, which means freedom from all fear.”- Jiddu Krishnamurti**

Your entire life you’ve been told what to do.

Your parents, teachers, extended families, and politicians are all telling you the same thing: _“Go to school. Get a job. Marry someone. Adopt a dog. Have kids. Buy a house. Retire.”_

You haven’t had the chance to think about the kind of life you wanted.

That’s society programming you.

The worst thing we’ve done in modern society is that we have made productivity, status, wealth, and power our gods.

People are rushing from one task to another. They try to fill every second of their lives with something productive.

- Listening to an ebook while doing the dishes.
- Putting on a podcast when they’re going to the gym.
- Reading a book because they were told that’s what successful people do.
- Waking up at 5 AM to meditate
- Going to sleep late because they were told to start a business

Doing everything you’re supposed to do is the bare minimum. And failing to do so means you’re lazy. They connected your value to your net worth and job title.

The worst part?

You hate the work that you do.

We’ve lost sight of what’s important in life. Social connection. Relationships. Friends. Fun. Play. Love. Creating. Rest.

Mix in the idea of how people are saying that god is not real and everything that happens in your life is your fault and you’ve got a recipe for disaster.

We’re now seeing people in their early 20s having a quarter-life crisis.

We’ve been brainwashed into thinking we can do everything and anything and be everywhere at all times.

You can’t.

Your brain is a computer.

You have limited bandwidth on how much information and tasks you can think of and do at any given point.

After 2-3 hours (which is the number of hours humans have as creative potent energy), you’re running on fumes. You can keep working for an extra 8 hours, but you’d barely make any progress.

Meaning is an internal job.

Nothing external can fix your internal state.

Just look around you.

Don’t you see how many successful and wealthy people are miserable?

Don’t you see how many celebrities have taken their lives because they were depressed?

These people have everything you want. The fame, the status, the wealth, the looks, the body, everything. Yet, they still feel empty inside.

Wake up!

How long are you going to keep your head buried in the sand?

You need to realize the path you’re taking and the future it’s leading you towards.

Is it going to lead to the kind of life you want?

If not, then do something about it.

I’m sorry for being harsh today.

But this is the reality.

You need to reflect on your life, question everything you’ve been taught and discover yourself again and see what you want.

Meaning, purpose, love, happiness, and everything that makes life great is an internal job.

### But why is meaning so important?

> **“It is only those who are in constant revolt that discover what is true, not the man who conforms, who follows some tradition. It is only when you are constantly inquiring, constantly observing, constantly learning, that you find truth, God, or love; and you cannot inquire, observe, learn, you cannot be deeply aware, if you are afraid.”- Jiddu Krishnamurti**

Humans are meaning-makers.

We attribute meaning to everything we do.

Just look at history.

Entire religions and spiritual practices were born just to assign meaning to our lives.

Because without meaning, what is the point of living? What is the point of your life? What is the point of doing anything?

The human mind cannot comprehend the fact that the struggle we go through is pointless. Making sense of your suffering is a huge part of finding joy and happiness in life.

- The single mother who works 2 jobs just to take care of her kids.
- The son who grew up in an abusive household and is now running a business.
- The soldier who came back from the army and is struggling to integrate back to society.

These are all people who are suffering. But because they are making sense of it, and assigning it a purpose, they are able to redirect their pain into fuel to keep moving in life.

I, for example, work quite a lot nowadays (close to 10+ hours every day).

I make enough money to support myself.

But the reason why I work so hard to keep growing my business is because I want to take care of my family. I have the goal of telling my mom and dad that they no longer need to look at any price tag anymore because their son can afford it.

So even though my work is mentally taxing and I feel stressed every single day, I still push through because I assign it meaning. The idea of “making it” so my parents can live comfortably makes me happy, and I am willing to make that trade-off.

Without meaning, you cannot achieve any goal.

Without meaning, you cannot operate anywhere close to your peak performance.

Without meaning, you cannot be happy (because for happiness to exist, sadness and pain must exist).

Without meaning, you don’t have a reason to do anything in life because there is no point to it.

# 6 stages to create meaning in life

[![](https://substackcdn.com/image/fetch/$s_!yd49!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F49aaf366-5a09-4733-b30c-5c2b0257c17a_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!yd49!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F49aaf366-5a09-4733-b30c-5c2b0257c17a_1920x1080.png)

_Credit: @hussainibarra_

Finding meaning is the same as saying what you think is worth suffering for.

That is the beauty of life.

When you choose your suffering, that is where enjoyment, purpose, and growth live.

But when suffering is assigned to you (say from your job), it becomes unbearable, boring, and creates chaos in your life (because you’re not the one who chose it).

If you want to live a happy, meaningful, and enjoyable life where calmness, love, and peace are present, you need to find your meaning.

There are 6 stages where meaning is developed.

### **1) Curiosity**

> **“Not knowing what you really want to do, your mind falls into a routine in which there is only boredom, decay and death. That is why it is very important to find out while you are young what it is you really love to do; and this is the only way to create a new society.”- Jiddu Krishnamurti**

Meaning comes from self-generated goals.

That means no one can tell you where to find it or how to solve it.

The only true way of setting goals for yourself is by chasing your genuine curiosity.

Your highest version of yourself is always communicating with you. They plant ideas and nudge you in directions so you can keep growing and pursue your purpose in life. When you don’t listen to it, that’s when you feel bad and sorry for yourself. Because you know you are capable of so much more.

But when you listen to the highest version of yourself?

You feel motivated.

You wake up and you’re suddenly curious about a topic and can’t stop learning about it.

When you’re chasing your curiosity, you lose touch with reality. Time moves differently. 5 hours go by and it feels like 5 minutes. Effort feels effortless.

Chasing your genuine curiosity feels like play.

### **2) Struggle**

This is where most people quit.

The 2-week honeymoon phase is over and you’re now in the trenches. Everything you do doesn’t seem to work.

Welcome to Beginner’s Hell.

It’s where in the next 6 months everything that you do doesn’t work. You feel dumb and worthless. But Beginner’s Hell is nature’s way of filtering out those who are serious and those who are not.

Struggle is a crucial part of finding meaning. Without it, then you wouldn’t be able to create a strong enough reason to pursue it.

The problem here is most people quit because they have been led to believe that if they’re not naturally talented at the thing they’re trying (which nobody is talented at first by the way), then it’s not for them.

How do you think you can bench press 225 lbs if you’ve never even tried lifting 100 lbs?

You need to start with the 100 lbs. Then progressive overload by adding more weights each week till you can bench 225.

The same thing applies to anything in life.

You need to learn how to stand first before you try reaching for the ceiling.

Without struggle, you won’t be able to tell what is worth doing and what is not.

Without struggle, you won’t be able to create a story (which is how we assign meaning).

Without struggle, you will not have anything worth pursuing (because everything feels easy and so you get bored).

Without struggle, you won’t have a reason to improve and will put you in a state of complacency (which leads to decay, atrophy, and entropy).

### 3) **Setting a goal**

Humans are a goal-striving species. Without goals directing your focus and consciousness, you feel lost and depressed.

Your mind is always working towards a goal, whether you’re aware of it or not.

That means, when you think you don’t have a goal, you default to your natural programming (the one that society installed), and now you’re working towards _their_ goals, not yours.

And if you want to see where that will lead you, look at the people around you. See where they are.

If you don’t take control of your life by setting goals, then you’re choosing to be average.

> **“He who has a why to live can bear almost any how”- Friedrich Nietzsche**

A goal is simply choosing what you want to suffer for.

It gives your suffering meaning and purpose and something to look forward to at the end.

If you don’t have a goal to chase, people will tell you what goals to go after.

They will assign you “suffering” that you never signed up for. This is why people are now getting fed up with traditional employment. They realize that they didn’t choose what to suffer for. They were assigned goals and a life that they never signed up for.

This is why you need to set a goal. It will give you something to work towards. It will give you a reason to keep pushing.

### 4) Exp**loration, experimentation, and education**

Become a truth seeker.

The world is built by truth seekers.

Those who are willing to dive into the unknown, hunt for new knowledge, discover new paths, and help others walk them.

No one can give you a roadmap. No one has a magic wand to wave and give you all the answers you want. All people can give you is advice on what has worked for them.

Your path will look different.

Just as there are infinite ways to play a game of chess and still arrive at the same end state (win, lose, or draw), there are infinite ways to arrive at the goals you have.

You need to self-educate, experiment with people’s methods and solutions and arrive at your own conclusions.

Create a plan, try, fail, and iterate. Become the mad scientist who is willing to do crazy sh*t in what we call life and make novel discoveries.

### 5) **Creativity**

Creativity is self-expression.

This is where most people feel alive and happy.

To be in a creative state of mind, you need a lot of different pieces to click together.

You can’t have money problems (at least at that moment), you need to have a goal, you need to find a problem to solve, you need to have the right skills to solve the problem, and a vision of where you want to be.

Creativity is where most people find their true selves.

- A chef finds it in his cooking.
- A writer finds it in the books she writes.
- A founder finds it in the product he’s creating.

### 6) Pur**pose**

Creativity is a selfish activity.

You do it because it makes you feel good and that’s it.

But when you have purpose, it’s different. It’s creativity but directed outwards.

In stage 5, you hide your work behind closed doors.

But in this stage, you take it public.

You start sharing your work with the world. It’s a pulling force that pulls you to share it.

Everyone finds their purpose in life differently.

This is why I say nobody can give you meaning.

You must give it to yourself.

It can be sports, writing, business, fitness, cooking, painting, making music.

The only way you can discover your purpose is to chase your genuine curiosity, setting a goal, self-educating, experimenting, and failing, to finally discover what it is that makes you most alive. When you experience the joy of creativity, you will feel inclined to share it with the world and wanting others to do the same. That, my friend, is purpose.

It all comes from chasing what _you_ want, not what others told you to want.

# Becoming a Creator (How to create a life of meaning, purpose, and profit)

[![](https://substackcdn.com/image/fetch/$s_!XHQD!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdd35659a-92f2-49c8-8383-f9354f1baa70_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!XHQD!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdd35659a-92f2-49c8-8383-f9354f1baa70_1920x1080.png)

_Credit: @hussainibarra_

I’ve never believed in the idea of work-life balance.

It implies that you hate the work you do.

- If you hate doing something, then why do it?
- Are you only working for a paycheck?
- Why don’t you just find something else you enjoy doing?
- If you’re going to spend the next 30-40 years working 8 hours a day (which is a huge chunk of your life), why not spend it on something you enjoy?

Excuse me for sounding like a pretentious asshole, but work-life balance is for those who gave up on themselves, gave up on the agency they were given, and let society dictate their entire lives.

I am a firm believer that anyone can chase their genuine curiosity, build amazing products, make money, feel happy, and have complete control over their lives purely by expressing their unique perspectives, skill sets, experiences, and creativity.

Today, as I am writing this, I woke up at 4 AM, went for a 12km run at 5, and now, it’s 11AM and I’m writing this letter.

Once I’m done, that’s it. My work for the day is over. I am free to do whatever I want.

The internet changed the game.

What used to take a team of 20 employees, you can now run all by yourself with technology, AI, no-code tools, and social media, at a fraction of the cost.

The only thing that is stopping you from achieving it is your self-limiting beliefs and the programming of society that told you it’s impossible.

I am not saying that it will be easy. It will be hard. But your work is also hard. Maybe even harder because of all the entropy it creates in your life.

If you want to make money doing something you love, this is the method I found that works:

### I - Start by solving the problems that are staring you right in the face

If you don’t know what problems to solve, start with the problems staring right at your face.

Hit the gym. Good looks matter. It doesn’t matter how unfair you think it is, people do judge by how you look.

Get good at speaking with other people. How else are you supposed to go on dates, find a partner and create meaningful relationships?

There’s no point in being successful but having no one to share your success with.

Make money.

No, money is not evil.

Making money will solve all of your money problems. You can get better healthcare, live in a better neighborhood, give more to charity, help your friends who are in a pinch. Money impacts every area of your life (whether you’re aware of it or not). The key is not getting sucked into the trap of making money for the sake of money.

Money is a tool you use to get what you want.

Most people haven’t figured this out.

### II - Use social media as your public journal

Document your journey on social media.

No, you don’t need a fancy setup. Or an expensive camera. Or even show your face.

You can write content (on Substack or Twitter).

You’re not being judged for how you look, speak, act, or your skin color or ethnicity.

You are being purely judged for the ideas you share.

This is why I love writing so much. It’s better for an introvert (like me).

And no, you don’t need to be an expert to post.

If you are interested in an idea, you can write about it.

If you can talk about the idea with a friend, you can write about it.

If you can explain an idea in your own words, you can write about it.

The internet is filled with average people who managed to build big audiences, make money, and share their interests with the world, simply by having the courage to share their ideas.

Posting content will feel cringe:

- Until you meet like-minded people
- Until you build an audience who trusts you
- Until you become friends with the people you looked up to
- Until you see the impact you make on people you don’t even know
- Until you start working with people and brands you never thought were possible

Create the content you wish to see in the world.

If you’re new to social media, you can get any $50 social media course to get you started (_If you want,_ _you can join [Passion & Profit, and get access to all of my systems](https://hussainibarra.thrivecart.com/passion-profit-1/))._

Use social media as a way to teach people what you learned and discovered. This is how you attract like-minded people to your world.

### III - Distribute your value to society

You need to start a business.

And I’m tired of hearing people say that “businesses are evil”.

Businesses aren’t evil.

A business is how you provide value to society and help mankind take a step forward and make the world a better place.

The phone you’re reading this letter from. The chair you’re sitting on. The light that you’re using. The car you’re driving. The shower that you use. They exist because a business created them.

You can try to start a charity where you solely rely on donations but that’s not sustainable.

If you want to pursue your meaning in life, you need to have a source of income coming in. You can get a job at first, but you’ll quickly hate it because you’re realizing just how much time and mental energy it’s taking from your life that you could’ve used in pursuit of your meaning and business.

If you want to do what you love for the rest of your life, you cannot operate from a place of scarcity. Nothing sustainable or great has ever been built from scarcity.

You need to operate from a place of creativity.

Creativity strikes when your mind is calm.

Your mind is calm when you have abundance.

Abundance in money, knowledge, love, and faith.

It’s much easier, more fulfilling, and profitable to create your own products and sell them.

Turn the knowledge you already have into a product (this can be coaching, consulting, courses, communities, templates, AI prompts, swipe files).

Anything that can be used to transfer knowledge, solve a problem, or help people achieve a desired outcome is a product idea.

Share your product with your audience.

You already have people with similar interests to you and will most likely struggle with the same problems you have already solved.

All you need to do is invite them to invest and they will buy.

### IV - As you level up, take on new interesting challenges

Problems are the cornerstone of a good life.

Most people see them as something to avoid at all costs, but if you want to live a meaningful, purposeful, and profitable life, you need to become a problem-solver.

One of the main reasons why so many wealthy individuals are miserable is that they have achieved a level of wealth where they can outsource all of their problems to others. So now they have so much time on their hands, and they don’t know what to do, so they become a victim of entropy.

As a human, you always need a goal to be working towards.

Use money, technology, and labor to outsource the work you don’t want to do so you have more free time solving the problem you enjoy solving.

When you solve a problem in your life, move on to the next.

Create new knowledge.

Create products that you wish existed in the world and would have helped you.

Share your products with your audience in exchange for money.

Repeat the process.

Thank you for reading.

Enjoy the rest of your day.

— Hussain

**P.S.**

If you’ve been struggling to create your product and don’t know where to find your first 3-5 paying customers...

In 24 hours, I’ll be opening the doors to 3 Weeks To Profitable.

3 weeks. 6 live calls. Your first product. Your first 3-5 paying customers.

That’s the promise.

It is the complete system that has helped me make $21,000 in the last 3 months selling digital products.

Stay tuned.


---

<!-- Archivo original: posts/2026-05-31-how-to-finally-escape-beginners-hell.md -->

---
titulo: "The fastest way to grow on social media (with zero followers & experience)"
subtitulo: "How I gained 33,000 followers in 19 months (and how I'd do it again if I had to)"
fecha: 2026-05-31T15:39:53.495Z
url: https://hussainibarra.substack.com/p/how-to-finally-escape-beginners-hell
audiencia: gratis
palabras: 3034
likes: 289
comentarios: 36
---

# The fastest way to grow on social media (with zero followers & experience)

_How I gained 33,000 followers in 19 months (and how I'd do it again if I had to)_

Content creation changed my life.

4 years ago, I was a broke college student, making $500/month, living off of the 2 meals my university provided.

Couldn’t eat out. Couldn’t afford coffee because it was out of my budget. Wouldn’t go out on the weekends because I couldn’t afford dinner.

So in 2023, I started writing online.

Didn’t have any social media experience. No skills. No money.

**A complete beginner and dead broke.**

I still remember saving up for 8 months just so I could afford Dan Koe’s 2 Hour Writer and Kieran Drew’s High Impact Writing courses (still one of the best investments I ever made).

And let me tell you…

My first 16 months of writing were absolute hell.

- 3 months to get my first 100 followers and make my first $20.
- 16 months to reach my first 1,000 followers.
- 17 months to make my first $1,000/month.
- 19 months to my first $4,000 month.

But today, as I’m approaching my 3rd year of writing online, I’ve now:

- Gained 90M+ views
- Built an audience of 33,000+
- Make over $8,000+/month doing what I love.
- My Monday mornings are the same as Saturday mornings.

And the best part?

I have a life that I’m absolutely in love with.

I workout for 3 hours a day, build products I love, and help people improve their lives.

I also get to make decent money doing it.

[![](https://substackcdn.com/image/fetch/$s_!Ex_P!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6bd50ac7-2eaf-4577-9a8d-a1a8e18db00c_928x510.png)](https://substackcdn.com/image/fetch/$s_!Ex_P!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6bd50ac7-2eaf-4577-9a8d-a1a8e18db00c_928x510.png)

I cringe whenever I post screenshots like these. But I do know how powerful it is when it comes to motivating people.

A huge reason why I have this lifestyle now?

**Building an audience.**

Without an audience, you don’t have a business.

Why?

Because to start a business, you need customers, and what better way to find customers than to build an audience first?

**Here’s why an audience is the best way to start a business:**

- They already know you and trust you (which makes selling a product a lot easier).
- You don’t need to do cold outreach (your audience already has your customer avatar).
- When you have an audience, you can pivot, create new products in different spaces, and still have people buying regardless.
- You don’t need to spend money on ads to market your products. You can simply promote your product to your audience and get customers.

I can keep going, but I think you get the point.

# Why you can’t get out of beginner’s hell (even when you’re doing everything right)

6-12 months.

That’s how long it takes people to get out of beginner’s hell.

I’ve now coached over 30 creators. Helped them gain tens of thousands of followers and make over $20,000+ in student wins.

I’ve also talked to 150 more creators.

From all of the conversations, there are 3 mistakes that keep people stuck and unable to grow.

### Mistake #1 - You can’t commit to a strategy

Social media is filled with FOMO.

Everywhere you look, you see someone post about a brand new strategy that has helped them add 1,274 readers in 24 hours, and your mind thinks: _“This is what I need to be doing.”_

Then you add it to your workflow.

Tomorrow comes around, then you see some other random guy say something similar about a different strategy, then you try that one.

Don’t you realize what you’re doing?

You can’t grow because you’re not committed. You keep switching, _hoping _something works.

My friend, all of these strategies work.

You just need to commit long enough with one to see results.

If you’re trying 5 different things at once, you’re not going to improve or learn anything. You’re doing a whole lot of work for not a whole lot of results.

Pick one, commit to it for 90 days, and if you don’t see the results you had hoped for, try another one.

But for the love of God, don’t switch strategies every day. You won’t see any results like that.

### Mistake #2 - You’re relying on tactics too much

Trends come and go.

That means if you always rely on the latest “hack”, you’ll always struggle to grow.

Because once a trend dies, you’re back to square one and can’t grow. Then you’re forced to change strategies or your content to continue to grow.

Don’t get me wrong.

I’m not saying don’t use templates and structures.

I follow trends, use templates, and structures myself.

But what I’m saying is don’t follow trends blindly. Don’t use templates without trying to understand what makes them work.

You need to be conscious of what you’re creating.

Dissect everything.

When you’re using templates, ask yourself:

- How do they capture attention?
- How do they deliver on the idea?
- How are the hooks written?
- How is the post structured?
- How does it make the reader feel?

Use templates as training wheels to understand what makes a great post.

### Mistake #3 - You’re trying to grow everywhere

This is a mistake I’ve seen many beginners fall for.

They see a guy with millions of followers and his content workflow.

- A newsletter gets turned into a podcast, 20 tweets, 3 threads, and a YouTube video.
- His tweets get repurposed to Instagram, LinkedIn, Threads, and Substack.
- His YouTube video gets clipped and turned into 15 Reels and TikToks.

It's a whole system from just _one _piece of writing, his newsletter.

So then you try to do the same.

But what you don’t realize is that that’s his FULL-TIME JOB.

That’s what he does for a living.

And also, he already has the audience to do it. That means he already had an audience on Twitter/X and so when they started posting on Instagram, they could funnel their Twitter audience to Instagram and use that to boost their initial growth.

You don’t even have 200 followers on any platform.

You have a job, a partner, friends, a mortgage, and a million other things to do other than just writing and creating content.

What people also miss is that every platform works differently. Different hooks work on different platforms. What works on Twitter doesn’t work 100% on LinkedIn.

_People on LinkedIn are more interested in work-related topics. Not so much about self-improvement, philosophy, or writing._

So where should you start creating?

Substack.

Why?

Because it does two things really well.

1. You can host your newsletter on it and it acts as a blog (so every newsletter gets saved).
2. It has a built-in growth mechanism for your newsletter with Notes (which is basically tweets that people see on their timeline and then they can join your newsletter).
3. Your newsletters get posted to people’s timelines (this helps you get discovered by people who aren’t subscribed to your newsletter).

Even though I’m a huge Twitter/X fan (because I like how unhinged the platform is), Substack is great for growth.

In just the past 30 days, I gained 1,300 new email subscribers from Substack alone.

So how do you do it?

How do you actually grow an audience?

How do you finally escape beginner’s hell so you can start earning money from it?

Let me show you.

# How to finally escape beginner’s hell (in 2026)

Let’s get one thing straight:

**You don’t need to be on 5 different platforms at once.**

You need to get good at growing on one platform.

Once you learn the skill of how to grow an audience (yes, building an audience is a skill that can be learned), then you can start thinking of adding another platform to your mix.

My advice:

Grow on one platform.

Get really good at it.

Once you have some sort of audience (10,000 followers minimum), then you can use your already existing audience to fuel your audience growth on a different platform (_your followers want to see more of you)._

I started posting on Substack when I had 19,000 followers on Twitter.

In my first 24 hours, I gained 2,400 followers.

How?

I funneled my audience from Twitter to Substack and used it to fuel my initial growth on Substack.

That’s what you need to do.

Do not start from zero on all platforms and try to grind your way out.

Here’s how I’d grow an audience (as a complete beginner).

## I - Pick a topic you’re interested in

This is pretty straightforward.

Pick a topic you can’t shut up about. The one where you can speak for hours on end without getting bored. One that excites you whenever someone brings it up.

Writing content is easy when you write about something you love.

## II - Create your tribe of mentors

Your success as a creator depends on the quality of your ideas.

The quality of your ideas is entirely dependent on the content you consume on a daily basis.

The 2-4 hours you spend scrolling on your phone.

- What are you watching?
- Is it useful?
- Is it educational?
- How does it contribute to your success as a creator?

You need to be highly selective about who you follow, watch, and listen to.

If you’re struggling to find ideas or feel like your content is shit, you need to increase the quality of your input (content you consume).

Go on a social media diet.

Curate your algorithm to only give you high-quality content and not some brain rot.

Create a list of the creators you look up to.

The ones that make you think:

_“Damn, I wish I wrote that.”_

These are the people you need to be consuming.

They will help you find ideas, become more articulate, and take action.

[Inside of Eden](https://eden.so?via=hussain93) (the software I use to write and create all of my content and products), you can create a list and add these creators.

For example, I have a list for creators who are in the one-person business niche.

[![](https://substackcdn.com/image/fetch/$s_!deiJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F42401e33-f448-4f6c-a1b1-dd012b56f52a_1648x988.png)](https://substackcdn.com/image/fetch/$s_!deiJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F42401e33-f448-4f6c-a1b1-dd012b56f52a_1648x988.png)

_Then you can stalk them (like I do)._

The best part?

You’re not limited to one platform.

You can add creators from different platforms (Twitter, Substack, IG, TikTok, LinkedIn, YouTube) to the same list.

Now, you have a curated feed to consume and go to whenever you need inspiration.

## III - Find high-performing ideas

If I had to summarize content creation to one point, it would be this.

If your goal is to get views, build an audience, and escape beginner’s hell, then you need to write about high-performing ideas.

Nobody reads your posts because they’re boring.

They want to see what they already like.

Do what works.

Scrolling your timeline is a horrible way to find ideas.

Go back to the list you created in Eden, and search for keywords.

For example, let’s say I’m trying to write a Twitter thread about stress. But I don’t know what angle to take, how to structure it, or make it interesting.

All I have to do is open the List I created, search for “Chronic Stress” and I have a list of already validated ideas.

You can even filter with “Top outliers” if you just want to see viral content.

So how do you find high-performing ideas?

[Inside of Eden,](https://eden.so?via=hussain93)you can go to the list you’ve just created (for your Tribe Of Mentors), and search for keywords.

For example, say I’m trying to write a tweet about stress.

But I don’t know how to make it interesting. I can search for “Chronic Stress” and I immediately have high-performing ideas.

[![](https://substackcdn.com/image/fetch/$s_!9pED!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fde3ff782-6ff8-4e84-a2e4-4eeace7702f6_1658x993.png)](https://substackcdn.com/image/fetch/$s_!9pED!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fde3ff782-6ff8-4e84-a2e4-4eeace7702f6_1658x993.png)

Now, you know what is already working.

You don’t need to guess what people want to see.

You can also see the hooks and their threads and spot the gaps and introduce a new perspective that no one talked about until now. This way, you get to see what’s already working for others and adapt it to your own content and benefit from it.

I’m not saying that you should copy others.

No.

What I’m saying is you need to know how to make your ideas interesting for other people to care enough about to read.

## IV - Use validated structures

Let’s be honest.

Your content probably sucks.

Mine did too.

For a long time I thought my content was great but when I reached rock bottom and was on the verge of quitting writing forever, I dedicated 30 days to studying great content, and my god...

**My content was horrible.**

If you want to capture attention and build an audience, you need to learn how to write high-impact content.

The easiest way to write high-impact content?

Listicles.

Why listicles?

- They are easy to write.
- They deliver value quickly.
- They hold the most attention.
- They have the highest word-to-value ratio.
- They help you condense big ideas into small, digestible chunks.
- They are the highest-performing pieces of content across all platforms.

The way I write my listicles is something like this:

1. Make a strong claim in your first line
2. Follow up with 3-5 actionable steps people can take
3. End with a hard-hitting line so people remember you

Let’s say my idea is “how to change your life”.

If I wanted to write a listicle, it would be something like this:

> _6-12 months is all it takes to completely change your life.- Remove distractions- Cut out toxic friends- Disappear from society- Laser in on ONE big goal- Find the 3-5 level-moving tasks- Execute like a madmanYour friends, phone and hangouts can wait.Your future cannot._

You can also find structures that have worked in the past for others and use the same structures to mold your ideas.

When you’re using structures, frameworks, and templates, don’t make the mistake of just copying without thinking.

Do it intentionally. Do it for the sake of learning and understanding _why _it works.

_“But Hussain, I don’t want to copy others.”_

Don’t you get it?

You still have a small audience.

Your goal isn’t to be the most creative and original. Your goal is to simply understand the game, and once you understand it and are consistently growing, start experimenting with different methods and be creative.

## V - Create a record of your best hits

At this point, you should start seeing some results with your content.

Your engagement has picked up, audience is growing, and you know what you’re doing. You also have a few posts that went “viral.”

Virality is subjective. It depends on your audience size and engagement levels. What I consider viral is someone else’s “average post”.

A few reasons why you should do this:

- You create a database of your own “validated ideas.”
- Whenever you don’t know what to post (or don’t have time to write), you can just copy and paste one of your Best Hits and post it again.
- You discover patterns that work exclusively for you.

Every week, I go to Eden, search for my own account, and look at my posts.

Any post that “went viral” (got over 100 likes on Twitter), gets added to a board called my Best Hits.

[![](https://substackcdn.com/image/fetch/$s_!bZ0p!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff0109332-23e8-44a5-8294-96f89a02e8df_1662x987.png)](https://substackcdn.com/image/fetch/$s_!bZ0p!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff0109332-23e8-44a5-8294-96f89a02e8df_1662x987.png)

Whenever I need to write a tweet, or forget to schedule one, or am simply too busy to write I can copy and paste any of these tweets and I know they’ll do well.

Very simple. Very effective way of growing.

## VI - Keep doing it until it stops working

Your audience is literally telling you what they want to see from you.

Your Best Hits is what your audience wants to see.

It is how you get more engagement (from your existing audience) and also exposes you to a wider audience (because the algorithm will push your content more when it sees it’s getting engagement).

I’m pretty shameless when it comes to repurposing my content.

If a tweet does well, I reuse it within 2-4 weeks.

I don’t change a word.

Just take a look at these two posts.

[![](https://substackcdn.com/image/fetch/$s_!Axj7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1d78b2ba-bfa7-4a5d-8f38-296f17207ec2_600x157.png)](https://substackcdn.com/image/fetch/$s_!Axj7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1d78b2ba-bfa7-4a5d-8f38-296f17207ec2_600x157.png)

[![](https://substackcdn.com/image/fetch/$s_!95Pd!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a5d6114-164e-4da9-a6fd-f3bc433d3c0c_594x157.png)](https://substackcdn.com/image/fetch/$s_!95Pd!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a5d6114-164e-4da9-a6fd-f3bc433d3c0c_594x157.png)

**They’re exactly the same.**

Didn’t change a single word, but still, the second time I posted it, I got 741k views.

It didn’t do as well as the first time.

But I didn’t put in any extra effort.

All I did was copy-paste my post and it has done well.

That’s not the only thing you can do.

You can also expand on idea that has done well.

Like what I did here:

[![](https://substackcdn.com/image/fetch/$s_!1NQx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3ba71119-ef9b-4601-9f9b-c93540df95a0_591x546.png)](https://substackcdn.com/image/fetch/$s_!1NQx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3ba71119-ef9b-4601-9f9b-c93540df95a0_591x546.png)

Because the tweet did well, it tells you that people like the idea. It’s a validated idea. Which means you can write a thread, a newsletter, or even create a YouTube video and expect it to perform well.

I turned the tweet into a thread.

And this was the result:

[![](https://substackcdn.com/image/fetch/$s_!0VuW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd2f695f2-238b-43c5-9749-b5d95266c91b_590x151.png)](https://substackcdn.com/image/fetch/$s_!0VuW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd2f695f2-238b-43c5-9749-b5d95266c91b_590x151.png)

I’m not reinventing the wheel.

I’m just following the signal.

Your audience is LITERALLY telling you what they want to see.

You just need to listen.

When you have a post that does well, it tells you a few things:

1. You have an idea that’s working
2. Your audience wants to see more about the same topic
3. You have a validated structure you can use for your other ideas

The worst thing you can do is have a post that does well, and then you let it pass you.

Milk it.

Take Dan Koe, for example.

90% of his success came from a few winning ideas:

- The 4-hour workday
- Your life is a video game
- The one-person business
- Psychic entropy & flow state
- Writing is the greatest skill of the 21st century

Look at his newsletters. They’re always around these 5 ideas.

He might take a different approach each time, but they’re always the same.

And he built an audience of 6M+ followers.

You don’t need new ideas.

You just need a handful and keep repeating them until that’s what you’re known for.

That’s how you build an audience in 2026.

That’s how you finally escape beginner’s hell.

Thank you for reading.

Enjoy the rest of your day.

— Hussain

**P.S.**

The tool that I’ve been using in this entire newsletter is called Eden.

It’s where I write all of my ideas, content, create my products, and store my prompts.

[If you want to try it for yourself, you can get a 7-day free trial here.](https://eden.so?via=hussain93)


---

<!-- Archivo original: posts/2026-06-24-youre-being-trained-for-a-world-that.md -->

---
titulo: "You have 24-36 months to make it (learn these 5 skills)"
subtitulo: "How to become AI-proof in today's economy"
fecha: 2026-06-24T21:04:25.376Z
url: https://hussainibarra.substack.com/p/youre-being-trained-for-a-world-that
audiencia: gratis
palabras: 4868
likes: 284
comentarios: 18
---

# You have 24-36 months to make it (learn these 5 skills)

_How to become AI-proof in today's economy_

> _**“AI will replace 50% of white-collar jobs in the next 2-5 years.”Dario Amodei, CEO of Anthropic**_

24-36 months.

That’s how long experts think it will take for AI to replace most jobs.

And I’m not talking about the low-level jobs.

I’m talking about white collar.

Accountants, economists, mathematicians, software engineers.

I’m not gonna bore you with the boring “AI doom is here, we’re all f*cked”.

There’s enough of that already.

But I can’t help but think about what it means for us, normal people.

What can we do when AI does all of our jobs?

What kind of work will we do?

Will we just be hooked up to some digital machine where we fry our brains with dopamine?

What kind of economy will we live in?

And what can you do to prepare?

I won’t stand here and pretend like I know what the future will look like.

For the past 4 weeks, I’ve been researching this topic and here’s what I wanna cover with you:

First, we’ll cover how fast we’re advancing as a species (which is insane btw), then talk about what kind of economy we’re living in nowadays (most people haven’t figured this out yet).

I’ll also share with you the 5 skills that humans have relied on throughout history (AI can’t replace these 5 skills).

And lastly, the one habit you need to do daily to become future-proof, and no longer have to worry about AI.

Buckle up.

This will be an interesting one.

# The speed of advancement is off the charts

1 million years ago, we controlled fire.

- Agricultural Revolution: 10,000 years ago
- Printing press (communication revolution): 600 years ago
- Industrial Revolution: 250 years ago
- Second Industrial Revolution: 150 years ago
- Digital Revolution: 80 years ago
- Fourth Revolution: 16 years ago

It’s clear that as technology advances, revolutionary changes happen more quickly.

With each revolution, humans have lost their jobs. It happened before with agriculture when we invented the plow. It happened again when we invented the printing press. The same with electricity, steam engines, machines, computers, and now, AI.

We went from fighting with swords, bows and arrows to nukes, rockets, satellites, and using horses to get around to self-driving cars in just 300 years.

Doesn’t this blow your mind?

And if you tried AI when it first came (2021/2022) out and weren’t impressed. Then let me tell you, those 4 years in the AI world are ancient.

Just so you understand the speed at which AI is advancing, here’s a timeline:

- 2018: GPT-1 was good at basic language tasks
- 2020: GPT-3 scored high school-level reasoning
- 2023: GPT-4 scored in the 90th percentile on SAT, LSAT, and medical exams.
- 2025: GPT-5 got the IMO Gold Medal

Then in February 2026, OpenAI (the company that created ChatGPT) announced that one of its new models, ChatGPT 5.3 Codex, was created, tested, and improved on by AI.

**AI JUST CREATED ITSELF.**

In the U.S., Claude (an AI model that’s being developed by another AI research lab, Anthropic) is being used in the government and army.

Claude was used during the mission when the U.S. extracted Maduro. This started a whole battle between Anthropic and the U.S. government in court.

But I don’t want to make this a political thing.

My point is, AI is getting good.

**Really f*cking good.**

The reason why AI is advancing so fast?

Because researchers realized that if AI could code, then they would’ve solved their biggest bottleneck:

Maximize speed and minimize mistakes.

This is why their first breakthrough was teaching AI how to code.

Now, software engineers are thinkers and leave all the technical aspects of coding to AI. They only code when there is something specific they need to do. Other than that, the first iteration of any code is created by AI. Because that’s what AI is so good at, going from idea to prototype.

What used to take a team of 10 software engineers to create can now be done with one software engineer and AI.

Coding, as a skill, is no longer valuable. Anyone and their mothers can create new apps nowadays. You need an idea, know how to articulate your idea to the AI model, and an unhealthy amount of AI credits and energy drinks.

Writing is the new coding language.

# What’s happening with jobs and AI isn’t something new

Technology has always replaced humans, and it always will.

It happened with the plow, the printing press, computers, and now AI.

The reason technology replaces humans is that humans are creators. We create solutions to our problems, and unfulfilling work is a problem.

Why is it a problem?

Because you spend a third of your life sleeping, a third of it working, and how you spend the last third depends on how much you enjoy your work and find it fulfilling.

If the work you do is unfulfilling or you hate it, you’ll be too tired to do anything when you’re back home (even if you barely did any actual “work”).

You can’t hit the gym, can’t eat clean, you argue with your significant other, so what do you do?

You fill it with mind-numbing activities. You scroll, watch Netflix, drink, smoke, do drugs, watch porn.

Anything to get you a quick dopamine hit.

You don’t realize it, but unfulfilling work is the source of most people’s problems. If they found something they love doing, they’d be happier, healthier, and in a better relationship.

If you’re going to spend a third of your life working, wouldn’t you want to spend it doing something you love?

If you don’t create your own work, you will be assigned one.

If you don’t know what you want to do, you will be told what to do.

If you don’t have a goal to chase, you will be assigned a goal.

If you don’t know what problem to solve, you will be told what to solve.

If you don’t think for yourself, you will be told what to think about.

If you don’t build your own life, you will build someone else’s.

If you don’t build your own products, you will build someone else’s.

If you don’t market your own products and skills, you will work for someone else.

If you don’t take control of your life, others will take control of you.

If you don’t create your own income, you will depend on someone else for your entire life.

If you want to live life on your own terms, you need to take control of it. You can’t let others decide for you. Think for yourself. Act for yourself. Take yourself seriously.

Taking control of your life is the highest form of self-love.

When I say take control of your life, I mean every domain of life.

Mind, body, spirit, wealth.

> _**“Treat yourself like someone you are responsible for helping”- Jordan Peterson**_

It means you care about yourself enough to give yourself the best life possible.

Most people treat their dogs better than they treat themselves and it’s sad because it means they don’t love themselves enough to take care of themselves.

# You’re being trained for a world that doesn’t exist anymore

[![](https://substackcdn.com/image/fetch/$s_!5Ei_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fca564de7-86f3-41ea-aa20-98d4b8d76528_2944x1648.png)](https://substackcdn.com/image/fetch/$s_!5Ei_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fca564de7-86f3-41ea-aa20-98d4b8d76528_2944x1648.png)

_Credit: Midjourney_

The current system that’s being shoved down our throats, the one that your parents, grandparents, and great-grandparents went through, doesn’t work.

You know, the traditional roadmap that’s given to everyone — go to school, get a job, retire at 65 — isn’t the answer anymore.

The current system was developed during the Industrial Revolution.

That system was never in your favor. It’s always been in favor of those who created it.

Who are they?

Well, it helps to know how the current system came about.

During the Industrial Revolution, factory owners wanted to increase their profits (as they always do). So they were thinking of ways to minimize mistakes and increase productivity.

How do you do that?

By turning every piece of the manufacturing process into a repeatable and systemized step-by-step process, so that anyone can do the job.

But also, they don’t want to spend resources (money and time) training their new employees. So they developed standardized tests and schooling to train people into being good, obedient employees who knew how to do the tasks, check boxes, and ask no questions.

Don’t you see?

The entire education system’s job is to turn humans into tools for their masters (corporations and businesses).

And as you’ve seen throughout history, tools get replaced by technology.

I genuinely believe that universities should be fined for teaching some of the programs they teach. They know a lot of what they teach has no real-world value, has already been replaced by AI, or will be replaced by AI before students can even graduate.

WAKE UP.

The old world of building a good life by purely relying on your employer is gone.

You can’t start a family, own a house, and live a comfortable life on a single income. Even when both parents are working, a lot of families are struggling to make ends meet at the end of the month.

You live in a different world now.

A new economy is being created as we speak.

# We live in the idea economy

Hard work is overrated.

Long gone are the days when you sit and grind for 8 hours a day and try to “outwork” everyone.

You now live in an age of infinite leverage.

You have infinite reach with social media. You can sell a million copies of a product with no fulfillment time.

The time it takes you to create content is the same whether 1 person sees it or a million. The time it takes to create a piece of software is the same whether one person buys or a thousand. The only time it takes from you is the time to create the piece of content or product. But once it’s there, it’s infinite leverage.

Working longer and “hustling” is hurting you more than you think.

Because when you operate in the domain of ideas, the person with the best idea wins. To have great ideas, you need to work less, not more.

Walk more. Read more. Write more. Think more. Play more. The best ideas hit you when you are away from work.

Leonardo Da Vinci was notorious for taking long breaks (2-3 weeks) when painting.

> _**“Men of lofty genius sometimes accomplish the most when they work least, for their minds are occupied with their ideas and the perfection of their conceptions, to which they afterwards give form.”- Leonardo Da Vinci**_

With AI, you now have Einstein and Da Vinci in your pocket.

The content is free. The tools are free. AI is already built. The entire infrastructure to start a one-person business is there.

You don’t need to be an expert or a genius to start a business. You don’t need any outside investment to start. You don’t need a warehouse to store your products. You don’t need to pay TV and radio stations to promote your products.

You can simply do it all with social media, no-code tools, and AI.

The only thing you need is an idea you believe in, a worldview, and a perspective to share with the world.

Just look at the vibe coding industry. It’s filled with ordinary people who have gone and built successful apps and products with no coding experience. The only thing they had was an idea they found interesting.

Ideas are like a virus.

You only need a handful of people speaking about your idea before it becomes contagious and everyone starts talking about it. When your idea spreads, you get to own mental real estate inside of people’s minds.

The world now operates in the domain of ideas.

The person with the best ideas wins.

# AI lowered the barrier to entry

[![](https://substackcdn.com/image/fetch/$s_!srCi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F265b24fe-2651-476c-9ea0-2c05eeb03abd_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!srCi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F265b24fe-2651-476c-9ea0-2c05eeb03abd_1920x1080.png)

_Credit: @hussainibarra_

Let’s be real for a second.

Couldn’t you have created the things you wanted to create without AI?

You could.

It would have just taken longer.

Maybe you needed to learn how to code, learn how to design, learn copywriting, marketing, and sales, and all the skills that you need to make whatever project you wanted to create happen.

You could have learned it all. The information has always been there, on YouTube, courses, mentorships.

AI has just reduced the gap from beginner to execution from months or years to a few hours or days.

Creative individuals can now finally just focus on their zone of genius (creating, ideating, imagining, thinking) and outsource all of the technical parts to AI.

Because the economy we live in now is different. We no longer operate in the physical economy. We operate in the idea economy.

If you have an idea, you can create content, attract supporters to your work, use AI to build your product, build a successful business, contribute to society, and make a meaningful living while doing so (without sacrificing your entire life).

# The future-proof skill stack (learn these 5 skills)

I’m not going to pretend like I have a crystal ball and tell you what jobs will be in demand or not.

Frankly, no one can. If anyone tells you that they have the answer, then they’re lying to you.

Also, most high-income skills will be replaced by AI in the next 24 months.

I’m talking about research, programming, math, design, you know, the skills that people spend decades mastering.

So is the solution to double down on them?

Nope.

Because AI can learn faster than you, make fewer mistakes than you, and doesn’t need to sleep. No matter how hard you try to specialize or how fast you learn, AI will catch up to you and become better than you at it.

So what is the solution?

You need to lean into what makes humans special in the first place:

**Your ability to create.**

There are 5 skills that humans have relied on to become the most dominant species on earth, conquer the tallest mountains, overcome the harsh environments, and go to the moon.

These skills, in my eyes, have always been in demand and always will be.

They can’t be taught in schools or universities.

If they can be simplified into a step-by-step solution, then you become a tool, and then AI comes back into the picture, then you’re at risk of being replaced.

You’ll need to go through these skills yourself, cultivate them and hone them through personal experience, self-development, self-education, self-experimentation, and self-reflection.

## I - Creativity

Everyone is born creative.

Schools just do a damn good job at beating it out of you.

NASA did a study in the 1960s. They followed kids since they were 3 until adulthood. They found that 98% of kids aged 3-5 were considered geniuses. But by the time they got into adulthood, only 2% of them were considered geniuses.

Schools kill your creativity because being creative means not conforming to the system that’s already been laid out. And that’s dangerous for institutions that are looking for obedient workers who clock in, check boxes that don’t mean anything, ask no questions, clock out, and repeat.

But let’s be honest, conforming to a system means being like everyone else. Average, fat, miserable, no goal, no ambition, no plans.

It’s f*cking boring.

Everyone is creative.

Creativity is a muscle.

It grows and becomes stronger the more you use it. But it also atrophies the less you use it. In life there is no such thing as “staying the same”. You’re either improving or decaying. This applies to the gym, to speaking, communication, memory, ability to learn, and creativity.

I still remember when I started writing online 3 years ago.

It was like fighting with a rusty fire hose just to be able to write two sentences together.

But today?

I can write for hours without ever stopping.

And listen, no one can teach you how to be creative or give you a step-by-step solution. Because when they do, that means you’ve adopted their thinking and beliefs and that’s not what creativity is.

Creativity is your ability to think outside the box.

No one can measure creativity. No one can test it. No one can put their finger on it.

Creativity, by definition, is supposed to exist outside whatever lines you draw.

Creativity appears differently for different people.

It can be poetry, coding, writing, building, design, art, marketing, product design, cooking, baking, research, reading, law, and so much more that I can’t even list out.

I feel the most alive when I’m in a creative state.

When you get a taste of creativity, it’s like a drug. You never want to stop. You realize just how fucking miserable it is to do monotonous, repetitive, and mind-numbing tasks.

If you’re bored in life, create something.

Anything.

Create music. Write poetry. Create a music beat. Write a song. Write a book. Create a clothing brand. Design a product. Design clothes. Redesign your room. Draw your perfect house. Create code. Build a software that you wish existed. For the love of god, create something.

It doesn’t matter if it’s good. Your mind is meant to create.

> _**“You feel bored, anxious, or overwhelmed because your mind wants ideas to flow but you won’t let them.”- Dan Koe**_

It’s in the act of creating and being in a creative state that you discover your true self.

Away from societal programming and beliefs that they have installed in you. Away from wanting to be “productive”. Away from chasing goals that others have set for you.

Create because you have something you’re interested in.

Create for the sake of creating.

It will change your life.

The more you create, the more creative you become. The more creative you are, the more future-proof you become. Because you get to operate on so many different domains, you see so much of the bigger picture and how everything connects that not even AI can see.

## II - Agency

Most people think of agency as “Entrepreneur vs Employee”.

Entrepreneur being the high-agency individual, and an employee is a low-agency. But that’s not the case. I’ve seen entrepreneurs who are low-agency and employees who have high-agency.

Others will say agency is your ability to do stuff. But you and I both know people who do a lot of stuff, set crazy goals, but 2 weeks into their side project or weight loss goal, they quit.

To me, agency is your ability to set your own goals and to keep trying and retrying, regardless of how many times you fail, until you achieve your goal.

To be “high agency” you need to be slightly delusional in other people’s eyes. For months or even years, you could be failing, and everyone will tell you to quit. But that’s only because they don’t see the vision you have. So you need to persist to get what you want.

- Learn to hunt (identify problems).
- Learn to solve (use AI to help with the technical side while you spend your energy on the big picture thinking).
- Learn to earn (build solutions for others to use in exchange for money).

Once you have agency in your life, AI can’t replace you. Because AI then becomes a tool for you to build the life you want.

It will help accelerate you.

## III - Taste

This is one of the hardest things to teach.

I’ve written over 30,000 posts, 300+ sales emails, and 150+ long-form newsletters like this one.

So I’ve developed the skill of knowing what makes a post do well and what doesn’t. What ideas to talk about and what ideas to avoid. How to frame “boring” ideas and turn them into interesting ideas.

Sure AI can write a 3,000-word article within minutes but that’s not the goal.

AI is great at volume.

But volume isn’t the answer.

Just because you can write more articles with AI, it doesn’t mean they’re good articles. More than 500 hours of content are uploaded to YouTube every minute. That’s 720,000 hours a day. Only a handful of those videos get views.

The same thing with apps.

AI can create any app you want. And yet, 99% of what’s being created gets thrown into the void. Nobody sees it. Has no impact.

There’s a law called Pareto’s Law.

[![](https://substackcdn.com/image/fetch/$s_!qSBI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F073c9883-0d9d-489c-bda7-edb6c148071c_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!qSBI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F073c9883-0d9d-489c-bda7-edb6c148071c_1920x1080.png)

_Credit: @hussainibarra_

It says that the top 20% of products capture 80% of the customers.

This law is seen everywhere.

In dating apps, videos, and wealth distribution.

**Volume isn’t the answer in today’s economy.**

Volume only comes after you have something that’s working. Before that, you need taste, the ability to know what is good and what is bad.

Taste is a skill that can only be developed through practice and intuition.

## IV - Perspective

You have Shakespeare, Dostoevsky, Alan Watts, and all of the greatest thinkers in your pocket.

Anyone can tell AI to write at the same level as them.

It’s not hard.

It’s also not hard to tell AI to give you a detailed analysis on a topic and publish as your own work.

But even with that, people still struggle to build something meaningful.

The reason?

They don’t have a unique viewpoint.

Your perspective, your unique point of view, the countless tiny lessons and experiences that have shaped who you are and your thoughts (whether you’re aware of them or not) are what people want to see.

[![](https://substackcdn.com/image/fetch/$s_!J8xt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1cb6665e-b704-4238-8ac2-8f565d0d96ab_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!J8xt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1cb6665e-b704-4238-8ac2-8f565d0d96ab_1920x1080.png)

_Credit: @hussainibarra_

People don’t want more information.

They want the nuance. The connected dots they never noticed. Your unique take on a topic.

Your perspective, the ability to see what others can’t, is what makes you stand out. It’s how you create novelty, and novelty captures attention.

Think of your favorite thinkers, creators, and philosophers, why do you follow them? Why do you listen to them? The answer is their perspective. They made you view the world in a different way. And that has impacted you more than if they just told you how to solve your problem.

Showing people a different way of thinking is just as important as giving them the solution.

## V - Judgement

When you can create anything and everything, knowing what to work on is infinitely more important.

Because now we don’t operate in the normal world.

The right decision does lead to 2x or 5x results. It’s 1,000x.

> _**“There are now 1,000x engineers.”- Naval Ravikant**_

An engineer who creates a loop that speeds up the operation by 0.01 seconds isn’t 0.01x better than other engineers.

He’s 1,000x better than them.

Because now the code is more efficient and when you have thousands or millions of users, that 0.01 second stacks up. So your judgment (and this comes from experience and spending time in that domain) is what will separate you from the others.

Your judgment to know when to cut your losses on a project or when to double down (even when you don’t see results) is more important than how great you are at your job.

Warren Buffett is a great example of a person who has great judgment. Even if he lost all of his money tomorrow, people will give him billions of dollars to invest just because they trust him and his decisions.

Hard work is now overrated.

Working on the right things, the right way, at the right time is underrated.

# The greatest skill of the 21st century

[![](https://substackcdn.com/image/fetch/$s_!ziJe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb08b9eee-25b8-47bf-a1e3-78457dc2c162_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!ziJe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb08b9eee-25b8-47bf-a1e3-78457dc2c162_1920x1080.png)

_Credit: @hussainibarra_

If agency, taste, perspective, judgment, and creativity are abstract skills that are only gained through self-development and experimentation, then writing is the vehicle to practice those skills.

AI can do anything and everything.

But it still lacks agency. Its ability to assign itself its own work.

It always needs a master to guide it. That means AI is only as good as its master. And the output that AI generates is dependent on how well you can articulate your ideas, translate your vision into words, and create clear instructions.

All that requires clear thinking.

So how do you become a better thinker?

Writing.

Writing is how you organize your thoughts, communicate with others, articulate your thoughts, persuade people, attract supporters to your work, create products that serve humanity.

AI can do the building. You spread the message.

Writing is a self-discovery, self-improvement, and learning vehicle.

When you write, you uncover all the societal programming that has been done to you. You’ll notice when you start writing that most of your thoughts aren’t your thoughts. The majority of what you thought was you was actually installed by society when you were a kid (by your parents, teachers, schools, adults, politicians, and the news).

The way to break free from people’s programming and beliefs?

Writing.

_“But Hussain, won’t AI replace writing?”_

No. It won’t.

There’s a theory called the Lindy Effect — a theory stating that the future life expectancy of non-perishable things (like ideas, technologies, or businesses) is proportional to their current age.

[![](https://substackcdn.com/image/fetch/$s_!Agp_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fac16a6d0-6d8b-4c7f-92e3-9364c09b8ce4_1280x708.jpeg)](https://substackcdn.com/image/fetch/$s_!Agp_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fac16a6d0-6d8b-4c7f-92e3-9364c09b8ce4_1280x708.jpeg)

_Found this on Google_

The oldest piece of writing is 5,500 years old.

So no, I don’t think writing is going away any time soon.

The way we write might change (after all, we went from drawing pictures inside of caves to writing on a keyboard and a screen).

But to say that it won’t exist anymore is to say that humans will stop communicating with each other (which is impossible since humans are a social species).

Writing is how we pass information to future generations.

The foundation of media (podcasts, films, videos, news, books, articles) is writing.

If you’re trying to build a business, go on social media and write to build an audience and attract supporters for your work.

If you’re trying to solve your problems, write about them first, understand them, and then look for solutions.

If you’re trying to understand yourself, have better mental health, improve your relationships, write.

For the love of god, write.

Write daily.

Write about your ideas. Write about your goals. Write about your dreams. Write about your interests. Write about what you’re building. Write about the lessons you’ve learned. Write to make discoveries. Write about the discoveries you made. Write without AI. Without templates. Without judgement. Without caring about what others will say. Without putting on a mask to please others. Without filtering yourself.

Because what else is there to do?

Don’t you want to be remembered in history?

Don’t you want to leave your mark on this world?

Don’t you want to become valuable in society?

Don’t you want to become the person that your family relies on?

Don’t you want to live a top 1% life?

Don’t you want to make waves in this world while you’re alive?

Then why don’t you start writing?

Writing is the one skill that I am willing to bet my life on that will change your life, open doors you never thought were possible.

It doesn’t matter if you want to start a business, improve your life, or simply understand your mind better. Marcus Aurelius, Da Vinci, Charles Darwin, Thomas Edison, Winston Churchill, and many more all kept a journal or wrote consistently.

Franz Kafka was poor in his lifetime.

But now, he’s remembered as one of the greatest writers of all time. The impact that he has on today’s world is because of his writing.

Humans have transcended the physical plane now. We don’t only reproduce biologically, but also mentally. You continue to live as long as people have your ideas, beliefs, and worldviews.

[![](https://substackcdn.com/image/fetch/$s_!NbEA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc25a4c41-5285-4a6d-8b68-18a3f5a1cfeb_1188x1188.png)](https://substackcdn.com/image/fetch/$s_!NbEA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc25a4c41-5285-4a6d-8b68-18a3f5a1cfeb_1188x1188.png)

**WRITE MORE.**

The more you write, the more high-value you become.

The more high-value you become, the easier it is for you to thrive in the next 10 years.

Learn to hunt, solve, build, sell, and earn, so you don’t have to rely on anyone to survive.

You can create your own work, make your money, and live life on your own terms.

> _**“Play stupid games, win stupid prizes.”- Naval Ravikant**_

F*ck hustle culture.

F*ck climbing the corporate ladder.

F*ck trying to win at games you never signed up for.

Create your own game. Start your own business. Share ideas you’re interested in. Build products you care about. Travel the world. Create work you love. Help others unconditionally. Pass down the lessons you’ve learned to others and future generations.

This is how you become future-proof.

That’s all for today.

Thank you for reading.

Enjoy the rest of your day.

— Hussain

**P.S.**

Speaking of writing.

My good friend Dan Koe is running a 30-day bootcamp to help you build your own writing and content creation system.

You’ll learn the skills to help you become AI-proof and the person who can thrive in the next decade.

You’ll discover Dan Koe’s exact writing process that helped him gain 5M+ followers, 300k+ email subscribers, and scale to $4.2M/year as a one-person business using nothing but writing.

When you join, you’ll also get 1 year of access to his writing software (it’s what I use for my writing as well).

The bootcamp starts on July 8th.

[You can join here.](https://eden.so/bootcamp?via=hussain93)

**P.P.S**.

I’ll be joining the bootcamp myself.

See you there!


---

<!-- Archivo original: posts/2026-06-30-my-story-who-the-fck-is-hussain-ibarra.md -->

---
titulo: "My story: Who the f*ck is Hussain Ibarra?"
subtitulo: "How I went from a broke college student to making $100,000 with my one-person business"
fecha: 2026-06-30T10:18:39.792Z
url: https://hussainibarra.substack.com/p/my-story-who-the-fck-is-hussain-ibarra
audiencia: gratis
palabras: 3003
likes: 73
comentarios: 15
---

# My story: Who the f*ck is Hussain Ibarra?

_How I went from a broke college student to making $100,000 with my one-person business_

_I’ve gained a lot of new readers over the past few weeks._

_Most don’t know who I am or what my story is._

_So I decided to reintroduce myself and show you my story on how I went from a broke college student to building a successful one-person business._

_Grab a coffee, this is going to be a banger read._

==================

I was a very introverted and socially awkward child growing up.

Didn’t really have a lot of friends. Didn’t go out much.

So I spent the majority of my time playing with my older brother (when I say playing, I mean fighting).

And I’d spend a lot of my time with my parents.

Whenever they went out to do chores, they’d always take me with them. A lot of the time, we’d pass by families that weren’t doing well financially.

Now, I wasn’t born rich. I come from a middle-class family. But I grew up doing well financially.

Seeing those families struggle did something to me.

It made me want to build a successful company so I can either take care of these families or at least employ them so they can earn decent money.

So I followed the advice of those who were older than me. I followed the traditional path, because that’s “what I’m supposed to do”.

Studied hard. Got good grades in school. Got accepted to the best university in Dubai. Enrolled into an engineering program (because I heard engineers get paid well and this will help with my mission).

Up until this point, everything I did was based on what others had told me to do.

# The bane of my existence

[![](https://substackcdn.com/image/fetch/$s_!ZCMF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6853a93-e328-4a87-ad79-ffa7d2ab8410_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!ZCMF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6853a93-e328-4a87-ad79-ffa7d2ab8410_1920x1080.png)

_Credit: @hussainibarra_

In the summer of 2022, I had to do an internship to graduate.

Got accepted into one of the biggest developers in Dubai. Worked on mega projects.

[![](https://substackcdn.com/image/fetch/$s_!zyyq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F43d68df4-081b-4279-9c61-fd7ca8f4a832_3024x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!zyyq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F43d68df4-081b-4279-9c61-fd7ca8f4a832_3024x3024.jpeg)

_The site I was working at…_

I thought it was the dream.

The people there were paid very well, but they were absolutely miserable.

They hated their lives, stressed, depressed, and they argued with their significant other daily.

When I saw this, I realized that what they’re going through would be me in the future if I continued to go down the path I was on.

After the internship, I went back to school and started looking at different career paths.

I love learning, exploring, and experimenting, so academia felt like it was the best option. Did a few research projects. It was amazing. But then I saw how professors were basically just a glorified version of a normal employee.

You don’t set your own schedule. Your livelihood depends on someone else. You can get fired tomorrow and lose everything.

And to be honest...

Most professors aren’t smart.

They are great at what they do, but they’re not smart when it comes to building wealth, managing people, and keeping up with technology.

So I looked elsewhere

# Failing, failing, failing, and more failing

[![](https://substackcdn.com/image/fetch/$s_!RpTM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1fbd5320-4dcb-4399-9bd1-e7f81e403e50_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!RpTM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1fbd5320-4dcb-4399-9bd1-e7f81e403e50_1080x1080.png)

In my last year of college, I tried different business models.

**1) Social Media Marketing Agency**

I was a broke college student with no real skills and everyone in the online space said that SMMA is the best way to start.

Found a free course about it on YouTube, started taking it.

8 weeks in, I quit.

I’m a very introverted person and doing cold emails and cold calls is just not for me.

**2) Blogging**

After SMMAs, I looked into affiliate marketing and blogging.

It seemed amazing.

I don’t need a product. I don’t need to do cold calls. I don’t need to spend all my time doing cold outreach. I didn’t need to do any product fulfillment.

I could simply write, plug a few products, and make $100,000/month.

_(At least that’s what the videos I watched told me)._

So I wrote a few blog posts, mostly with AI (which I regret doing). But writing with AI wasn’t the problem. The problem was that no one was reading my blogs.

I needed traffic...

**3) SEO**

The goal with SEO was to do 2 things:

1. Help drive more traffic to my blog
2. Maybe offer my services to others who have had the same problem

It was too complicated.

Even after weeks of trying to learn it, I didn’t really understand it.

Not to mention, almost all of the tools were $80-$100/month (which for me, was money that I didn’t really have).

So again...

I quit SEO and blogging.

**4) One-Person Business**

The reason I failed at all of my attempts so far was because the business models didn’t fit me or my personality.

I don’t like doing outreach. I don’t like “working” for others. I didn’t like writing about things I don’t really care about.

At the start of 2023, I discovered a guy with a mullet on YouTube. He talked about the Creator Economy.

The guy was making $100,000/month writing on Twitter. He worked 4 hours a day, didn’t have to do any client fulfillment, and built a business around his interests.

What drew me in the most was the fact that he used himself as the Customer Avatar. He wrote for himself, created products for himself, and sold to himself.

That man was Dan Koe.

I binge-watched his content for 2 weeks straight.

It took me 6 months from first discovering him to mustering up the balls to write my first tweet.

With the one-person business model, I didn’t need to do cold outreach, sell services I didn’t care about, and create content I had no idea about.

I could simply talk about what I find interesting, solve my problems, and help those who are one or two steps behind me.

# Creating a double life

With the one-person business model, I thought I was going to be a millionaire overnight.

Little did I know how hard it would be.

When I started creating on Twitter, I had just graduated from university.

During the summer of 2023, my goal was to make Twitter work.

_Spoiler: It didn’t work._

To create a cover story for myself, I went back to university. Enrolled in a master’s program in environmental engineering.

I still liked academia and thought maybe I could do both (run my one-person business and do academia at the same time).

But as time passed, I started hating academia.

To this day, my family, friends, and those who know me irl don’t know that I have my one-person business.

_(They think I’m just doing my master’s degree lol)_

[![](https://substackcdn.com/image/fetch/$s_!9xKb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F97d09957-e486-4557-8cdf-d6090e2241e8_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!9xKb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F97d09957-e486-4557-8cdf-d6090e2241e8_1080x1080.png)

Keeping my one-person business a secret was the best thing I did.

Because that would’ve just added more unnecessary pressure. The people around me would’ve criticized me, made fun of me, or even tried to convince me to quit before I gave it a real shot.

The funny thing is that most people in this world never had the balls to start something of their own. So they do their best to drag you down (because deep down, they hate themselves for never taking a risk and building something meaningful).

So why bother telling them?

If you want to build something that most people have never tried to build, be very careful who you share your ideas, plans, and dreams with.

Share what you’ve done once you’ve built it.

You’ll shut everyone up. And they’ll ask you how you did it.

# Living in a never-ending nightmare

At the start of 2024, I was still broke.

I needed money.

And after getting peer pressured by the people around me, I went back to the same developer I interned for.

I was paid well. Great office view. Working on mega projects.

[![](https://substackcdn.com/image/fetch/$s_!UlcI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35bd27b5-fca0-42db-b61a-ba99e72bd6ec_3024x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!UlcI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35bd27b5-fca0-42db-b61a-ba99e72bd6ec_3024x3024.jpeg)

_The view from my office_

On the outside, I was successful. Working at a prestigious company and getting my master’s (with plans on getting my PhD).

But this was the worst period of my life.

I felt like a zombie, depressed, and simply, I couldn’t imagine myself living for much longer.

I was up at 5 AM, write for 30 minutes. Get dressed. Arrive at the office at 8. Leave at 3. University lectures from 5 till 8. Hit the gym, run, and I’m back home at 11.

When I’m back home, I’d try to write for 30 minutes. But my brain is fried. I can’t think, can’t write, can’t even plan.

This just made me even more motivated to make my one-person business work.

I couldn’t imagine living the rest of my life like this.

Even though I only made a few hundred dollars with my one-person business after 12 months, and there were no signs of success (or any sign I’d be successful in the future), I knew in my bones that my one-person business was going to succeed.

So quitting my job and doubling down on my business was the only way I could escape this never-ending nightmare.

I rolled the dice, and on May 6th, I sent my resignation email.

[![](https://substackcdn.com/image/fetch/$s_!Ju4h!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc678d6e2-4191-4347-ad52-5e50f13085a3_480x581.png)](https://substackcdn.com/image/fetch/$s_!Ju4h!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc678d6e2-4191-4347-ad52-5e50f13085a3_480x581.png)

_My face after I sent the resignation email!_

I still kept my cover story of being a “master’s student” for the people around me.

But in the background, I went even harder with trying to build my audience.

# Nothing happens, then everything happens at once

[![](https://substackcdn.com/image/fetch/$s_!rwUw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F450f5400-543d-4a3a-b999-534db0fad326_736x736.jpeg)](https://substackcdn.com/image/fetch/$s_!rwUw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F450f5400-543d-4a3a-b999-534db0fad326_736x736.jpeg)

In September of 2024, I had to be honest with myself.

16 months had passed and still, there were no signs of progress.

I had 800 followers, 70 email subscribers, and made a few thousand dollars during that entire time. Meanwhile, most of the people who started with me scaled to $8k, $12k, and $15k/month and have thousands of followers.

“_Maybe I’m not cut out for this,”_ I told myself.

I made a deal with myself:

If I couldn’t get to 1,000 followers by October, then I’d quit, accept the reality that I wasn’t meant to be someone successful. I’d be average for the rest of my life (which is the scariest thought I had).

I spent the entire month of September obsessing over viral threads like my life depended on it (because it did).

On September 29th, I published my first thread. Spent 2 weeks writing it and when I hit post, I was gutted...

[![](https://substackcdn.com/image/fetch/$s_!ZS-A!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7d856f5b-8448-4053-84b8-b7e66d29d345_730x681.png)](https://substackcdn.com/image/fetch/$s_!ZS-A!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7d856f5b-8448-4053-84b8-b7e66d29d345_730x681.png)

_Text I sent to my group chat after my first thread_

I was convinced that I wasn’t cut out for it.

But for some reason I gave myself a chance to write one more thread.

This thread, it was about an experiment I did on myself. I went caffeine-free for 3 months, and shared what made me want to do the experiment.

And it went viral.

Went from 880 followers → 2,700 overnight.

That was a signal to keep doubling down on threads and topics I loved.

### 1) Gained 17,000 **followers in 50 days**

After my caffeine thread, I wrote a few more threads on health (because health is a big part of my life).

I wrote about sleep, stress, and self-improvement. They kept going viral.

At this point, I was at 6-8,000 followers

Then I wrote my most viral thread about ADHD.

In 72 hours, I gained 27M views and went from 8,000 → 17,000 followers.

People from other programs started talking about me and this caught the attention of big creators:

[![](https://substackcdn.com/image/fetch/$s_!z_ek!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9012c970-875a-4aed-b2b8-9fe75540a0e8_482x1043.jpeg)](https://substackcdn.com/image/fetch/$s_!z_ek!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9012c970-875a-4aed-b2b8-9fe75540a0e8_482x1043.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!8t3B!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb0d52239-150a-44fa-b009-9e6d73b48320_482x1043.jpeg)](https://substackcdn.com/image/fetch/$s_!8t3B!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb0d52239-150a-44fa-b009-9e6d73b48320_482x1043.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!tLk9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff10c1fb7-0aa3-4c10-85fc-0e3360a6c069_591x1280.jpeg)](https://substackcdn.com/image/fetch/$s_!tLk9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff10c1fb7-0aa3-4c10-85fc-0e3360a6c069_591x1280.jpeg)

__I had an insane fanboy moment right here.__

### **2) Started ghostwriting**

After learning the skill of going viral and having proof that I can do it (I was my own case study), people started asking me to write for them.

I needed the money, so I agreed.

One of my friends also asked me to join his team.

He was running a cohort and wanted ghostwriters to write for his students. His students were a big chunk of where my ghostwriting clients came from.

I was charging clients $250 per post.

This helped me reach $4,000/month just through ghostwriting.

That’s also when I realized that marketing and sales are key skills for me to learn. Not just solving problems.

Because if you want to make your own living (and not rely on someone else your entire life), then you need to create your own customers.

Truth is, I didn’t enjoy ghostwriting.

So I did something I never thought I’d do...

### **3) Burned my ghostwriting business to the ground**

I became a writer because I wanted to share ideas I cared about and have freedom.

But I was stuck writing about other people’s ideas, building their brands, and making them money, while my brand stopped growing.

In January of 2025, I fired all of my clients.

Went from making $4,000/month → $0 overnight.

Made a big pivot into coaching/digital products. So I asked Kieran Drew (a writer who has built the sort of business I want) for help.

Joined his cohort for $3,000 (I only had $3,300 in my PayPal).

It was scary giving him all my money. But the pain of being a ghostwriter was bigger than the pain of failing so I took the leap of faith.

3 weeks later, I created a product idea, built out the curriculum, launched it, and made $3,745 with my first-ever cohort launch.

[![](https://substackcdn.com/image/fetch/$s_!1cGi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F23738d36-a2b8-484c-9834-a328b9e73c36_1659x589.png)](https://substackcdn.com/image/fetch/$s_!1cGi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F23738d36-a2b8-484c-9834-a328b9e73c36_1659x589.png)

### 4) Created a group coaching program

The most enjoyable part of the cohort was the Q&A calls.

I loved helping people gain clarity, so in July of 2025, I launched a group coaching program, Profitable Micro Entrepreneur

At this point, I was making $4,000-$5,000/month consistently.

### 5) Launched The One-Person Business Sprint

[![](https://substackcdn.com/image/fetch/$s_!uJc9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F102cd5ea-4400-48e7-bc89-eb5522bbfe0c_1919x811.png)](https://substackcdn.com/image/fetch/$s_!uJc9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F102cd5ea-4400-48e7-bc89-eb5522bbfe0c_1919x811.png)

_I was showing the students my Origin Story_

At the start of 2026, I launched my 3rd cohort, The One-Person Business Sprint.

It was everything I had learned the past 2 years of building online.

I was no longer the guy who barely had any results. At this point I helped 30+ brands build their audience and monetize.

For this launch, I did a 5-week build-up.

By the end of the 5 weeks, I made $7,000 from it.

_(My biggest launch at the time)_

### 6) Launched Passion & Profit

Cohorts are amazing.

But I can’t do one every month (they’re exhausting).

So I built [Passion & Profit](https://hussainibarra.thrivecart.com/passion-profit-1/).

It’s my private community where people who are early in their creator journey can still learn. I’ve stuffed all of my products, systems, and workflows inside it so others can also benefit from it.

This is when I realized that running a community is much harder than it looks.

It’s not as “passive” as people make it seem to be. The revenue you make from it isn’t much at the beginning.

But it grows with time.

Passion & Profit is a long-term asset that I’m willing to commit to.

### 7) Crossed 10,000 email subscribers

[![](https://substackcdn.com/image/fetch/$s_!rU5x!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbd37cf34-0d07-4c52-9f46-c8a4b3b8eda7_1098x642.png)](https://substackcdn.com/image/fetch/$s_!rU5x!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbd37cf34-0d07-4c52-9f46-c8a4b3b8eda7_1098x642.png)

_Credit: @hussainibarra_

At the start of 2026, I set two crazy goals:

1. Reach 100,000 followers
2. Scale my email list to 20,000 subscribers

I felt dumb when I first wrote them down. Because I was only at 22,000 followers and 2,600 email subscribers. I literally had to 5-10x my stats.

But here’s the thing:

When you set a big goal, you’re forced to think of building leverage and being brutally honest with how you’re operating.

What got me to 2,500 readers in 2 years won’t get me to 20,000 email subscribers in the next 12 months. So I had to double down on creating deeper and higher-quality content.

And as I’m writing this on June 30th, I am at 10,547 email subscribers (already more than halfway there!).

### 8) Crossed $100,000 in the last 16 months

With my audience growing, and having a suite of digital products (cohorts, group coaching, and private community), I now have 3 streams of income. This helped me cross $100,000 with my business.

I’m also now making $8-$9k/month with my revenue climbing each month.

_(Very thankful for the position I’m in now)._

# The one lesson I want you to take away from my story

[![](https://substackcdn.com/image/fetch/$s_!o9Oi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F593cfc48-46dc-49d0-bad3-b35aa1983c7d_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!o9Oi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F593cfc48-46dc-49d0-bad3-b35aa1983c7d_1920x1080.png)

_Credit: @hussainibarra_

Problems are the cornerstone of living a good, meaningful, and purposeful life.

They are goals for you to chase. They give structure to your life.

The more problems you solve, the more skills you acquire, the more qualified you are to help others.

Running away from problems is how you become anxious, depressed, and lost in life. Because you don’t have a goal to chase.

My entire business was built by me obsessively solving my problems.

Once I solved them, they became my products. The version of me who struggled with the problem became my customer avatar. The reasons why I was trying to solve the problem became my marketing plan.

It will be hard at first.

But that goes for anything in life.

To build something meaningful in your life, you’ll need to burn your old identity.

Then do it again.

And again.

Over and over. Until you are where you want to be.

That’s what you need to do to evolve.

[![](https://substackcdn.com/image/fetch/$s_!VpPP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2e6802cd-aa5d-4ad7-9410-79de8eea7cd9_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!VpPP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2e6802cd-aa5d-4ad7-9410-79de8eea7cd9_1920x1080.png)

_Credit: @hussainibarra_

Just like a phoenix.

When it grows old and has its beautiful feathers and colors, it has to burn itself to continue to live.

You must do the same with your life.

You are comfortable with the life you have now. You have the friends, the job, the money.

But you’re stagnating.

In life, you’re either growing or you’re dying. There’s no in between.

If you ever find yourself in a period of no growth, you must throw yourself into the unknown.

You must climb out of the rut of comfort. Burn your old identity to allow for a new identity to be born.

That’s all for today.

Thank you for reading.

-Hussain

**P.S.**

If you’re new here, welcome.

Glad you made it to the bottom.

You’re probably into one-person business and want to start one and you’re thinking: _“Okay, so where do I actually start?”_

The answer is simple: [Passion & Profit](https://hussainibarra.thrivecart.com/passion-profit-1/)

It’s the private community I built for people sitting exactly where I was 3 years ago. A complete beginner. No skills. No audience. No idea where to begin.

Everything I used to go from 800 followers to crossing six figures, the products, the systems, the workflows, is stuffed inside.

You don’t have to figure it out alone like I did.

That’s the whole point of it.

[Join Passion & Profit here:](https://hussainibarra.thrivecart.com/passion-profit-1/)


---

<!-- Archivo original: posts/2026-07-16-happiness-is-a-skill-heres-how-you.md -->

---
titulo: "Happiness is a skill (here's how you can master it):"
subtitulo: "How to live in human optimal experience in 5 steps:"
fecha: 2026-07-16T07:45:58.424Z
url: https://hussainibarra.substack.com/p/happiness-is-a-skill-heres-how-you
audiencia: gratis
palabras: 4005
likes: 151
comentarios: 20
---

# Happiness is a skill (here's how you can master it):

_How to live in human optimal experience in 5 steps:_

I tried to commit suicide when I was 8.

For some reason teachers liked to bully me and I didn’t have any friends when I was in kindergarten till 2nd grade.

And that put me in a dark place. To be honest, I don’t really remember much of my childhood.

I think for me, life began when I was 13.

Thankfully, I am no longer suicidal.

But I still struggle with depressive cycles. They last around 3-16 weeks. I feel empty, no joy, no motivation, constant brain fog and negative thoughts.

I still get my work done. But I don’t experience any joy. It’s as if I’m some sort of robot who’s just existing.

I got so tired of living in this cycle, so I decided to do something about it.

I spent the last 2 months researching, reading, and learning about the science behind happiness. Explored spirituality, religion, faith, and scientific research about it.

My main goal today is to provide you and me with a guide that will help us improve the quality of our lives and how we can experience enjoyment even with the things we don’t think of as “fun”.

My second goal is to help you understand where misery, pain, and suffering come from, how you can overcome them, and why no matter how much people chase pleasure, their lives don’t improve.

Because if your goal was to do activities that gave you the most pleasure (a quick hit of dopamine), then the entire world would be a heroin addict.

Lastly, I want to show you a 5-step process to help you maximize happiness, find meaning, purpose, and fulfillment (and exercises to help you with each one).

I will be referencing Mihaly Csikszentmihalyi and his book Flow quite a bit in this letter.

Let’s begin:

# I - Understanding what happiness is

Happiness is not an object.

If it were, you’d get the same happiness every time you engaged with it.

A pen weighs the same every time you pick it up.

But you can binge-watch your favorite TV show and feel nothing. You can finally get the date, the promotion, the money, and still feel empty inside.

This is hedonic adaptation.

Your mind’s ability to drop to its baseline after a positive or negative experience in life.

Which means, if you keep outsourcing your happiness by chasing external results, then you’ll spend a lifetime living a life you never signed up for.

Happiness is an internal job.

It happens in the mind.

And because it happens in the mind, we need to understand consciousness and how our brain works.

# II - The anatomy of consciousness (what it is & how it works)

> “How we feel about ourselves... ultimately depend directly on how the mind filters and interprets everyday experiences.”- Flow

Let me ask you a question: Do you know what consciousness is?

It’s a difficult question to answer.

Depending on who you ask, you’ll get a different answer.

A neuroscientist will say consciousness is the firing of multiple synapses and brainwave activity.

A philosopher will say it’s your subjective experience of reality.

In Buddhism, consciousness is just is. It’s not a byproduct of anything.

But to me, the best definition I came across is from the psychologists.

Psychologists believe that consciousness is awareness.

Being aware of your thoughts, your behavior, attention, your surroundings, everything that goes on in your life, being aware that you are aware, and actively directing attention to what you desire.

That is what consciousness is.

The goal of consciousness is to take in information from the external and internal world (your surroundings and what goes on inside of you from feelings, emotions, goals, thoughts, and ideas), evaluate the information, and prioritize tasks accordingly.

Without consciousness, we can still “know” what’s going on around us, but we’ll always be in a reactive state. But because we are aware and we have consciousness, we can create information that didn’t exist before.

We can dream, be creative, and imagine a life in our minds that doesn’t exist yet and bring it into reality.

This is how we came to understand how the universe works, create art, write books, and develop technology.

That is all the work of consciousness.

Doesn’t this blow your mind?

The problem is that most people aren’t in control of it. It’s more like they’re sleepwalking. They sense, feel, and have thoughts, but they cannot direct their consciousness.

So how can you be in control of it?

### **Psychic Energy - Bringing order to your** consciousness

> “Control over consciousness cannot be institutionalized. As soon as it becomes part of a set of social rules and norms, it ceases to be effective in the way it was originally intended to be.”- Flow

Attention is potential psychic energy.

Without it, no work can be done. And it is dissipated through doing work. Your life is created by how you invest this energy.

Information enters consciousness because we focus our attention on it. When you’re driving, you pass hundreds of cars. But if I asked what cars you passed or saw, you wouldn’t remember any of them.

But you will remember the car that was serving, the one that cut you off, or was break-checking you for no reason.

The reason you remember is because you focused your attention on them, started processing the information of what’s happening, evaluated the situation, made a judgment, and executed all within a fraction of a second.

> “The mark of a person who is in control of consciousness is the ability to focus attention at will, to be oblivious to distraction, to concentrate for as long as it takes to achieve a goal, and not longer.”- Flow

The person who can do this is usually happier in their everyday life.

### **Psychic Entropy** - The reason why your life feels chaotic

> “Natural processes do not take human desires into account. They are deaf and blind to our needs, and thus they are random in contrast with the order we attempt to establish through our goals.”- Flow

Psychic = mental

Entropy = chaos, disorder, and randomness in a system

Everything in the universe has entropy.

From the birth and death of stars, how molecules move and interact with each other, the energy we get from the sun (and all the life we see here on earth before that energy is directed back to space).

These are all examples of entropy.

Entropy is always increasing.

Unless external energy is directed towards the system to maintain order.

Why does this matter?

Because the same thing applies to your state of consciousness.

Any piece of information that contradicts your identity or distracts you from your goal creates psychic entropy. Unless you catch yourself and direct your attention towards your goal again, you will descend into chaos.

_“But Hussain, I’m happy with where I am, I just want things to stay the same.”_

Don’t you get it?

There’s no such thing as “staying the same”.

The harder you try to keep things the same, the more energy you’ll need to invest to keep things the same.

Entropy is always increasing.

Everything is always in a state of change.

The more psychic energy you invest in trying to keep things the same, the less psychic energy you’ll have to get into new relationships, learn a new skill, get a promotion, read a book, or simply pick up a new hobby.

Imagine your mind is a room.

If you don’t clean it for a day, it’s not a big deal.

But a month, a year, or a decade without cleaning it?

Your parents will yell at you saying you live in a dumpster.

You need to constantly put effort, attention, and energy into cleaning your room.

It’s much easier to clean your room daily than to wait a whole year, thinking about all the work you will need to do to clean the room.

You’re only creating more entropy (through anxiety and overthinking) by avoiding doing the work.

It’s no wonder that we have a mental health crisis around the world. We have people who have spent their entire lifetime not cleaning their room.

And who wants to clean a room that dirty?

Entropy keeps increasing because there is a gap between knowing what we should do and actually doing it.

There’s a blockage in our system that’s stopping us from putting energy into the system.

### Pleasure, enjoyment & happiness

Most people think happiness is the same as ecstasy (getting high, drinking, partying, good food, sex, traveling).

As if you’re not always high on dopamine and on cloud 9, then something is wrong.

But ecstasy is pleasure. And pleasure isn’t happiness. Pleasure is just a quick dopamine hit. Once it fades, you’re back down to baseline.

> “Pleasure helps to maintain order, but by itself it cannot create new order in consciousness.”- Flow

Enjoyment comes from a sense of novelty and accomplishment.

Playing a close game of tennis. Finishing a hard level in a video game. Launching a business. Learning a new skill. Writing about a hard subject (like happiness). These are all experiences.

In the moment, these activities don’t feel pleasurable. If anything, they feel hard and frustrating. But once the event is finished, you look back and wish you could do it again because it helped you grow.

You can experience pleasure without psychic investment.

But you cannot experience enjoyment without investing psychic energy (focus, attention, time, and effort).

# III - Assigned routines are the source of your psychic entropy

> _**“A thoroughly socialized person is one who desires only the rewards that others around him have agreed he should long for (rewards often grafted onto genetically programmed desires). He may encounter thousands of potentially fulfilling experiences, but he fails to notice them because they are not the things he desires. What matters is not what he has now, but what he might obtain if he does as others want him to do. Caught in the treadmill of social controls, that person keeps reaching for a prize that always dissolves in his hands.”- Flow**_

Look at the masses.

It doesn’t take a genius to realize that most of them hate their lives.

They wake up and immediately start filling their consciousness with psychic entropy

- “I have to go to work”
- “I’m gonna get stuck in traffic”
- “I need to deal with my sh*tty boss”
- “And the tasks that I need to finish, they’re so long.”
- “I also have a deadline that I need to meet.”
- “Oh, right, after work I also need to go buy my dog his food.”

The list is endless!

You already ruined your day before it even started.

When in reality, you’re just lying in bed.

The reason your life feels out of order is because you refuse to invest your attention in what truly matters, the present

> Problems don’t exist in the now.

When you think of the future, you get excited, but that’s also where anxiety lives.

When you think of the past, you feel joy, but that’s also where pain and depression live.

Research shows happiness comes from being one-pointed. When all of your attention is being directed to one thing.

The yogis have spent decades mastering.

They spend hours every day meditating, being in a one-pointed state of consciousness.

It is in that state that you enter an even higher state of consciousness: **flow state**.

# IV - Flow (the psychology of happiness)

Have you ever experienced a human’s optimal experience?

The state of consciousness every athlete, yogi, and high-performer swears to be their key to success.

Athletes call this experience “The Zone”.

You’ve tasted it before.

You’re unconsciously chasing it every day.

- When you were playing basketball and every shot you took went in.
- When you were painting and every brush stroke was perfect.
- When you were writing and ideas kept coming to you
- When you were solving math problems without making a single mistake.

It’s in this state where you are completely focused and present at the task at hand. Peak productivity, performance, and happiness all exist in this state of consciousness.

You finish 6 months of work in 6 hours.

When you’re in flow, your consciousness is extremely well-ordered.

Every piece of information that comes into your consciousness only strengthens your identity. Your mind is ordered and more attention is freed to deal with the outer and inner environment.

**What happens to your brain when you’re in flow:**

- **The default mode network becomes less active**.
- **Your reward circuits are activated** - You gain the reward from the activity itself (not the outcome), helping you sustain that state of consciousness.
- **Your prefrontal cortex quiets down** - The inner critic’s voice disappears and your self-monitoring circuits shut down (you’re not judging yourself, you’re simply “doing”).
- **Your amygdala is less active** - Less negative emotions, thoughts, and experiences, and you experience more positive emotions.

The opposite of flow is boredom.

When you’re bored, your mind is distracted.

I sometimes catch myself watching Netflix, scrolling my phone, eating junk food, and simply doing everything and anything just to kill the boredom.

Nothing is working because I don’t have a goal to rewire my psychic energy towards, so my mind is creating psychic entropy.

Your mind craves order.

Goals help bring order to your consciousness. They give you a sense of control. The more goals you set out for yourself, the more in control you are in life.

When you’re pursuing something out of genuine curiosity, your mind starts rewiring itself. Experiences you once were oblivious about, you now see them everywhere. Because you’re now investing psychic energy towards a goal and your mind needs to register any piece of information that helps you achieve that goal.

# V - How to enter optimal human experience (5-step process)

It’s impossible for anyone to tell you how to get into flow state.

But I’ll show you exactly how you can get into it.

First, why is it impossible?

Because flow state is a state of consciousness, not action.

Humans are great at taking action. You can read a book, write an essay, listen to a podcast, or go for a walk.

But you can’t _do_ a state of mind.

A state of mind happens to you.

You can’t _make _yourself sleep. What you can do is go to bed which will help you fall asleep.

The harder you try to achieve a state of mind, the harder it is to be in it. The harder you try to sleep, the harder it is to fall asleep. The harder you try to think of nothing, the more thoughts come to your head.

Do you get it now?

You can’t bring a state of mind through action.

That’s impossible.

The only thing you can do is facilitate it. Lay the groundwork for flow state to happen.

This is what yogis, athletes, artists, and high-performers all do.

Here’s how you can achieve optimal human experience:

### 1) Set a meaningful goal

Self-generated goals impose order on your consciousness.

Goals that get assigned to you (through society) generate entropy.

A goal has a starting point, a desired outcome, a sequence of events, a known set of rules, and feedback.

- You need a starting point because if you don’t know where you are, then how will you know if you made any progress?
- You need a desired outcome. How will you achieve anything if you don’t know what you’re aiming for?
- You need a plan, a sequence of events or actions you need to complete to achieve your goal.
- Rules are important because they help you understand what it is you’re trying to do. A person who doesn’t understand the goal (or the rules of the “game”), will not see the goal as a challenge or an opportunity. It’s simply meaningless.
- A feedback system tells you how you’re progressing, if you’re heading in the right direction or not, and sends you a signal to course-correct to get back on track.

Solving a problem is a goal.

If you don’t know what problem to solve, start with the ones staring you in your face.

Solve your money problems, get in shape, go on dates.

Pick something. And start working towards it.

It doesn’t matter what you pick.

What matters is that you now have something to rewire your mind to. Something meaningful to invest your psychic energy in.

This newsletter is me solving my own problems.

- **I identified a problem** - feeling unhappy, unmotivated, distracted
- **Set a goal** - Understand what happiness is
- **Dove into the unknown** - Read scientific papers, books, and listened to lectures
- **Experimented with solutions** - Meditated, journalled, walked, ran.
- **Distilled my findings into organized thoughts** - Writing this newsletter to share my findings, experiences, and perspective on the topic.

### 2) Maintain the Challenge-To-Skill ratio

[![](https://substackcdn.com/image/fetch/$s_!z-hw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf0d543e-3b3c-4f46-9a40-60829f666042_1000x1000.png)](https://substackcdn.com/image/fetch/$s_!z-hw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf0d543e-3b3c-4f46-9a40-60829f666042_1000x1000.png)

_Credit: @thedankoe_

> _**“The best moments usually occur when a person’s body or mind is stretched to its limits in a voluntary effort to accomplish something difficult and worthwhile. Optimal experience is thus something that we make happen.”- Flow**_

Humans are terrible at focusing their minds.

So we use tasks (external forces that create stress) to help us focus our minds, become one-pointed and enter flow state.

But you need to strike a balance.

If the task is too easy, you become bored. If the task is too hard, you become anxious. In both states, your mind is distracted.

You need to be in the middle.

You need a challenge that is hard enough to keep you focused, but easy enough to not overwhelm you.

> _**“The goal is to stretch, not snap.”- Steven Kotler**_

This is why video games are so addictive. They mastered this concept.

I didn’t play Elden Ring. But my brother did. And he would spend 4 hours straight trying to beat one boss.

ONE.

In video games, you cannot go to the next level unless you master the current one.

Most of my friends aren’t as good as me when it comes to League of Legends (I was rank #9 in the server).

So whenever I got on a lower-ranked account to play with them, I’d just stomp the entire game.

_Get owned, noobs!_

Because the games were too easy, I started getting bored. So to make the games more fun, I’d restrict myself from using certain items or choose characters that I was bad at to make the game harder for myself.

**When the task at hand is too easy, make it more challenging.**

Add restrictions, deadlines, anything to make it harder.

**When the task at hand is too hard, metabolize the emotion.**

You’re not overwhelmed because of the task itself. You’re overwhelmed because of an emotion, fear of future consequences.

You need to metabolize that emotion and bring your attention back to reality.

How to do it?

- Journalling
- Speaking to a friend
- Going on a walk

But the easiest and simplest way to do it is to center your attention on your breathing.

Research shows that how you breathe and the emotions you have are connected.

When you breathe rapidly, you start feeling anxious (try it). When you breathe slowly, you’ll feel calm.

My favorite breathing exercise is when you breathe into your solar plexus.

[![](https://substackcdn.com/image/fetch/$s_!7lGR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F58769635-4a30-4d43-a63b-48e9e3c4a1fd_503x800.png)](https://substackcdn.com/image/fetch/$s_!7lGR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F58769635-4a30-4d43-a63b-48e9e3c4a1fd_503x800.png)

Here’s how you can do it:

- Close your eyes
- Pay attention to your body’s proprioception (your arms, head, nose, anything where you can feel yourself)
- Now focus on your solar plexus (the spot below your sternum, above your stomach)
- As you breathe in and out, you can feel your rib cage expand but if you pay attention to just the solar plexus itself, you’ll notice a **feeling of emptiness, an **_**absence**_** of feeling** there.
- Meditate on that absence. As you do, you get closer to shunya (the void, the part of you underneath all the ego labels, roles, thoughts, and emotions).

And this will sound crazy.

When I first tried this breathing exercise, I saw memories that were not mine. As if it was from a previous life or something.

I’m not into that woo-woo spirituality, but man, that experience was very trippy.

### 3) Disconnect from reality

When you’re in flow state, time moves differently.

5 hours pass and it feels like 5 minutes.

But it’s not just time that changes, your sense of self also changes.

You lose your sense of self, identity, and ego when you’re in flow.

You don’t care about what’s happening _to you_. You care about what you’re doing.

You become one with the thing you’re doing.

For a writer, it’s not their thoughts and a keyboard. The keyboard becomes an extension of the writer. The same happens with a golfer and her club. The club becomes an extension of who they are.

As long as the ego (your sense of self) is in the picture, you cannot attain flow state.

So what keeps your ego in the picture?

Comparisons.

You cannot compare yourself to someone else without attaching your ego to it. You can never compare yourself without saying “I”.

As long as you keep comparing yourself to others, you can never be happy. Because there’s always someone who’s better, more attractive, wealthier, taller, more productive, and has a more attractive partner than you.

> When the “I” exists, the ego exists with it.

### 4) Laser focus

This is the only thing you _can do._

You need to direct your focus and attention on something for an extended period of time.

You don’t randomly slip into flow state and then work.

To enter flow state, you need to have a meaningful goal to chase, start the task at hand, a healthy dose of stress to focus your mind, then your ability to stay in that discomfort without any distractions.

The longer you can stay focused, the bigger the probability you will enter flow state.

### 5) Remove lingering thoughts (the final boss)

Even if you do everything above, there’s one thing that will keep you from achieving flow state.

That’s a lingering thought.

Not a random thought, but a persistent one. Something you know you should be doing but avoid.

There are two ways to remove a lingering thought:

The first is disappearing and living on top of a mountain in isolation and meditating for 20 years and achieving a level of detachment unknown to mankind.

Or...

And this will sound obvious...

JUST GO AND DO THE THING.

You won’t become happier from doing it. But it will help you become one-pointed which will help make entering flow state possible.

# VI - How to consistently have good days

You can consistently have good days.

Sounds weird.

But it’s true.

If you can eat clean, hit the gym, go for a run, you got a good day.

Then you can do it again tomorrow, then the day after that, and before you know it, you have some momentum going.

You see, here’s the thing about momentum: It goes both ways.

It can either propel you forward (by stacking good days), or you can keep digging yourself into a bigger hole (by stacking bad days), creating more entropy, which only make starting harder.

You don’t need to feel like doing it.

Like I said, pleasure isn’t the same as happiness. Pleasure is fleeting. It comes and goes.

Happiness comes from investing your psychic energy into meaningful goals.

I don’t feel like working out every day. But I never regretted going to the gym or for a run. Just yesterday, I struggled to even drive to the gym because I was having a bad day. But I forced myself to go, and then I went for a 40-minute run.

The result?

I was in a much better mood.

> You’re not depressed, you just haven’t worked out.

You need to create a routine that no matter what will keep you on the right track. And when you create that routine, then it’s all about stacking good days and living in flow.

That’s all for today.

Thank you for reading.

Enjoy the rest of your day.

- Hussain


---

<!-- Archivo original: posts/2026-08-05-how-to-build-a-beautiful-mind.md -->

---
titulo: "How to build a beautiful mind"
subtitulo: "The process behind building a more intelligent and creative mind (and how you can do it step-by-step)."
fecha: 2026-08-05T09:18:11.989Z
url: https://hussainibarra.substack.com/p/how-to-build-a-beautiful-mind
audiencia: gratis
palabras: 3107
likes: 109
comentarios: 18
---

# How to build a beautiful mind

_The process behind building a more intelligent and creative mind (and how you can do it step-by-step)._

One of my favorite compliments I’ve been getting recently: “I like the way your mind works.”

For as long as I can remember, I’ve been obsessed with becoming smart.

I loved how philosophers spoke so eloquently.

The creativity of Michelangelo.

The perspective of Alan Watts.

The articulation of Jordan Peterson.

The analysis of Alain de Botton (from The School of Life) on a topic.

I still remember sneaking into my dad’s study room and reading books around logic, philosophy, and ethics.

Now granted, I didn’t understand 99% of what I was reading because the topics were too hard (or they overcomplicate things for no reason).

But the idea of becoming smarter and more intelligent has stuck with me ever since.

And in today’s era, it’s more important than ever to become a better thinker. Because we live in an age of infinite leverage. Any average person can have access to the smartest and most powerful AI models. That means knowing what to do, how to do it, and why you should do it is everything. If you work on the wrong things, then it’s an infinite difference between you and the person who made the right decision.

In this letter, I want to cover a few things:

1. How you can build your mind just like how a bodybuilder builds their physique.
2. Give you a few strategies and habits that you can start adding to your routine to become a better, more creative thinker.
3. Show you how you can learn about your interests and passions and use them as a vehicle for living a better life.

Let’s begin:

# I - Mental Bodybuilding

Mental bodybuilding is the act of chiseling your psyche to achieve your goals in all domains of life:

- Health, wealth, relationships, and happiness
- Professional, personal, and societal
- Mind, body, and spirit

To build muscle, you’re always manipulating 3 key elements to create an environment that is conducive to your goals:

Nutrition, training, and recovery.

When you’re trying to put on more muscle, you go on a bulk. You’ll eat more food, train hard, and get plenty of sleep.

Eventually, as you reach your goal (or you get fed up with how soft you look), your goal changes. You now go on a cut.

When you’re cutting, you reduce the amount of food you eat (or increase the training) to remove all the fat and reveal all the muscle and progress you made the past few months.

**The key lesson here:** you need a conscious goal to direct your focus for each chapter. A goal provides both meaning and a vision that imposes order on your life.

## I.i) Your mental nutrition

Most people, just like with normal nutrition, have a horrible diet.

They spend hours on their phones doomscrolling, watching porn, and playing video games.

What you consume affects how you think.

To think like a great person, you need to consume high-quality content.

A few methods that have helped me:

**1) Listen to podcasts**.

Podcasts are a double-edged sword.

Some are informative and give you high-quality ideas, while others are complete junk.

I’m not super big on podcasts. But two that I enjoy listening to are the Naval Podcast and Modern Wisdom.

I only listen to them when I’m on a run or going for a long drive, and I’m tired of listening to music.

**2) Read books.**

[![](https://substackcdn.com/image/fetch/$s_!UWkW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F81eb36ba-2fd6-41e0-abf7-a692b1d2751b_1080x1080.png)](https://substackcdn.com/image/fetch/$s_!UWkW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F81eb36ba-2fd6-41e0-abf7-a692b1d2751b_1080x1080.png)

Books have the highest-quality ideas.

An expert spends 20 years of their life creating knowledge and you can gain their knowledge in a 5-hour read.

The problem?

Most of them take way too long to say anything useful.

This is why I skim through the boring parts and only stop to read when something catches my eye. When it does, I save it and look for ways to incorporate it into my newsletters.

Most of my newsletters are inspired by books I am reading.

And no, you don’t need to read 50 books a year as everyone else tells you to.

You just need 5-10 great books you love. Keep rereading them. Every time you read a book again, you’re not the same person who finished it before. You have new goals, and your goals dictate what kind of information you pick up on.

**3) Curate your algorithm.**

I hate how people say social media is toxic.

It’s not.

Social media is just an algorithm that is built to give you what _you want._

If you think social media is toxic, then it’s just a reflection of who you are.

My feed is incredibly inspiring. Every time I open my phone, I see posts of people building amazing products, doing incredibly difficult races, and writing amazing newsletters.

To improve your feed, you must be intentional with what you consume. Unfollow creators that are polarizing and engagement-baiting. Block trolls. Be ruthless with clicking “not interested”.

Follow creators you enjoy and who inspire you. It will take 1-2 weeks until the algorithm adjusts to your new taste.

**4) Clean your circle of friends**.

Your friends influence you more than you can imagine.

Their ideas and habits leak into your life.

Are you surrounding yourself with people who give you great ideas? Or are they just there to numb your mind?

All of my friends are building businesses, agencies, creating art, running brands, and apps. And because we’re all operating in the ideas domain, we start cross-pollinating ideas.

## I.ii) Your mental training

We have a problem in our society that almost no one talks about:

**Mental obesity.**

Mental obesity is the act of consuming content without ever putting it towards a meaningful goal or creating something.

It’s the same with food, right?

If you only eat and never train, you get out of shape.

And when you’re obsessed with being productive (because that’s what everyone on social media is shoving down your throat), you start squeezing something productive into every free moment.

Listening to a podcast, learning about topics you aren’t interested in, and being obsessed with actionable content and never actually doing anything with it.

If you want a beautiful mind, an aesthetic mind, you need to train it.

The best way to do it?

Having a project to apply it to.

It can be anything.

Writing a newsletter, starting a business, learning a new skill, coding, web design, editing.

Now, before you start watching a YouTube tutorial or a guide on how to learn marketing, find a product you want to sell, and start marketing it. As you go and encounter problems, you want to research and learn. This way, you’re avoiding the mental masturbation that comes from only watching content, taking notes, and planning without ever starting.

**The thing to keep in mind:**

As you get better at the thing you’re doing, you want to increase the challenge. The way you build muscle in the gym is by progressive overload. Increasing the weights or reps you do every week (or every few weeks).

With the projects you start, you want to make sure you’re always working on projects that stretch you just beyond your current abilities.

This is how you become a better thinker, speaker, and builder.

## I.iii) Recovery

The highest-paid individuals are visionaries, strategists, and true creatives of the world.

Da Vinci was notorious for taking long breaks from the projects he worked on.

He’d work with great intensity for 2-3 days then disappear for 2 weeks.

He’d fill his time with walking, being present, and observing the little details that everyone would take for granted, and he would write down his notes and ideas whenever he got them.

This is why he was so creative.

At the highest echelons of whatever you’re trying to do, the skill that sets you apart from everyone is your creativity.

Not hard work or how good you are at a skill.

Why?

At the top, everyone is hardworking and is great at what they do.

But your way of doing things, working in your zone of genius (creativity), becomes your advantage.

So how do you become more creative?

**Boredom.**

You need to give yourself 1-3 hours a day to be bored.

Stare at a blank wall. Go for a walk without your phone. Go for a run. Meditate. Anything. It doesn’t matter.

When you’re not focused on a task, your mind goes from being narrow-minded (because of stress and chasing a goal) to a state of consciousness where you are open to receiving ideas (the Default Mode Network).

I get my best ideas when I’m out on a run.

I can _see_ what the piece looks like (even before writing it). I know exactly what needs to go where. I also see how different ideas (that seem unrelated) can all be tied together to create a unique, interesting, and valuable piece.

But the only way you can do this is to be comfortable with being bored and to allow your subconscious mind to surface and your creativity to kick in.

This means working less. Removing the noise: the repetitive tasks that drain your energy, tasks that require no creative challenge. Freeing up your time for playing, thinking, walking.

It’s in that time that you allow your mind to digest everything you’ve consumed and connect ideas together.

# II - How to build a beautiful mind (step-by-step)

To become a bodybuilder, you must lift weights.

To become a swimmer, you must swim.

To become a writer, you must write.

To build a business, you must create a product, learn marketing and sales, and find customers.

You can’t _be_ anything unless you actually _do_ first.

> Life is lived in the arena.

You must go there and do the work yourself. Find what works, what doesn’t, and iterate. That means doing more of what worked and less of what didn’t.

When it comes to building your mind, you must read about different topics, take notes, gain new experiences (by building projects), synthesize your knowledge, come up with novel perspectives, and share your experiences with others on social media (because that is the new town square where everyone is at).

Accept the fact that it will be hard in the beginning. Just like with everything else in life.

But as you keep doing it, it becomes easier, and eventually, you don’t need to think about it, you just do it.

## 1) Start a weekly project

Life is merely a constant stream of information.

Your quality of life is determined by how your mind interprets the information you receive. Your “self” is the collection of experiences, conversations, ideas, interactions, beliefs, and worldviews that were projected onto you by society.

In other words, your “self” is the unique combination of what you experienced in your life and how you interpreted that information.

Goals play a big part in that.

Goals frame your consciousness. They decide what information enters your mind and what doesn’t.

If you don’t know what goals you should chase, then solve a problem. Start with the ones that are staring you in the face.

If you’re out of shape, then get in shape.

If you’re struggling financially, learn how to make money (yes, making money is a skill).

If you’re tired of being single, go out and speak to people and go on more dates.

Whatever problem you choose to solve, share it in public.

This is why I love writing newsletters.

Every week, you choose a new problem to solve, write about what you learned, and help others do the same.

My newsletters are my attempts to solve my problems in public.

Writing literally rewires your brain. The more you write, the more you realize how little you actually knew and how so many of your opinions and beliefs are in reality other people’s beliefs, ideas, and perspectives that you were regurgitating without knowing it.

**The lesson here:**

Setting goals and solving problems is the cornerstone of a good, meaningful, happy life.

Without goals, you become aimless.

No clue of who you are, where you’re going and what you’re supposed to do. So you start feeling overwhelmed and depressed.

The only way to take back control is by setting a goal to rewire your mind to.

## 2) Dissect your mind for ideas

The most common question I get asked:

_“What should I write about?”_

Literally anything that interests you.

But I know how giving that freedom makes some people feel more paralyzed than ever.

So here are a few ways to find ideas:

**What are things you believe more people should adopt?**

Write about your beliefs and how they lead to a better life.

**What are 5-20 things you are genuinely curious about?**

Study your interests, experiment, take notes, come up with your own conclusions and theories and share them with the world.

**What are you good at?**

Write about the skills you have and the life you’ve been able to live because of them.

**What are topics you live to consume in your free time?**

I love consuming content about fitness, marketing, and spirituality.

I live, breathe, and eat those topics.

Create a topic tree of your interests (keep it to 3-5 broad topics), break each topic into subtopics. Keep doing it until you can’t break them down further.

Then use these ideas as starting points for your writing.

> You’ll also start making connections between different domains and this will help you come up with unique perspectives and ideas.

## 3) Know who you’re speaking to

Most people are complete beginners.

That means if you’re writing high-level content and super advanced topics, it will go right over their heads. You need to speak their language.

In the world of writing and content, that’s their awareness level.

**There are 5 awareness levels:**

- **Problem unaware -** they don’t know how something is affecting their life. Focus on pointing out the sources of their pain.
- **Problem aware -** they know they have a problem, but don’t know a solution exists. Focus on educational content.
- **Solution aware -** they know solutions exist but don’t know about yours. Focus on promoting your products.
- **Product aware -** knows about you, your solution, and product.
- **Most aware -** they are ready to act, they just need an incentive to take action now.

Most of my short-form content is between levels 1-2. Short-form content is shallow for a reason. That’s how it’s designed to be.

But newsletters are different. You have more room to go deeper with an idea. This allows you to take people from problem unaware to solution (or even product aware).

With long-form, you can create a persuasive argument. You can address why their current way of viewing the world is false, how it’s affecting them, introduce a new perspective, idea, or method of living, show its benefits, and give actionable advice.

That’s literally how I write all of my newsletters.

It’s always:

- **Start with a problem -** show how the problem is affecting people’s lives across different domains (health, wealth, and relationships).
- **Explain the mechanisms of the problem -** why the current way of doing things doesn’t work
- **Introduce a new perspective -** introducing a new idea or way of seeing the problem.
- **End with actionable steps -** create a step-by-step solution to help my readers solve the problem.

## 4) Study evergreen skills

[![](https://substackcdn.com/image/fetch/$s_!hJSl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4ce63c9c-8c1b-4fa9-8ac6-ac28d66b35f5_1188x1188.png)](https://substackcdn.com/image/fetch/$s_!hJSl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4ce63c9c-8c1b-4fa9-8ac6-ac28d66b35f5_1188x1188.png)

The goal isn’t to just build a beautiful mind. The goal is to make a positive impact on the world with your ideas, beliefs, and experience.

Otherwise, what’s the point of being so smart?

Marketing, sales, and persuasion are the skills you need to make an impact. These are the skills that make people care.

- Marketing is how you get your message heard.
- Sales is how you get people to adopt your message.
- Persuasion is the underlying foundation of everything you do.

Your ideas, beliefs, and opinions are internal.

They only impact you. But with marketing, sales, and persuasion, you turn them into external forces as well.

If you can’t get people to see you or care about you, you will end up being a starving artist.

What is a starving artist?

Someone who is great at their craft, but no one buys from them or even knows them.

Smart people get paid to be themselves.

My ultimate goal in life is to be paid purely for the quality of my thoughts.

Learning these skills does not make you unethical, immoral, or inauthentic.

_“But Hussain, I don’t want to be inauthentic.”_

Learning persuasion does not make you less authentic.

It helps you organize your ideas to make them more impactful. Once you get the hang of persuasion_, _you can drop the frameworks because your mind now understands how to make an idea impactful.

## 5) Iterate on your best ideas

For every 1,000 ideas, only a handful will be outliers.

You need to experiment with different ideas, and when you have a few that work, your goal is to double down on them.

This is how evolution works. This is how nature works. This is how natural selection works. Everything that is around you is a result of millions of years of evolution.

You have to be okay with failing. Without failure, success wouldn’t exist.

Every month, review your posts and save the best ones (the ones that performed best or that you liked most)

Then rewrite them from a place of more experience.

With each rewrite, your posts do better. Because 1) if something worked in the past, it’s an indication that it will work in the future and 2) your ideas are now more refined than before and you have developed a worldview that attracts people to your world.

Eventually, your mind starts _thinking_ in terms of your best ideas.

This is how your favorite podcasters, creators, writers, and speakers are always so articulate and magnetic with their ideas.

They’ve trained themselves to think with their big ideas.

Your first iteration of an idea is not the same as its last iteration. You must constantly write about your ideas, not because they change but because you change. With time, your beliefs change, you gain new experiences, and new perspectives. This changes how you view certain ideas.

Iterating on your best ideas in public is how you create a body of work that you are proud of.

That’s all for today.

Thank you for reading.

Enjoy the rest of your day.

—Hussain

**P.S.**

If you found this valuable, help spread the word by sharing/restacking this article (_the button is below)._


---

<!-- Archivo original: posts/2026-08-12-how-to-do-a-hard-reset-on-your-life.md -->

---
titulo: "How to do a hard reset on your life in 1 day"
subtitulo: "The art of reinventing yourself"
fecha: 2026-08-12T01:09:21.958Z
url: https://hussainibarra.substack.com/p/how-to-do-a-hard-reset-on-your-life
audiencia: gratis
palabras: 3439
likes: 78
comentarios: 10
---

# How to do a hard reset on your life in 1 day

_The art of reinventing yourself_

People are finally waking up to reality.

They are realizing that the life they were promised (go to school, get good grades, get a job, retire at 65) won’t bring them happiness.

Many people who are in their 50s, 60s, and some in their 70s emailing me saying how they are taking the first step to build something of their own (I have to say, it’s a very brave thing to do).

But I am also seeing just how so many young, ambitious people are also figuring this out.

So many people are becoming obsessed with hitting a “reset button” on their lives and starting fresh.

This letter isn’t a “How To” or an actionable guide.

Frankly, because I believe the first step to changing your life is changing your mindset.

If you go into it with your old mindset, ideas, and beliefs, it doesn’t matter if someone gives you the perfect plan, you wouldn’t commit because you’re not at the awareness level of someone who can actually do something with it.

But if you’re in the right mindset, you wouldn’t even need actionable advice, you’ll simply figure it out.

Without making the intro too long...

Here are 7 ideas to help you do a hard reset on your life:

[![](https://substackcdn.com/image/fetch/$s_!qnQ7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35b1fda2-4354-4a76-ad4b-fac0f2a2bd4a_2912x1632.png)](https://substackcdn.com/image/fetch/$s_!qnQ7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35b1fda2-4354-4a76-ad4b-fac0f2a2bd4a_2912x1632.png)

# I - Blame yourself for everything and preserve your agency

Everything is your fault.

It’s always your fault. Even when it’s not, it’s still your fault.

This is how you need to move in this world.

Your agency is the only thing you have. Once you start blaming others, you give up the only thing you had going on in your life.

The average person doesn’t take any responsibility. They’re like a child who blames everyone for everything. They live in a victim mindset where they think the world is out to get them. They always think they’re being oppressed.

You’re not a victim. The world is not conspiring against you. No one is out to “get you”.

You’re just a snowflake.

Just because you haven’t gotten what you wanted doesn’t mean people are evil.

The world doesn’t owe you anything. No one owes you anything. If you want something, go get it.

Agency is your ability to set a goal, devise an action plan, put in the work, fail, and persist until you achieve what you want.

Is life unfair?

Absolutely.

Fairness only exists in a perfect world, and we don’t live in one.”

But of think that you can’t be successful because the “rich control the world” or you’re of a certain race, gender, ethnicity, or background, then you’re completely wrong.

When you look at the highest echelons of life, you’ll see people from all over the world, from every race, every gender.

Even in your life, you have done things that led to good outcomes. And if you hadn’t done those things, you wouldn’t have what you have now.

So absolutely, you have agency.

The more time, effort, and iteration you put towards achieving a goal, the smaller role luck plays.

# II - The best things in life are best pursued indirectly

If you want to make money, you don’t immediately go for the money. If you do go for the money directly, it will be a miserable and hard road.

To make money, find something you’re genuinely curious about, set a goal, learn the necessary skills to achieve that goal, encounter problems along that journey, solve them, create a path for others to take and achieve the same goals as you had minus all the struggles you went through, iterate on it, and then you make money as a byproduct.

The pursuit of high status is a signal of low status. A high-status person does not care about their status. They got there by providing value to society and getting status as a byproduct.

If you want to get in shape, for the sake of getting in shape, every day will be hell. You won’t stick to your training plan or diet because you don’t enjoy it. You’re doing it for the outcome, and once you achieve that outcome, you’ll go back to where you were. The best way to do it is to adopt a lifestyle that helps you build muscle and lose fat.

If you want to write a book, write short essays based on lessons you wish someone taught you, publish them as newsletters, and use your newsletters as your outlines.

If you want to be happy, you don’t go for it directly. If you do, you’ll be chasing cheap pleasures that ruin your life in the long-term. To be happy, you do everything in your power to minimize distractions and maximize high flow activities (Flow State is the state of consciousness of optimal human experience).

The best things in life are gained as a byproduct of chasing your genuine curiosity and working in your zone of genius.

# III - You’re not where you want to be, because you’re not the person who’s supposed to be there

**Here’s a harsh truth:**

You’re not where you want to be because you’re not as good as you thought you were.

If you were, you’d already be there.

The gap between where you are now and where you want to be is skill, knowledge, and experience.

And until you gain the necessary information to _become the person who’s supposed to achieve the goals,_ you won’t.

To achieve your goals, you must live in the end. To see yourself at the finish line. You must first become the person who has the great physique, the successful business, the big house, mentally. Then you must think, act, and behave as that person.

> Your actions are always in alignment with your self-image.

Everyone has a self-image (whether you’re aware of it or not). Your self-image is what dictates the kind of life you will live.

That means if you see yourself as a failure, then no matter how hard you work, you will never become successful.

A student who believes he’s bad at math will always find ways to self-sabotage his own work.

To change your life, you must live in the end.

To live as if you have already achieved it. How does that version of yourself act, speak, think, and work? How did they become successful?

Reverse engineer the steps that took them from where you are now to where they are.

This works incredibly well if you’re a beginner or lacking direction. Because it gives you a clear path to go from where you are now to where you want to be.

Athletes do this extremely well.

You’ll see many athletes and coaches talk about visualization.

Before a race, an F1 driver can already see himself taking the corners, hitting the brakes, and overtaking the other drivers. He already sees himself on the podium.

An Olympic swimmer can visualize her every stroke, every breath, and every turn.

A basketball player runs hundreds of different simulations of every pass they make, every dribble, every shot.

All of these people can run hundreds of scenarios.

They can imagine every mistake they make, how to correct it, and what they need to do in order to win, all before even starting.

You only reach your goal once you become the person who can achieve it.

That means having the right skill set, knowledge, expertise, leverage, and mindset that will help you achieve it.

Most people know this, yet so many people still operate in the exact opposite way.

**Engrave this into your subconscious mind: **You must become the person capable of achieving your goals in your mind, start acting, thinking, and behaving as if you have already achieved it, then you actually achieve it.

It will feel cringe at first, but it will only be that way until life catches up to you.

# IV - The riskiest path is the safest path

Everyone is secretly anxious about AI replacing them at work.

But this just exposes a deeper issue we’ve accepted as a society: getting a job is “safe” and entrepreneurship is “risky”.

A job gives you predictability which you mistake for safety.

You know a set amount of money will come at the end of each month, you know when you’re getting promoted, and what the pay is like each time.

But you can lose it all tomorrow.

How is that any different than entrepreneurship?

When you create your own work, you’re not guaranteed how much money you’ll make tomorrow, but you know as long as you have yourself, you’ll always be ok.

You’ve learned the high-value skills: thinking, marketing, sales, and making money (knowing how to make money is a skill that you can learn).

Entrepreneurship teaches you how to be self-reliant and self-sustaining.

> Your life is determined by how much uncertainty you can handle.

Entrepreneurship looks risky because nothing is guaranteed.

But isn’t life the same?

You’re not guaranteed to live tomorrow. You can lose your job tomorrow just because you didn’t make sense on a spreadsheet (it happened to many people before you).

I’d even argue that entrepreneurship isn’t as risky as it once was.

You now have AI, no-code tools, and social media. You can attract an audience, build amazing products, and live a good life without having to spend all of your life savings.

You solved problems in your life, you have valuable knowledge to share with others, that’s all you need to start a business nowadays.

You don’t need a website, or a company logo, or ads, or anything else you think you need.

All you need is a social media account, an idea you believe in, and the courage to share it with the world.

Entrepreneurship teaches you that even when your life turns to shit, you’ll still find a way to figure it out and solve it.

# V - Labels & credentials are the source of your pain

> _“Empty your mind. Be formless, shapeless, like water. You put water into a cup, it becomes the cup. You put water into a bottle, it becomes the bottle. You put it into a teapot, it becomes the teapot. Now water can flow or it can crash. Be water, my friend”- Bruce Lee_

We live in an age of infinite leverage.

You can be anyone, build anything, do everything.

You are limitless, but the identity that you keep adopting is holding you back.

Don’t you see it?

Just because you’re a writer doesn’t mean you can’t use AI.

Just because you’re a doctor does not mean you get to be bad at math.

The more you try to hold onto an identity, the more pain you’re causing yourself.

You’re not just an accountant, or a father, or a husband, a son, an employee, a neighbor. You’re all of them and more at once.

Your identity is malleable.

You’re secretly addicted to failure and you don’t even know it.

You adopted an identity that once served you, but today, it is now the source of your misery. And the reason you refuse to let go is because it feels familiar (which your mind interprets as safe).

Let go of any labels or identities.

We live in an age where labels and credentials don’t mean shit. Being an “expert” means nothing nowadays. Being an “expert” impresses your boss, not the true wealth creators and value providers.

Not a single high-value individual I worked with asked what degree I have or how many years of experience I have.

I was an engineer with zero social media experience. But because I let go of all my preconceived beliefs, I managed to build a business around content creation.

I worked and became friends with some of the biggest creators in the space (many of whom inspired me to start).

# VI - Be strict with the vision, be loose with the details

Life is very predictable and rational.

From the biggest to the smallest objects in the world, everything can be explained rationally.

All galaxies, the stars, the planets, the bacteria, the trajectory of an asteroid, the formation of a sun, the rate of growth of trees, when the rain falls and where it falls, they all obey the same laws of physics.

It only seems random because we are so centered on ourselves.

It seems random because we’re not aware of the laws or simply because we wish life to be a certain way.

The cosmos does not care that you’re trying to go and play with your kid in the park today.

The same applies to your life and goals.

Having a vision and a goal you want to achieve is great. It gives you direction, order, and a purpose in life. But you can’t be overly strict with the details.

If you want to get in shape, be at a certain weight, or look a certain way, great. But don’t be overly obsessive over the kind of training plan or diet you’ll follow.

I started my fitness journey doing a Push, Pull, Legs split (6 days of training). But then I added running, then I did 3 days of weightlifting and 3 days of running.

Now, I am doing an upper/lower split with 5 runs a week.

If I’d been too strict with the details, I wouldn’t have been able to run and lift at the same time.

I made the mistake of being too strict with the details with my business.

My goal was to make money with my personal brand (god... that’s a cringe word to say).

In the beginning I said I’d only do it through digital products (templates and courses).

I made a whopping $1,000 in 16 months.

Then I changed my plan.

I ran a cohort, made $3,745 and I loved it. I thought cohorts were going to be my thing. But then I tried group coaching and loved it even more. Then I tried a community and I’m also loving it.

Now, my business is doing all 3: live cohorts, a paid community, and group coaching.

**My point is:** have a goal you want to achieve, but be loose with the details on how you get there or how you achieve it.

Humans are notorious for being overconfident in their skills.

You don’t know the future. You don’t know what will change. You don’t know what you don’t know. And being flexible with your approach is how you survive.

> Don’t quit. Pivot.

Suffering happens when your expectations of what reality should be and what reality is don’t fit perfectly together.

The more you try to force reality to be a certain way, the more suffering you’ll inflict on your life.

# VII - A message to my spiritual reader

Everyone knows that they’ll die eventually.

And religions tell you that your main goal on this earth is to believe in God and do good deeds.

But when you look around, you’ll notice that everyone is asleep.

They operate as if they’re immortal. As if there is no hell or heaven.

You find them bickering and fighting over the pettiest of things (money, fame, and status).

Wake up.

You need to be aware that life on earth is nothing but a short stop on the way to somewhere greater.

Your only job here is to do good, be good, and help others.

Distribute value to society.

If you have knowledge and experience, distill and share them with the world by writing a book or even better, creating content on the internet and spreading the word as much as possible.

### vii.i) Wha**t being awake means**

Being awake means seeing God in everything.

When you eat, you realize that there was a Creator behind it. The money you earn, you know that it came from a Creator. The people in your life who have helped you, you know that God has put them in your life for that specific reason.

Being awake means when you treat people, you treat them with respect, kindness, and compassion (even those who hurt you). Not because you’re weak, but because you treat people based on your morals, ethics, and behaviors, not theirs.

You also know that even when you mistreated God (by not following his teachings), God forgives you, gives you a second chance, and still welcomes you with open arms.

Being awake means knowing that every ounce of success you have, everything that you love about yourself and take pride in, came from Him, and it can be taken away at any moment.

Being awake means always remembering what truly matters: being a good servant of God.

Always thankful, always humble, always generous.

Most people only wake up and remember God when they go to church. They feel enlightened and more spiritually connected.

But once that’s over?

They fall back to sleep.

Back to the degeneracy. Back to bickering over petty things.

Wake up!

### vii.ii) How to achieve anything in this life

Nothing in this life is yours.

Nothing that you have in your life is because of what you did, how skilled you are, or how intelligent you are, everything that is good in your life came from God.

And religions gave us the playbook to achieving anything that we want.

It’s in 4 steps:

1. **Intention -** set the right intention. To go anywhere, you need to know where you’re going. Otherwise, where the hell are you aiming at?
2. **Strive -** create a plan and work towards achieving it. This is the only thing you _can_ do. In fact, this is the only thing you’re asked to do. Striving does not mean attempting once and quitting. It means exhausting all of your options before giving up. It means learning as much as you can, getting help whenever you need it, and trying 10x more than anyone else.
3. **Submit -** realize that everything in your life comes from God. Your outcomes have absolutely nothing to do with you.
4. **Accept -** humans are short-sighted. We think we know what is best for us but we actually don’t. If you didn’t get what you wanted, good. If you got what you wanted, also good.

Everything that happens in your life is for a good reason.

You don’t need to understand why things happened the way they did in the moment. You don’t even need to believe me now.

But in 5 or 10 years’ time you’ll look back and be grateful that things happened the way they did because you’ll realize that if you had gotten what you wanted, your life would be worse.

### vii.iii) Remember what truly matters

Most things in life don’t actually matter.

The only thing that matters is being a good servant of God. Doing good work. Being good. And leading by example.

Hookup culture, politics, gender wars, gambling are all distractions pulling you away from what truly matters.

Focus on meaning. Focus on making planet Earth a better place. Focus on helping humanity as a whole take a step forward in the right direction.

All of this starts with working on yourself.

Before fixing the world, fix yourself.

Before calling someone out on their bad habits, look at yourself.

Look at your flaws and fix them.

Fixing yourself and getting rid of all your vices, that is the hardest thing you will ever do.

It is much easier to start a business than to rid yourself of envy, jealousy, anger, and hatred.

### vii.iv) Everything comes to an end

Nothing in this life came from you.

It’s all from God.

What does this mean?

It means: set a goal, work hard towards it, and if you achieve it, be thankful.

If you didn’t, then take comfort that God is the best of all planners and you didn’t get what you wanted because he has something better in store for you.

Take comfort in knowing that the same one who created the universe, the sun, the stars, planets, trees, water, and everything you see, feel, touch, and smell, has also created you and is going to take care of you (just like he’s taking care of everything else).

That’s all for today.

Thank you for reading.

»Hussain

**P.S.**

This was a very different kind of newsletter.

These are ideas that I’ve been reminding myself of a lot recently. They have helped me push through dark and hard times.

If you got value from this letter, help spread the word by sharing it.

_(There’s a button below)_

If you’d like to keep reading…

Here are some of my favorite letters I wrote:

