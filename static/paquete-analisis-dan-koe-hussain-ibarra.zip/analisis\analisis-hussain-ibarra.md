# Hussain Ibarra: anatomía de una marca construida en público

## Resumen ejecutivo

Analicé los 34 artículos públicos de *Passion & Profit*, publicados por Hussain Ibarra entre junio de 2025 y agosto de 2026. El archivo contiene unas 100.600 palabras y conserva títulos, fechas, likes y comentarios.

La conclusión principal es esta:

> **Hussain no construyó su negocio empezando por una newsletter. Primero aprendió a generar atención en X, después trasladó parte de esa audiencia al correo y utilizó la relación creada por el email para lanzar productos y servicios.**

Su recorrido observable se parece a:

**habilidad → publicaciones en X → atención → newsletter → confianza → lanzamientos → servicios y productos**

La newsletter no es su principal motor de descubrimiento. Es el lugar donde profundiza la relación, demuestra competencia y vende.

El segundo hallazgo es que su posicionamiento se amplía con el tiempo. Al principio escribe principalmente sobre audiencia, escritura y monetización. Al final incorpora creatividad, filosofía, felicidad, educación, economía y desarrollo personal. No abandona el negocio: lo coloca dentro de una misión más amplia.

---

## 1. Qué contiene el archivo

- 34 newsletters con cuerpo completo.
- Periodo: 22 de junio de 2025 a 12 de agosto de 2026.
- Aproximadamente 100.604 palabras.
- Promedio por artículo: 2.959 palabras.
- Promedio visible: 198 likes y 16 comentarios.

Las métricas deben interpretarse con cautela. Una publicación —*Most high-income skills will be irrelevant in 10 years*— acumula 4.449 likes y eleva mucho el promedio. Además, los artículos más recientes han tenido menos tiempo para recibir interacciones.

Las cifras de seguidores, suscriptores e ingresos son datos autorreportados por Hussain. El archivo permite verificar que los publicó, no auditarlos ni demostrar causalidad.

---

## 2. La newsletter no fue el principio

Este es el dato que cambia la interpretación de su crecimiento en Substack.

Hussain afirma que empezó a publicar en Substack cuando ya tenía 19.000 seguidores en Twitter/X. Según su relato, consiguió 2.400 seguidores en Substack durante sus primeras 24 horas.

Por tanto, sería un error observar su crecimiento y concluir:

> “Publicó en Substack y Substack hizo crecer su audiencia”.

Su trayectoria fue más parecida a:

1. aprendió escritura y distribución en X;
2. construyó una audiencia allí;
3. utilizó esa audiencia como palanca para arrancar en Substack;
4. convirtió parte de la atención social en lectores de correo.

La lección no es “empieza una newsletter”. Es:

> **Construye atención donde exista distribución y traslada esa atención a un canal donde puedas desarrollar una relación.**

---

## 3. Cada canal cumple una función distinta

En julio de 2025, Hussain publicó que tenía más de 22.000 seguidores en redes y algo más de 2.000 lectores de email. Su lista era aproximadamente una décima parte de su audiencia social.

Sin embargo, afirmó que el 90 % de sus ingresos procedía del email.

En otro artículo explica que el 99 % de su crecimiento había procedido de los hilos.

Su sistema separa dos funciones:

- **Redes sociales:** descubrimiento, alcance y adquisición.
- **Email:** profundidad, confianza y conversión.

Esto aclara una aparente contradicción. La mayor audiencia no es necesariamente la más valiosa comercialmente. X amplifica ideas; el correo permite desarrollar argumentos, contar historias, presentar pruebas y lanzar ofertas.

El sistema completo es:

**hilos → seguidores → suscriptores → relación → oferta**

---

## 4. Monetizó mientras aprendía

Hussain no esperó a poseer una autoridad perfecta ni un producto definitivo.

En julio de 2025 contó que había realizado seis lanzamientos en tres meses: aproximadamente uno cada dos semanas. El objetivo no era solo generar ingresos; también quería mejorar escribiendo emails de venta.

Los lanzamientos sumaron, según sus cifras, 12.985 dólares e incluyeron:

- cohortes;
- coaching individual;
- coaching grupal;
- talleres;
- *ghostwriting*;
- productos de afiliación.

Lo importante no es únicamente el total. Es el comportamiento observable:

> **Utilizó los lanzamientos como experimentos de aprendizaje.**

No siguió una secuencia de producto perfecto → gran lanzamiento. Siguió una secuencia de:

**oferta → lanzamiento → respuesta del mercado → aprendizaje → nueva oferta**

Esta rapidez le permitió aprender ventas, precios, formatos y objeciones con clientes reales.

---

## 5. Servicios para financiar; productos para escalar

En los primeros artículos aparece una escalera comercial bastante clara:

1. servicios de alto precio;
2. coaching individual o grupal;
3. talleres y productos digitales más baratos.

En junio de 2025 considera “high-ticket” una relación de 2.000 dólares o más al mes por cliente. También explica que limitaría el *ghostwriting* a un único cliente de 2.000–3.000 dólares mensuales para reservar tiempo a productos propios.

Un mes después afirma que el 71 % de sus ingresos había procedido de coaching y ofertas de mayor precio.

Los productos baratos cumplían otra función:

- reducir el riesgo inicial del comprador;
- demostrar competencia;
- crear clientes;
- conducir a algunos compradores hacia servicios más caros.

Su modelo no era “vender un ebook barato a miles de personas”. Era:

**contenido gratuito → producto accesible como prueba → implementación de alto valor**

Los servicios aportaban caja y aprendizaje. Los productos permitían empaquetar el conocimiento y aumentar el alcance.

---

## 6. La evolución del negocio

La evolución que Hussain relata es aproximadamente:

- **2023:** primeros ingresos, unos 20 dólares.
- **2024:** aproximadamente 4.000 dólares con su marca.
- **2025:** más de 50.000 dólares, según él, con márgenes cercanos al 93 %.

A comienzos de 2025 cerró su agencia de *ghostwriting* para concentrarse en sus propios productos.

El movimiento es significativo:

**hacer el trabajo para otros → enseñar el trabajo → empaquetar el método → vender el resultado de forma más escalable**

No empezó con ingresos pasivos. Empezó adquiriendo habilidades, trabajando para clientes y observando problemas reales. Los productos llegaron después.

---

## 7. Su máquina de contenido es circular

Hussain describe un proceso parecido a:

**leer → tomar notas → escribir una newsletter → extraer publicaciones → crear un hilo → convertirlo en nuevas Notes o newsletters → repetir**

Esto es distinto de pensar cada día:

> “Necesito inventar una idea nueva”.

Una idea central produce varias piezas. Las reacciones obtenidas generan información para decidir qué desarrollar de nuevo.

El proceso funciona como un circuito:

1. el aprendizaje genera ideas;
2. la newsletter obliga a profundizar;
3. el ensayo produce piezas breves;
4. las piezas breves prueban interés;
5. las mejores respuestas alimentan contenido futuro;
6. el conjunto desarrolla propiedad intelectual.

La unidad de trabajo no es una publicación. Es una **idea reutilizable**.

---

## 8. Repite las ideas ganadoras

Una de sus recomendaciones tardías es no abandonar una idea cuando empieza a funcionar. Propone revisar resultados semanalmente, descartar lo débil y redoblar la apuesta por lo que obtiene respuesta.

El propio archivo muestra repetición alrededor de varios núcleos:

- construir audiencia;
- reinventar la vida;
- convertirse en una persona difícil de emplear o sustituir;
- desarrollar habilidades futuras;
- escapar del condicionamiento social;
- transformar problemas personales en productos;
- utilizar intereses múltiples como posicionamiento.

No publica una idea y pasa para siempre a la siguiente. La reformula mediante nuevos títulos, historias, estructuras y promesas.

Su proceso es:

**idea → publicación → respuesta → repetición → variación → nueva respuesta**

No:

**idea 1 → idea 2 → idea 3 → idea 4**

---

## 9. Su escritura parece espontánea; el proceso no lo es

En *What Goes Behind Writing ONE Good Post*, Hussain muestra parte de su proceso de construcción.

Antes de escribir, decide qué debe conseguir la pieza:

- alcance;
- utilidad;
- suscriptores;
- clientes;
- autoridad;
- demostración de competencia.

Después elige la gran idea, desarrolla un esqueleto, añade argumentos, reorganiza, corta y reescribe. También comenta que puede pasar días obsesionado con los detalles de algunos hilos virales.

La lección es importante:

> **La voz puede sonar casual sin que la creación sea casual.**

El resultado parece conversación. Debajo existe intención comercial, estructura y edición.

---

## 10. Cómo fabrica títulos

Sus títulos utilizan repetidamente:

- cifras específicas;
- resultados personales;
- periodos de tiempo;
- transformación extrema;
- amenaza futura;
- contraste;
- primera persona;
- curiosidad entre paréntesis.

Ejemplos:

- *My realistic plan to reaching $10,000/month*
- *7 Lessons I learned After Making $12,985…*
- *My Idea Generation System That Gained Me 72 Million Views*
- *6 Months is All It Takes To Completely Reinvent Your Life*
- *I gained 49 leads in 7 days. Here's how…*
- *I went from 800 to 26,000 followers in 13 months…*
- *Most high-income skills will be irrelevant in 10 years…*
- *You have 24–36 months to make it…*
- *How to do a hard reset on your life in 1 day*

Las fórmulas principales son:

### Resultado + mecanismo

**Conseguí X. Así lo hice.**

### Amenaza + sustitución

**Esto dejará de funcionar. Aprende estas alternativas.**

### Transformación + plazo

**Cambia esta parte de tu vida en X días o meses.**

### Confesión personal + lección

**Esto me ocurrió. Esto es lo que aprendí.**

El título promete una transformación concreta. El cuerpo la amplía hacia una visión del trabajo, la identidad o la sociedad.

---

## 11. Cómo amplió su posicionamiento

Al principio, *Passion & Profit* está muy cerca del negocio de escritura:

- audiencia;
- hilos;
- newsletter;
- monetización;
- lanzamientos;
- servicios y coaching.

Después aparecen temas más amplios:

- riqueza;
- reinvención personal;
- productividad;
- creatividad;
- filosofía;
- felicidad;
- educación;
- inteligencia;
- futuro del trabajo.

La expansión no es aleatoria. Hussain termina articulando su marca alrededor de una misión y de su propia transformación, no de un nicho rígido.

Su audiencia objetivo se parece a una versión anterior de sí mismo: joven, ambiciosa, con intereses múltiples, insatisfecha con la ruta convencional y atraída por la posibilidad de construir una vida independiente.

Eso le permite evolucionar sin romper la marca. Puede cambiar los temas porque sigue hablando a la misma persona sobre la misma transición:

**de espectador condicionado a creador autónomo**

---

## 12. Primeros artículos frente a últimos artículos

### Al principio

- Textos más cortos y comerciales.
- Resultados económicos en los títulos.
- Énfasis en tácticas concretas.
- Ofertas frecuentes y explícitas.
- Autoridad basada en resultados recientes.
- Identidad centrada en escritor, creador y pequeño empresario.

### Al final

- Ensayos más largos.
- Mayor peso de filosofía, identidad y cultura.
- Amenazas sociales o económicas como punto de entrada.
- Transformaciones vitales más amplias.
- Menor dependencia de una única categoría profesional.
- Autoridad basada en una visión del mundo, no solo en una métrica.

El cambio puede resumirse así:

**enseñar tácticas de creación → interpretar el mundo para aspirantes a creadores**

La marca se vuelve más amplia a medida que su voz se vuelve más reconocible.

---

## 13. Su publicación con mejor resultado

La anomalía del archivo es *Most high-income skills will be irrelevant in 10 years (learn these 4 skills instead)*, con 4.449 likes y 265 comentarios visibles.

El título concentra varias de sus mejores técnicas:

- amenaza a la seguridad económica;
- horizonte temporal;
- pérdida potencial;
- lista concreta;
- promesa de sustitución;
- relevancia para un público amplio.

No exige que el lector quiera escribir o crear contenido. Habla de una inquietud universal: **seguir siendo valioso en el futuro**.

Esto respalda una observación importante:

> **El contenido especializado ayuda a monetizar; el contenido de identidad, futuro y supervivencia amplía la audiencia.**

---

## 14. Lo que predica frente a lo que hace

### “No te encierres en un nicho”

Lo cumple en variedad temática, pero no habla de cualquier cosa. Sus intereses están unidos por una misión y un lector reconocible.

La lección precisa es:

> **No necesitas un único tema; necesitas una transformación coherente.**

### “Los hilos generan crecimiento”

Su propia trayectoria y sus afirmaciones coinciden: X fue el motor inicial de distribución y Substack recibió esa audiencia.

### “El email genera ingresos”

Sus lanzamientos, ofertas y explicación del reparto de ingresos muestran que utiliza el email para vender, no solo para publicar ensayos.

### “Repite las ideas ganadoras”

El archivo muestra variaciones reiteradas sobre audiencia, reinvención, independencia, habilidades y productos basados en problemas personales.

### “Convierte tus problemas en productos”

Su propio negocio evoluciona desde resolver problemas de clientes hasta empaquetar los sistemas que desarrolló para sí mismo.

---

## 15. La estrategia completa

Reconstruida a partir del archivo, su estrategia es:

1. aprender una habilidad comercializable;
2. ofrecerla como servicio;
3. publicar sobre el problema y el proceso;
4. dominar un formato con distribución —los hilos—;
5. construir audiencia en una plataforma social;
6. trasladar parte de la audiencia al email;
7. lanzar repetidamente para aprender ventas;
8. utilizar servicios de alto precio para generar caja;
9. crear talleres y productos baratos para demostrar competencia;
10. convertir experiencia en marcos propios;
11. ampliar el posicionamiento desde una habilidad hacia una misión;
12. reutilizar ideas ganadoras hasta convertirlas en propiedad intelectual.

No es una historia de crecimiento puramente orgánico dentro de Substack. Tampoco es una historia de ingresos pasivos desde el principio.

Es una progresión desde habilidades y servicios hacia audiencia, productos y una marca intelectual más amplia.

---

## 16. Qué se puede reproducir

- Separar el canal de descubrimiento del canal de conversión.
- Empezar vendiendo servicios cuando todavía no existe una gran audiencia.
- Lanzar para aprender, no solo cuando todo parece perfecto.
- Usar productos baratos como prueba de competencia.
- Convertir una newsletter en fuente de muchas piezas, no en una tarea aislada.
- Revisar resultados y repetir las ideas que funcionan.
- Construir una marca alrededor de una transformación, no de una lista de temas.
- Ampliar el contenido cuando la misión y el lector están claros.

## 17. Qué no debería copiarse mecánicamente

- Sus cifras y promesas extremas sin resultados propios.
- La variedad temática sin una identidad central.
- Suponer que abrir una cuenta en Substack reproducirá su crecimiento; él llegó con audiencia previa.
- Confundir correlación con causalidad.
- Repetir su voz, lenguaje o marcos en lugar de extraer principios.
- Lanzar muchas ofertas sin capacidad real de cumplirlas.

---

## Conclusión

La lectura superficial de Hussain Ibarra es:

> Escribe sobre crecimiento, marcas personales y negocios unipersonales.

La lectura del archivo completo es:

> **Aprendió distribución en redes, convirtió la atención en una lista propia, monetizó mediante lanzamientos frecuentes y servicios de alto valor, transformó la experiencia en productos y amplió gradualmente su marca desde la escritura hacia una misión personal.**

Sus principios operativos son simples, aunque no fáciles:

**aprende → publica → mide → repite → convierte → amplía**

Y el hallazgo más importante no está en uno de sus consejos, sino en la secuencia de su trayectoria:

> **La newsletter convirtió la atención en negocio, pero la atención se había construido antes.**

Eso es lo que aparece cuando dejamos de analizar publicaciones aisladas y empezamos a estudiar el archivo como evidencia.
