# Guía para analizar el archivo de cualquier autor

Una guía de [Soto Platero](https://sotoplatero.substack.com), la newsletter de Damián Soto sobre escritura, creadores, ideas y herramientas para pensar mejor.

## Qué vas a conseguir

Al terminar tendrás un análisis longitudinal del autor que responda:

- cómo evolucionó su escritura;
- qué hizo realmente;
- qué ideas y formatos repitió;
- qué dejó de hacer;
- cómo construyó su posicionamiento;
- qué canales utilizó para conseguir atención;
- cómo conectó contenido y negocio;
- qué patrones puedes aplicar sin copiarlo.

El resultado no debe ser un resumen de artículos. Debe ser una reconstrucción basada en evidencias.

---

## Paso 1 — Elige bien al autor

El método funciona mejor cuando el autor cumple varias condiciones:

- lleva al menos uno o dos años publicando;
- tiene varias decenas de publicaciones públicas;
- las publicaciones conservan fechas y títulos;
- ha cambiado de temas, productos o posicionamiento;
- comparte experiencias, resultados o decisiones;
- existe suficiente material gratuito para observar patrones.

Una gran audiencia ayuda, pero no es imprescindible. Un archivo cronológico rico es más importante que la popularidad.

---

## Paso 2 — Descarga su archivo público

Entra en:

**https://damiansoto.me/tool/archive**

Después:

1. Copia la dirección principal de la publicación de Substack que quieres estudiar.
2. Pégala en la herramienta.
3. Inicia la descarga del archivo público.
4. Guarda el ZIP en tu equipo.
5. Descomprímelo.

Normalmente encontrarás:

- un archivo `indice.csv` con títulos, fechas, palabras y métricas;
- una carpeta `posts` con una publicación en Markdown por archivo;
- un documento `LEEME.md` con el alcance y las limitaciones de la descarga.

Los artículos de pago pueden aparecer truncados porque la herramienta solo puede recopilar la parte mostrada públicamente por Substack.

---

## Paso 3 — Prepara el material para la IA

Puedes trabajar de dos maneras.

### Método sencillo

Si el conjunto no es demasiado grande, reúne todos los `.md` en un único documento, ordenados del más antiguo al más reciente.

Antes de cada artículo conserva:

- título;
- fecha;
- URL;
- número de palabras;
- likes;
- comentarios;
- audiencia gratuita o de pago.

Usa un separador claro entre artículos:

```text
---

# Título del artículo
Fecha: …
URL: …

[Cuerpo completo]
```

Después sube el documento único a la conversación.

### Método para archivos grandes

Si existen cientos de publicaciones, trabaja por fases:

1. entrega primero `indice.csv`;
2. pide una auditoría y una clasificación cronológica;
3. divide los artículos por etapas;
4. analiza cada etapa por separado;
5. entrega las conclusiones parciales para producir la síntesis final.

Este método reduce olvidos y evita que las últimas publicaciones dominen el análisis.

### Si la IA no acepta el ZIP

No subas el ZIP directamente. Descomprímelo y sube el Markdown combinado, el índice o grupos de archivos `.md`.

También puedes pedir a una IA con acceso a tus archivos locales:

```text
Busca el ZIP que acabo de descargar, extráelo, localiza todas las publicaciones Markdown y reúnelas cronológicamente en un único archivo. Conserva los metadatos y no modifiques el contenido de los artículos.
```

---

## Paso 4 — Ejecuta el prompt maestro

Abre:

`03-prompts/prompts-analizar-archivo-de-cualquier-autor.md`

Copia el bloque titulado **Prompt maestro** y entrégaselo a la IA junto con el archivo del autor.

La pregunta central es:

> **Ignora por un momento lo que este autor dice que hay que hacer. ¿Qué hizo realmente según las huellas que dejó en su archivo?**

El prompt obliga a separar:

- **hecho observable:** aparece directamente en el archivo;
- **afirmación del autor:** el autor cuenta un resultado que no está verificado independientemente;
- **inferencia:** interpretación derivada de varios patrones.

No elimines esta separación. Es lo que impide que el análisis se convierta en una historia de éxito inventada.

---

## Paso 5 — Verifica la auditoría inicial

Antes de aceptar el análisis, comprueba:

- número correcto de publicaciones;
- primera y última fecha;
- documentos sin cuerpo;
- artículos de pago truncados;
- palabras totales;
- métricas disponibles;
- duplicados o entradas que no sean newsletters.

Si la auditoría es incorrecta, corrígela antes de continuar. Todas las conclusiones posteriores dependen de esa base.

---

## Paso 6 — Analiza la evolución cronológica

No agrupes los artículos en periodos arbitrarios. Busca cambios observables:

- nuevos temas;
- títulos diferentes;
- artículos más largos o cortos;
- nueva audiencia objetivo;
- aparición o desaparición de productos;
- cambios en las llamadas a la acción;
- nuevas fuentes de autoridad;
- cambio de una habilidad concreta hacia una misión más amplia.

Una pregunta especialmente útil es:

```text
Compara los primeros 10 artículos con los últimos 10. ¿En qué se convirtió este autor como escritor, creador y empresario? ¿Qué dejó atrás?
```

---

## Paso 7 — Separa consejos y comportamiento

Pide una tabla con:

```text
Consejo | Comportamiento observable | Coherencia o tensión | Evidencia | Confianza | Explicación alternativa
```

Ejemplos de aspectos que conviene contrastar:

- recomienda elegir un nicho, pero ¿sus temas se estrechan realmente?;
- recomienda ser original, pero ¿repite ideas ganadoras?;
- recomienda una plataforma, pero ¿de dónde llegó su audiencia?;
- recomienda productos baratos, pero ¿qué parece generar sus ingresos?;
- defiende la espontaneidad, pero ¿qué grado de planificación muestra su proceso?

No busques contradicciones artificiales. Una estrategia puede cambiar con el tiempo.

---

## Paso 8 — Reconstruye su máquina de contenido

Intenta expresar el sistema en una sola línea:

```text
fuente → idea → pieza principal → distribución → relación → oferta → feedback → repetición
```

Después exige evidencias para cada conexión.

Preguntas útiles:

- ¿De dónde obtiene las ideas?
- ¿Cuál es su pieza principal?
- ¿Cómo reutiliza el contenido?
- ¿Qué canal genera descubrimiento?
- ¿Qué canal convierte atención en relación?
- ¿Qué contenidos atraen y cuáles venden?
- ¿Qué ideas repite hasta convertirlas en propiedad intelectual?

---

## Paso 9 — Analiza títulos y rendimiento

Clasifica los títulos mediante estructuras como:

- transformación directa;
- resultado + mecanismo;
- amenaza + salida;
- contradicción;
- urgencia temporal;
- confesión + lección;
- número específico;
- identidad o aspiración.

Si existen métricas, compara las cinco publicaciones con mejor resultado y las cinco con peor resultado.

No concluyas automáticamente que el título produjo el resultado. También pueden influir:

- el tamaño de la audiencia en ese momento;
- la antigüedad del artículo;
- la distribución externa;
- una colaboración;
- el tema;
- un acontecimiento de actualidad.

Transforma las conclusiones en hipótesis que puedan probarse, no en leyes universales.

---

## Paso 10 — Sigue la genealogía de una idea

Elige una idea recurrente y sigue su evolución:

```text
primera aparición → reformulación → historia → marco propio → producto → argumento de venta
```

Este análisis permite descubrir cómo una idea termina convirtiéndose en propiedad intelectual y, en algunos casos, en negocio.

---

## Paso 11 — Busca lo que desapareció

El abandono también contiene información.

Busca:

- temas que dejaron de aparecer;
- productos que ya no promociona;
- plataformas que perdió interés en utilizar;
- ofertas que no volvió a lanzar;
- identidades profesionales que superó;
- formatos que fueron reemplazados.

No inventes el motivo. Propón varias explicaciones y señala qué evidencia faltaría para confirmarlas.

---

## Paso 12 — Extrae principios sin crear un clon

Termina separando:

### Reproducible

Principios, procesos y experimentos que otra persona puede adaptar.

### Dependiente del contexto

Acciones que funcionaron gracias a su audiencia, reputación, plataforma, momento o recursos.

### No copiar

Su tono, frases, títulos, historias personales, cifras o productos.

El objetivo es producir un **clon estratégico**, no estilístico.

---

## Paso 13 — Convierte el análisis en contenido

No publiques todo el informe como una lista de hallazgos. Elige un descubrimiento inesperado y constrúyelo con tres pruebas.

Una estructura eficaz es:

1. experimento;
2. pregunta diferente;
3. descubrimiento inesperado;
4. tres evidencias;
5. nueva interpretación;
6. limitación;
7. frase final memorable.

Ejemplo de apertura:

> Descargué todos los artículos públicos de un creador que admiro y se los di a una IA. Pero no le pedí que resumiera sus consejos. Le pedí que reconstruyera lo que realmente hizo.

La pieza debe aportar valor incluso si el lector nunca visita la herramienta.

---

## Lista de control final

Antes de guardar o publicar el informe, verifica:

- [ ] El número de artículos es correcto.
- [ ] La cronología está clara.
- [ ] Cada hallazgo importante contiene evidencias.
- [ ] Las cifras del autor aparecen como autorreportadas.
- [ ] Las inferencias están identificadas.
- [ ] No se presenta correlación como causalidad.
- [ ] Se ofrecen explicaciones alternativas.
- [ ] Se distingue atención, relación y monetización.
- [ ] Se explica qué cambió y qué desapareció.
- [ ] Los principios son transferibles sin copiar el estilo.
- [ ] Las limitaciones del archivo aparecen en el informe.

---

## Flujo resumido

**Substack → archivo descargado → auditoría → cronología → patrones → evidencias → interpretación → principios transferibles → contenido publicable**

Descarga el archivo público de cualquier publicación desde:

**https://damiansoto.me/tool/archive**

Para recibir nuevos experimentos, análisis de creadores y formas de utilizar la IA para aprender de quienes admiras, suscríbete a [Soto Platero](https://sotoplatero.substack.com).
