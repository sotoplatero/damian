# Dan Koe: anatomía de una marca que convierte identidad en negocio

## Resumen ejecutivo

Analicé el archivo público de *future/proof*: 90 entradas publicadas entre mayo de 2025 y agosto de 2026. El conjunto contiene 86 cuerpos en Markdown —algunos de pago están truncados— y unas 297.000 palabras. Para evitar confundir popularidad con estrategia, comparé cronología, títulos, temas, frecuencia, llamadas a la acción, productos y métricas visibles.

La conclusión principal es esta:

> **Dan Koe no vende información sobre negocios. Vende una identidad: la persona autónoma que aprende, escribe, crea una audiencia y convierte sus intereses en una vida propia.**

El negocio unipersonal es la consecuencia comercial de esa identidad. Por eso puede hablar de propósito, dopamina, inteligencia, escritura, IA, estrategia o dinero sin que la marca se descomponga. Los temas cambian; la transformación prometida es siempre la misma.

Su sistema puede resumirse así:

**malestar con la vida convencional → nueva visión del mundo → reconstrucción personal → escritura pública → audiencia → producto → autonomía**

---

## 1. Qué contiene realmente el archivo

- 90 entradas en el índice.
- 86 publicaciones con cuerpo disponible.
- 70 entradas gratuitas y 20 de pago; cuatro son podcasts o *restacks* sin cuerpo.
- 297.374 palabras entre las publicaciones con cuerpo.
- Promedio por publicación: 3.458 palabras, 1.137 likes, 49 comentarios y 163 restacks.
- Periodo: 3 de mayo de 2025 a 8 de agosto de 2026.

Las métricas no permiten atribuir causalidad. Los textos antiguos han tenido más tiempo para acumular interacciones y la audiencia creció durante el periodo. Además, cifras sobre seguidores o ingresos proceden del propio Dan. El archivo demuestra qué publicó y cómo lo presentó; no audita sus cuentas.

---

## 2. El verdadero posicionamiento

A primera vista, Dan escribe sobre demasiadas cosas:

- desarrollo personal;
- pensamiento y aprendizaje;
- escritura;
- creación de contenido;
- marca personal;
- negocios unipersonales;
- dinero;
- IA;
- filosofía y sentido vital.

Pero no son ocho nichos. Son ocho partes de una misma historia.

Dan presenta al lector como alguien atrapado en un guion industrial: escuela, especialización, empleo, consumo, distracción y dependencia. Después ofrece una salida: recuperar agencia, desarrollar una mente propia, aprender habilidades, escribir en público, reunir una audiencia y crear productos.

Su nicho no es “marca personal” ni “negocios para creadores”. Es algo más amplio:

> **Autonomía personal y económica para personas intelectualmente curiosas que no encajan en una carrera convencional.**

Esto explica por qué su artículo sobre intereses múltiples puede llevar naturalmente a un negocio unipersonal, o por qué un ensayo sobre escribir mejor puede terminar presentando una herramienta. El puente no es el tema. El puente es la identidad del lector.

---

## 3. Las tres etapas visibles

### Etapa 1 — El laboratorio de productos (mayo–agosto de 2025)

En los primeros cuatro meses aparecen 47 publicaciones: más de la mitad del archivo. Solo mayo contiene 20 entradas, 10 de pago.

La mezcla es reveladora:

- manifiestos y ensayos gratuitos;
- prompts de IA;
- guías de escritura;
- sistemas de trabajo profundo;
- creación de productos;
- marca personal;
- cursos y recursos empaquetados.

Dan no espera a que la newsletter madure para monetizarla. Usa la publicación como escaparate, laboratorio y canal de distribución desde el principio. La frontera entre contenido y producto es deliberadamente porosa: un ensayo plantea el problema; una guía, prompt, curso o aplicación ofrece una implementación.

En esta fase, Kortex es el producto que aparece con mayor frecuencia. El archivo registra 58 menciones durante los primeros cuatro meses, frente a tres entre septiembre y diciembre y una en 2026. El producto cambia; la narrativa que lo sostiene permanece.

### Etapa 2 — La expansión hacia identidad y cultura (septiembre–diciembre de 2025)

La frecuencia cae a 19 newsletters en cuatro meses, pero las piezas se vuelven más reconocibles y más masivas. Aquí aparecen varios de los mayores resultados del archivo:

| Publicación | Likes | Restacks |
|---|---:|---:|
| *How to articulate yourself intelligently* | 15.175 | 1.978 |
| *How to fix your entire life in 1 day* | 7.576 | 1.449 |
| *A dopamine detox to reset your life in 30 days* | 2.362 | 308 |
| *The most important skill to learn in the next 10 years* | 1.946 | 363 |

El cambio importante no es solo cuantitativo. Se desplaza desde “cómo crear contenido o vender un producto” hacia preguntas de identidad:

- ¿Cómo pienso mejor?
- ¿Cómo articulo mis ideas?
- ¿Cómo recupero el control de mi atención?
- ¿Cómo rehago mi vida?
- ¿Qué habilidad me hará valioso en el futuro?

Este es el gran ensanchamiento de la marca. Dan deja de atraer únicamente a aspirantes a creadores y empieza a atraer a cualquiera que sienta que su capacidad está desaprovechada.

### Etapa 3 — La síntesis intelectual y comercial (enero–agosto de 2026)

En 2026 publica 20 newsletters con cuerpo. La mayoría son ensayos gratuitos, largos y autosuficientes. Ya no necesita tantos microproductos editoriales de pago: la newsletter gratuita funciona como infraestructura de atención y sus productos viven fuera de ella.

El cambio de producto también es visible. Las menciones de Kortex prácticamente desaparecen y Eden aparece 70 veces en los textos de 2026. Dan conserva el mismo argumento —convertir conocimiento, intereses y escritura en resultados— pero conecta esa promesa con una herramienta nueva.

Los ensayos recientes integran tres capas que antes aparecían más separadas:

1. **Filosofía:** agencia, propósito, sentido, estrategia.
2. **Educación:** cómo pensar, escribir, aprender o construir.
3. **Comercio:** Eden, Creator Bootcamp y otros recursos como mecanismos de implementación.

No abandona el negocio. Lo envuelve en una visión del mundo más grande.

---

## 4. Lo que hizo, no solo lo que recomienda

La trayectoria que Dan describe en sus propios textos puede reconstruirse así:

1. Probó diversos modelos —Facebook Ads, SEO, *dropshipping*, arte digital y otros— sin tratarlos todavía como negocios serios.
2. Vendió servicios, especialmente diseño web, y comenzó a escribir en Twitter para atraer clientes sin depender de prospección en frío.
3. El servicio evolucionó hacia consultoría o asesoría de marca.
4. Convirtió la escritura en el núcleo de un ecosistema: newsletter → vídeo → podcast → publicaciones sociales.
5. Usó la audiencia para distribuir cursos, membresías, libros, prompts y software.
6. Transformó su método de trabajo en propiedad intelectual y después en producto: Kortex primero; Eden más tarde.

Su embudo real no parece ser simplemente “publica contenido y vende un curso”. Es más parecido a:

**resolver un problema propio → documentar la solución → formular una visión → atraer personas con el mismo problema → empaquetar el método → construir una herramienta que facilite aplicarlo**

El producto es, literalmente, una parte externalizada de su forma de pensar.

---

## 5. Su máquina de contenido

Dan afirma que organiza su sistema alrededor de una newsletter semanal. El propio archivo respalda la arquitectura, aunque no siempre la cadencia exacta:

1. Elige un problema relacionado con su misión.
2. Investiga ideas que ya han demostrado interés.
3. Las filtra mediante su propia visión del mundo.
4. Escribe un ensayo largo.
5. Convierte el ensayo en guion flexible para YouTube y podcast.
6. Extrae ideas para publicaciones cortas.
7. Conecta el tema con un producto que permite actuar.

Esto crea una ventaja importante: no necesita inventar ideas independientes para cada plataforma. El ensayo funciona como proyecto intelectual de la semana y como materia prima para todo lo demás.

La unidad básica de su sistema no es el post. Es la **idea madre**.

---

## 6. Cómo fabrica títulos

Entre los 67 títulos gratuitos del conjunto:

- 18 empiezan por “How…”;
- 29 incluyen “you” o “your”;
- 28 contienen una cifra;
- 11 emplean paréntesis;
- al menos 15 usan negación, amenaza o ruptura: *death*, *wrong*, *fake*, *don’t*, *won’t*, *ruin*, *fail*.

Sus fórmulas más frecuentes son:

### Transformación directa

- *How to articulate yourself intelligently*
- *How to fix your entire life in 1 day*
- *How to think like a strategic genius*

### Habilidad + importancia futura

- *The most important skill to learn in the next 10 years*
- *The most profitable skill of the 21st century (not AI)*

### Amenaza + salida

- *How to become so valuable AI will never replace you*
- *The death of the 9–5 job…*
- *Most creators will fail…*

### Contradicción o giro

- *How to remember everything you read… don’t*
- *Growing on social media is easy, actually*
- *You don’t need a niche…*

### Urgencia temporal

- *You have about 36 months to make it*
- *7 days to lock it in*
- *…in 30 days*

Los títulos prometen una recompensa individual enorme, pero el cuerpo suele ampliar el asunto hacia un sistema filosófico. Esa combinación es una de sus armas principales:

> **El título captura con una ambición concreta; el ensayo retiene con una cosmovisión.**

---

## 7. Qué publicaciones funcionan mejor

Los tres resultados extraordinarios son:

1. *How to articulate yourself intelligently* — 15.175 likes.
2. *If you have multiple interests, do not waste the next 2–3 years* — 10.289 likes.
3. *How to fix your entire life in 1 day* — 7.576 likes.

Están muy por encima del promedio de 1.137 likes y comparten seis rasgos:

1. **El lector es el protagonista.** No prometen explicar a Dan; prometen transformar al lector.
2. **Atacan una inseguridad privada y extendida.** No saber expresarse, sentirse disperso o creer que se está desperdiciando la vida.
3. **Ofrecen una mejora de identidad.** Ser inteligente, integrado, disciplinado o dueño de la propia dirección.
4. **No requieren querer ser “creador”.** El mercado potencial es mucho mayor.
5. **Convierten intereses abstractos en una ruta práctica.**
6. **Son fáciles de recomendar.** Compartirlos también comunica algo positivo sobre quien los comparte.

La evidencia sugiere que el contenido de negocio es útil para monetizar la atención, pero el contenido de identidad es el que más expande la atención.

---

## 8. La arquitectura persuasiva de un ensayo de Dan Koe

Sus textos suelen seguir una secuencia reconocible:

1. **Diagnóstico:** tu vida, mente o trabajo no funcionan como deberían.
2. **Enemigo:** escuela, empleo industrial, especialización, algoritmos, distracción, cultura convencional o uso superficial de la IA.
3. **Reencuadre:** el problema no es pereza o falta de talento, sino una identidad y un sistema equivocados.
4. **Posibilidad:** internet, medios, código y audiencia permiten una alternativa.
5. **Mapa:** principios, niveles, fases o pasos.
6. **Prueba personal:** su experiencia o la de alguien cercano.
7. **Implementación:** escritura, audiencia, oferta, producto o herramienta.
8. **CTA comercial:** el producto aparece como continuación lógica del argumento.

Esto evita que la venta parezca un bloque completamente separado. Si el problema es que el lector carece de sistema, venderle un sistema parece coherente.

---

## 9. Lo que predica frente a lo que hace

### “No necesitas un nicho”

Lo cumple a nivel temático, pero no publica de forma aleatoria. Repite obsesivamente un conjunto pequeño de ideas: agencia, propósito, escritura, intereses múltiples, audiencia, negocio unipersonal y futuro del trabajo.

La lección precisa no es “habla de cualquier cosa”. Es:

> **Puedes abordar muchos temas si todos ayudan al mismo tipo de persona a atravesar la misma transformación.**

### “Crea desde tus intereses”

Lo hace, pero no ignora el mercado. Sus títulos son extremadamente conscientes de atención, deseo, amenaza, curiosidad y resultados. La autenticidad aporta materia prima; el empaquetado aporta distribución.

### “La newsletter debe ser el centro”

El archivo lo respalda. Los ensayos funcionan como investigación, producto editorial, guion, fuente de publicaciones cortas y vehículo comercial.

### “El producto es una herramienta de transformación”

También lo aplica. Sus productos evolucionan desde educación y plantillas hacia software que materializa su método. Kortex y Eden no son temas nuevos: son distintas implementaciones de la misma promesa.

### “La IA no sustituye el pensamiento”

Su estrategia depende intensamente de la IA, pero la coloca después del criterio. Vende prompts y software mientras insiste en que una persona sin gusto, experiencia ni comprensión solo producirá mediocridad más deprisa. No rechaza la IA; la subordina a una mente entrenada.

---

## 10. Las tensiones que fortalecen su marca

Dan combina ideas que normalmente aparecen separadas:

- propósito **y** dinero;
- filosofía **y** tácticas de marketing;
- intereses múltiples **y** una narrativa muy disciplinada;
- crítica a la productividad **y** sistemas de ejecución;
- rechazo a la vida convencional **y** fórmulas comerciales muy estructuradas;
- defensa del pensamiento original **y** estudio consciente de ideas validadas;
- crítica al contenido superficial **y** títulos diseñados para maximizar el clic.

No son necesariamente incoherencias. Son el mecanismo de la marca. Dan promete reconciliar al intelectual con el emprendedor: no tienes que elegir entre pensar profundamente y ganar dinero.

---

## 11. Su ventaja competitiva

Su verdadera ventaja no es una táctica de crecimiento. Es la integración de cuatro capacidades:

1. **Síntesis:** conecta filosofía, psicología, negocios, tecnología y experiencia personal.
2. **Empaquetado:** convierte ideas complejas en títulos, marcos y secuencias memorables.
3. **Distribución:** transforma un ensayo en contenido para múltiples canales.
4. **Productización:** convierte partes del proceso en libros, cursos, membresías o software.

Muchos pensadores no saben distribuir. Muchos creadores distribuyen ideas poco profundas. Muchos vendedores no poseen una visión reconocible. Dan ocupa la intersección.

---

## 12. Qué se puede reproducir —y qué no

### Reproducible

- Definir una transformación central más amplia que un tema.
- Escribir una pieza madre y derivar el resto del contenido de ella.
- Repetir un conjunto pequeño de problemas desde ángulos distintos.
- Alternar contenido amplio de identidad con contenido específico de implementación.
- Diseñar títulos para captar atención sin limitar la profundidad del cuerpo.
- Convertir los métodos propios en herramientas o productos.
- Empezar vendiendo servicios antes de depender de productos de audiencia.

### No reproducible de forma mecánica

- Copiar su tono filosófico sin haber desarrollado una visión propia.
- Publicar sobre muchos temas sin una transformación unificadora.
- Usar sus títulos sin una promesa creíble detrás.
- Atribuir sus resultados a la newsletter aislada: su audiencia y ecosistema externo ya son parte de la distribución.
- Asumir que sus métricas demuestran que cada consejo causó su éxito.

---

## Conclusión

La lectura superficial de Dan Koe es:

> Construye una marca personal, escribe en internet y crea un negocio unipersonal.

La lectura del archivo completo es más interesante:

> **Construye una interpretación del mundo en la que tu producto sea la herramienta lógica para convertirte en la persona que esa interpretación promete.**

Dan no comienza cada semana desde cero. Vuelve una y otra vez a la misma transformación, cambia la puerta de entrada y actualiza el vehículo comercial.

Primero vende la posibilidad de escapar de una vida prestada.

Después enseña que escribir, aprender y construir son el camino.

Finalmente ofrece productos que aceleran ese camino.

Ese es el sistema que aparece cuando dejamos de preguntarle qué recomienda y empezamos a observar qué publicó.
