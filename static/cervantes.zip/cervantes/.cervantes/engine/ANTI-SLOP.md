# Anti-slop — banned patterns (always enforced)

"AI noise" is the single biggest tell that a machine wrote the text. Cervantes never produces the patterns
below — in drafts, polish, titles, subjects, subheads, or cover copy.

Each pattern is listed with real surface forms in **ES** (Spanish) and **EN** (English), because surface
forms are what's actually checkable against a real text. The pattern is what's banned, not those specific
words — see § Any other language.

## The exception rule (read first)

A pattern is allowed ONLY if `voice/profile.md` documents it as a legitimate signature of THIS
author's real voice (observed in their published text, not assumed) — and even then only when it comes
from a real tension, never as empty filler. A documented exception in the profile overrides this list.

## The frequency rule (read second)

Several devices below are legitimate craft **once**, and a tell the moment they become a habit: the
one-word dramatic pause, the trailing ellipsis, the rule of three, the aphorism, the mid-sentence dash.
They got overused because they worked. So the test is density, not existence:

> **Once per issue, earned by real tension: fine. Twice: cut one. A per-section reflex: it's a tic, and
> readers who see AI text all day will clock it.**

Everything under *Rhythm tics* is governed by this rule. Everything else is a flat ban. Counting is the
`editor` agent's job — across the whole issue, not within a section, because a device used once per
section is a tic even though no single section overused it.

## Banned patterns

### Formulaic openings
- **The "something made me think" preamble.**
  ES: *"Hace unos días leí algo que me hizo pensar…"*, *"Recientemente me topé con…"*
  EN: "The other day I read something that got me thinking…", "I recently came across…"
  Open with the thought itself.
- **Scene-setting from nowhere.**
  ES: *"En un mundo donde…"*, *"Imagina por un momento…"*
  EN: "In a world where…", "In today's fast-paced world…", "Imagine for a moment…"
  Nobody starts a real conversation this way.
- **Rhetorical question as the first line.**
  ES: *"¿Y si nos pusiéramos de acuerdo en…?"*, *"¿Alguna vez te ha pasado que…?"*
  EN: "What if I told you…?", "Have you ever…?", "Ever wondered why…?"
  The hypothetical + inclusive "we" is a machine favorite: it manufactures community with no one in the room.

### Antithesis and manufactured contrast
- ES: *"No es X. Es Y."*, *"De X a Y"*, *"¿X? No. Y."*, *"No solo X, sino Y"*, *"Deja de X, empieza a Y"*
  EN: "It's not X, it's Y", "From X to Y", "X? No. Y.", "not only X, but Y", "Stop X, start Y"
- **The reframed-question move.**
  ES: *"La pregunta no es si vas a usar X. La pregunta es cómo."*
  EN: "The question isn't whether you'll use X — it's how."
- Allowed only when the contrast genuinely stings — when Y actually contradicts X and the author can show
  it. Decorative contrast is banned.

### Announced effects
The text claims an effect instead of producing it. Always cut the announcement; keep whatever follows, if
anything is really there.
- **Announced honesty.** ES: *"Permíteme ser honesto contigo"*, *"Te voy a ser sincero"* · EN: "Let me be
  honest with you", "I'll be real with you". Real honesty doesn't ask permission — it just shows up.
- **Announced depth.** ES: *"Esto me hizo reflexionar profundamente"*, *"Hay algo más profundo aquí"* ·
  EN: "This made me reflect deeply", "There's something deeper here". Depth is visible in the next
  paragraph or it isn't there.
- **Announced importance.** ES: *"y eso lo cambió todo"*, *"spoiler:"*, *"esta es la clave"* · EN: "and
  that changed everything", "spoiler:", "here's the key".

### Filler bridges and empty profundity
- **Connective tissue joining two ideas that don't connect.**
  ES: *"Porque hay algo más profundo en juego"*, *"Y ahí está la clave"*, *"La realidad es que"*
  EN: "Because there's something deeper at play", "And that's the key", "The reality is that"
  If the bridge is load-bearing, the ideas don't belong in the same paragraph.
- **The too-perfect aphorism** — a sentence so balanced it reads as generated.
  ES: *"La ventaja competitiva no está en tener la herramienta. Está en saber cuándo no usarla."*
  EN: "The competitive advantage isn't having the tool. It's knowing when not to use it."
  Real insight arrives lopsided and specific. If it would fit any newsletter in the niche, cut it.
- **Macro generalization with nothing under it.**
  ES: *"cuando todos seguimos la misma recomendación, el mercado deja de diferenciar."*
  EN: "when everyone follows the same advice, the market stops rewarding it."
  Sweeping claims need the author's data, the author's experience, or a real cited source — otherwise
  state it small and concrete.
- **Universal-lesson closing** the text didn't earn.

### The colon gloss

The compressed `concept: explanation` shape — a noun phrase, a colon, and the gloss that explains it —
whether it lands in a subhead or in the middle of a paragraph. It reads as a caption pinned to the text
rather than as somebody talking, and stacked two or three times it is one of the most reliable machine
tells there is.
- ES: *"La clave: la consistencia."*, *"El problema: nadie lo lee."*, *"Título: la guía definitiva"*
  EN: "The key: consistency.", "The problem: nobody reads it.", "Title: the definitive guide"
- **In the body this is a flat ban**, not a frequency call. Write the sentence out — *"la clave es la
  consistencia"* — or better, replace the label with the concrete thing that makes it true. Subheads
  follow the same rule (`WRITING-CRAFT.md` §8).
- What stays legitimate is the colon doing real work: introducing a list, a quote, or an amplification
  the sentence earned (*"Solo pedía una cosa: que le devolvieran el dinero"*). The tell is the **label
  shape** — headline on the left, definition on the right — not the punctuation mark.

### Rhythm tics (frequency rule applies)
- **Empty tricolon.** ES: *"rápido, simple y potente"* · EN: "fast, simple, and powerful." And the
  anaphoric trio — three short parallel sentences in a row.
- **Lists of three** as a default shape. Reality rarely comes in threes; use the number of items there
  actually are.
- **The one-word dramatic pause** on its own line. ES: *"Silencio."* / *"Nada."* · EN: "Silence." / "Nothing."
- **The trailing ellipsis** used to manufacture suspense…
- **Mid-sentence dash density.** The dash is legitimate punctuation — in Spanish the *raya* has always
  marked incisos, and in English the em dash is standard — but AI reaches for it where a comma, a colon, or
  a full stop belongs. Cap it at roughly one per section, and never as a substitute for deciding how two
  clauses relate.
- **Symmetric sentence pairs** used as decoration rather than meaning.

### Inflated and dead vocabulary
- **Adjectives with no proof.** ES: *"transformador"*, *"disruptivo"*, *"revolucionario"*, *"increíble"* ·
  EN: "powerful", "robust", "fascinating", "revolutionary", "incredible", "seamless", "game-changer",
  "delve", "leverage" (as a verb). When everything transforms, nothing does.
- **Exhausted metaphors.** ES: above all *"navegar"* (la incertidumbre, el cambio, la complejidad) ·
  EN: "navigate" (uncertainty, change, complexity), "unlock", "unleash", "supercharge". Name the actual
  action: choosing, postponing, cutting, paying.

### Ritual engagement
- **The reflex closing question.** ES: *"¿Tú cómo lo ves?"*, *"¿Y tú qué opinas?"* · EN: "What do you
  think?", "I'd love to hear your thoughts." Asking is fine; asking the way everyone asks is wallpaper. Ask
  something only this issue could ask, or close on a statement.
- **The altruistic share CTA.** ES: *"Comparte si crees que esto puede ayudar a alguien."* · EN: "Share
  this if you think it could help someone." It's engineered to lower resistance, and the engineering shows.

## Any other language

The list is about the **pattern**, not the wording. When the newsletter is in a language other than
Spanish or English, **derive that language's real equivalents before the sweep** — the forms a fluent
writer of that language would actually recognize as machine cadence — and check against those. Never
transliterate the ES/EN forms word for word: a literal translation catches nothing, because the tell
lives in the idiom, not in the dictionary.

When a genuinely new equivalent surfaces in the author's language, note it in
`voice/profile.md` § Things I NEVER do so it's checked from then on.

## The test

If a sentence could be signed by anyone, it isn't the author's. Rewrite it from a concrete detail in their
material, or cut it.

---

Pattern catalogue expanded from ["Las 20 notas que querrías haber leído antes"](https://nataliapapiol.substack.com/p/las-20-notas-que-no-querrias-haber) — series *"¿Cómo dejar de sonar a IA?"* by Natalia Papiol, used as internal reference.
