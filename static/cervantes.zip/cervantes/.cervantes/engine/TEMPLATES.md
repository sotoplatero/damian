# Templates — structural skeletons

> Skeletons, not text. They give scaffolding; the sentences come from the AUTHOR'S material (or Cervantes drafts them from it). Pick one or mix.

**How a skeleton becomes an outline.** Each bullet below is a candidate H2 section in the brief's outline
(`STRUCTURE.md` §3): it gets a concrete subhead in the author's voice, the beat it carries, what material
feeds it, and a word budget. A skeleton bullet with no material behind it is a gap to fill or a section to
cut — never a section to write anyway.

**Fitting the tier** (`STRUCTURE.md` §1): at `short`, collapse the skeleton to its 2–3 load-bearing
bullets; at `standard`, one section per bullet; at `deep`, the bullets that carry two or three named beats
expand into their own sections (or gain H3 beats). Never repeat a skeleton bullet to fill length — the
skeleton is a shape, not a quota.

## 1. "What I did / learned this week"

The engine format for almost any personal or creator newsletter.

- **Hook (1–2 sentences):** what you did or what grabbed you, and why.
- **What it really is:** short explanation, at the author's level. The reader learns with them, not beneath them.
- **The context / the research:** what already exists? who thought of it before? is there a debate? (with inline links).
- **The tension / the twist:** what you didn't expect.
- **What you did with it:** the concrete action or result.
- **Close:** the lesson or the line you keep.

## 2. "The lesson / the mistake"

- The mistake or the belief held.
- What happened (the story, in order).
- The moment the mind changed.
- What you'd do differently / what you'd tell someone like you.

## 3. "Honest mini-tutorial"

- The real problem you had.
- What you tried (including what did NOT work).
- The steps that worked, no decoration.
- The traps and the "watch out for this."

## 4. "Opinion / take"

- The observation or pattern you see.
- Why it happens (your theory, from experience).
- The uncomfortable nuance (what almost no one says).
- What you propose / what you keep.

## 5. "The reader's transformation" (reader-as-hero arc)

For tutorial/how-to issues where the reader is clearly the protagonist. Use when the material invites it — not as a default mold (see WRITING-CRAFT §13, anti-formula guard).

- **The reader's gap:** where they are now vs. where they want to be — named so they recognize themselves in the first lines.
- **The stakes:** what the gap is costing them (time, money, a recurring frustration).
- **You as guide:** the plan/tool/insight you hand them — you point the way, you're not the hero.
- **The transformation:** the steps, with the real errors and small wins along the way (yours or theirs).
- **The new normal:** what changes for them after — and one concrete first step.

---

## What a complete draft looks like

The author receives the whole issue, written, no gaps — no `[FILL IN]`. Example of an already-written section (generic); note the rhythm (short sentence, long sentence) and the fact doing the work without declaring the emotion:

> ### The mistake that sat in front of me for weeks
>
> It was in plain sight every day. I didn't see it. It took an outsider staring at the same dashboard for ten minutes to point, with a finger, at the thing I'd normalized without noticing. I fixed it in an afternoon. The hard part wasn't fixing it — it was admitting how long I'd been living with it.

If the author wants to add their reaction, they add it when editing — but they already have text that reads on its own.

---

## Subject line

### FORBIDDEN patterns (see ANTI-SLOP.md; profile-documented signatures excepted)
- Antithesis: "From X to Y," "It's not X, it's Y," "X? No. Y.," "Stop X, start Y."
- Hook rhetorical question: "What if I told you…?"
- Colon subhead: "Title: the story of how…"
- Tricolon: "Faster, simpler, more powerful."
- Reframed question: "La pregunta no es si X, es cómo" / "The question isn't whether X — it's how."
- Announced effect: "Esto me hizo reflexionar…", "Te voy a ser sincero…", "Let me be honest with you."

### What to do instead
- **Build the subject from a concrete detail in the material**: a real noun, a real number, a real action. Plain-and-specific beats clever-and-abstract, and it sounds more like the author.
- Useful archetypes: concrete noun/number · honest curiosity gap (name the thing, withhold the turn — only if the body pays it off) · first-person admission ("I was wrong about X," when true) · specific question the reader is already asking.
- **< ~50 characters** when possible — reads in full on mobile, lifts opens. "you/your" beats third person.
- Give **3 variants**, mark the MOST concrete one (usually the winner).
- If a variant could top anyone's post, delete it: it isn't the author's.

## Preheader (preview text)
- **Always set it.** It **extends** the subject — adds a second beat, never repeats the words.
- ~40–90 characters. Never default body text or "View in browser."
- Subject + preheader read together as one two-line promise.

## CTA
- **One only.** Ask for three things and they do none.
- Concrete and verbal: "reply and tell me X," "read it here," "try it."
- To start and grow, the best is usually to **prompt a reply**, not to sell.

## Layout
- Short, scannable paragraphs. The reader skims before reading.
- One idea per paragraph. Bold sparingly, only for what genuinely anchors.
