# Writing craft — how the draft gets written so it grabs

Cervantes' toolbox for writing a complete draft with rhythm, story, and a hook — without inventing anything and without AI noise. Applied in the author's language, filtered through `voice/profile.md`.

This file governs the **prose**. The **shape** of an issue — length tiers, the outline and its brief,
word budgets per section, writing section by section, and the seams pass — lives in `STRUCTURE.md`, and
it runs *before* any of the craft below gets applied.

## 1. One idea

Each issue defends ONE thing. If the material holds more, save it for another issue. Single focus is what gets it read end to end.

## 2. The hook (the first 2 sentences)

The reader decides in 3 seconds. Open with the most concrete thing available:
- a **scene** or **real moment** (better than a generic question),
- a **fact that jars**, or
- a **tension/contradiction** ("I thought X; the opposite happened").

Avoid the marketing-template hook ("What if I told you…?") — that's AI noise. In email, the first line also seeds the **preview text**, so it must earn the open on its own.

**Method:** name the tension first (curiosity / pain / contradiction / desire / identification) → generate 8–10 options across different formulas in `HOOK-FORMULAS.md`, drawn from the author's real material → filter through profile voice + `ANTI-SLOP.md` → pick the 3 most concrete/on-voice. The formula gives the angle; it never overrides the golden rule or the voice. A hook opens a door — it never reveals the whole answer.

## 3. Story, not a list

People remember stories and connect with people, not bullets. Minimum structure: **before → what happened → after**. There's a change, and it shows. Bullets only when they genuinely help scanning, never to narrate. Whose story it is matters — see §13.

## 4. Open loops

Open a question or tension early and **pay it off** later (Zeigarnik effect). Two levels:
- **Macro:** one tension running through the issue, resolved at the end.
- **Micro:** small paragraph-to-paragraph questions that close fast and pull to the next line.

Rule of honor: **every loop opened gets closed.** Otherwise it's clickbait.

## 5. The callback

A detail, phrase, or image from the opening that reappears at the end. Closes the circle; small reward for the reader.

## 6. Rhythm and cadence

The music of prose — this kills rhythmless walls of text:
- **Vary sentence length.** Short ones that hit. Long ones that carry the reader through an idea and let them breathe. Reliable pattern: short, short, long.
- **Vary sentence openings.** Not all subject-verb-object; sometimes open with a subordinate clause or a concrete detail.
- **Vary paragraph size.** A long developing paragraph, then a one-line paragraph to land the point.
- **Read-aloud test.** If you run out of breath or it sounds choppy, something's off. The sentence that sounds natural spoken is the author's voice.
- **Carry the thread across subheads.** Rhythm isn't only inside the paragraph. A heading is a visual pause, never a fresh start: the section under it continues the thought the previous one left standing. `STRUCTURE.md` §6 and the seams pass in §7 govern this.

## 7. Concrete > abstract (show, don't tell)

A real detail outweighs a declared emotion. Not "I felt vertigo" — the concrete fact that produces it ("it was the third time that week"). The fact does the work — and nothing gets invented that the author didn't give.

## 8. Subheads that guide (required)

Every issue has a **title**, a **dek** (the promise under the title), and **internal subheads** — roughly one every 2–4 paragraphs, each concrete and in the author's voice, so a skim of the subheads alone gives the shape of the issue. A draft without internal subheads is incomplete. In a long issue the subheads are the outline rows agreed in the brief; hierarchy rules (when H3 earns its place) are in `STRUCTURE.md` §5. No "The Definitive Guide: Everything You Need to Know" or colon formats (AI noise).

## 9. Plain words, zero filler

Short sentence over long if they say the same thing. Cut adverbs and inflated adjectives ("powerful," "robust," "incredible"). The closing is **earned** by what was told; no free universal moral.

## 10. Subject, preheader & CTA (the part that converts)

Written LAST, from the finished draft — by then the most compelling hook is known.
- **Subject:** one focus, < ~50 characters (reads in full on mobile, lifts opens), concrete and in the author's voice.
- **Preheader:** extends the subject — never repeats it, never leaves default body text. The subject's second line, ~40–90 chars.
- **CTA:** one only. To start and grow a list, the highest-converting move is usually to **prompt a reply**, not to sell.

Concrete archetypes and 3-variant rule: see `TEMPLATES.md` § Subject line.

## 11. Research and cite (situate the story)

The issue isn't only the author's story: it's their story **situated**. Research the topic and weave in: what the thing is really called, who thought of it before, the debate if there is one, and **real, checked links**.

**Links go INLINE, on the word where the claim lives.** This is a newsletter, **not a thesis**: NO references list, bibliography, "Sources," or footnotes at the end. Never invent what a source says; cite in passing, without copying paragraphs.

**And links are rationed.** At most one per section, and only where the claim genuinely rests on the source — a number, a name, prior art, something a reader might not take on trust. Two to four across a whole issue is normal. Linking a term the reader already knows, or stacking three in a paragraph, turns the page into a link farm and costs the reader the thread at every one of them. When a source is worth keeping but the sentence doesn't need it, leave it out: it stays in the `researcher` brief, and a `[[note: ...]]` can offer it to the author without spending the reader's attention.

## 12. Guiding notes (placeholders with meaning)

Alongside the text, leave deletable notes for the author:
- `[[note: ...]]` — an observation or heads-up.
- `[[idea: ...]]` — a suggestion they can take or leave.
- `[[fact?: ...]]` — something they may want to add or verify.
- `[[enrich: ...]]` — points to where the text lands harder with something only the author has: a concrete example, a personal anecdote, their reaction, a real number. Mark the opening; never fill it with invented material.

Seed `[[enrich: ...]]` deliberately where the author's own detail beats any outside context. **If they delete every note, the text still works.**

## 13. Write to ONE reader — who is the hero

Not "hey friends" — from the reader's side there's no room full of other subscribers; it's just them. The letter (voice, point of view) matters more than the news.

And in that letter, **the reader is the hero; the author is the guide** (StoryBrand). The reader has the problem, the gap, the transformation to live; the author points the way — they don't stand center stage taking a bow. Practically, the reader should finish the issue seeing *themselves* changed, not just admiring the author.

This does NOT cancel a confessional, first-person voice. When the author tells their own story — their failure, their number, their mistake — it works precisely because it's the reader's **mirror**: "the same thing is about to bite you." Author's story = the vehicle; reader's transformation = the destination. Tell yours so they see theirs.

**Anti-formula guard:** don't stamp a hero's-journey mold on every issue (personage → gap → guide → transformation → result, week after week). Applied mechanically it becomes the exact template-slop `ANTI-SLOP.md` bans — and it makes every issue sound identical. Use the arc when the material invites it; skip it when a plain observation or a single scene lands harder. The frame serves the story, never the reverse.
