# Hook formulas — reference library

> Swipe library for hooks, openings, titles, and subject lines. Source: "75
> fórmulas de ganchos" by Oscar Feito, adapted as an internal reference.
> **Not copy-paste templates** — they're angle starting points. Every hook
> generated from here still passes the golden rule (nothing invented), the
> author's voice (`voice/profile.md`), and `ANTI-SLOP.md`.

**Bilingual layout.** Each formula keeps the source's original Spanish pattern and example verbatim
(quoted material), followed by an indented **English pattern line** — the shape of the formula, named and
templated. Work from the pattern line, not from the example: the examples are illustrations from another
author's niche, and translating them literally produces exactly the generic copy this engine exists to
avoid. Writing in a third language: derive that language's natural phrasing of the pattern, the way
`ANTI-SLOP.md` § Any other language requires.

## How to use this (method)

When a hook, opening line, title, or subject is needed:
1. **Name the tension first** in one sentence: curiosity, pain, contradiction, desire, urgency,
   identification, or surprise?
2. **Generate ~8–10 options** across *different* formulas below, drawn from the author's real material.
3. **Filter through voice + anti-slop**, then **pick the 3 most concrete / on-voice**, mark the strongest,
   and say in one line why each works.
4. **Don't reveal the whole answer** — a hook opens a door; the body pays it off.

Principles: speak to the *right* reader ("this is about me"); promise only what the issue delivers; for
inbox/Notes keep each line ≤ ~55 chars; hook → reward → hook → reward (first line stops, next justifies
reading on).

## Narrowing the 75 to this author's voice

Don't scan all 75 every time. Once `voice/profile.md` is seeded, pre-select the handful of formulas
that fit the author's stance and reach for those first; record that shortlist in the profile so it carries
across issues.

> **Example shortlist** — for a *first-person, confessional, self-ironic voice that documents failures with
> numbers*: **#13 Menos es más, #19 La verdad sobre, #25 Confesión directa, #28 Reescritura en directo,
> #30 El error invisible, #33 Primer hito, #39 Reencuadre positivo, #45 Revelación del dolor, #52 Lo que
> aprendí pagando caro, #53 Algo hizo clic, #54 Cómo empezaría hoy, #58 Revelación de ROI, #61 Me
> equivoqué, #62 Despiece de éxito atípico, #63 Error costoso, #69 No hagas esto, #75 La verdad
> inesperada.** A different voice (analytical, teacherly, opinion-led) favors a different set — derive it
> from the fingerprint, don't reuse this one.

> Watch for **antithesis** formulas (e.g. #13, #66): anti-slop normally flags antithesis. Allow it only
> when the author's seeded profile marks it as a legitimate signature *and* it comes from a real tension —
> never as empty filler.

## The 75 formulas

1. **Culpa mal asignada** — [Lo que suelen culpar] no es el problema, [lo inesperado] sí. *Ej: Tus correos no son malos. Tus asuntos sí.*
   → *Misassigned blame:* [what they usually blame] isn't the problem — [the unexpected thing] is.
2. **¿Merece la pena?** — ¿Es [hábito/estrategia popular] una pérdida de tiempo? *Ej: ¿Publicar en redes es una pérdida de tiempo?*
   → *Is it worth it:* is [popular habit or strategy] a waste of time?
3. **La gran equivocación de un referente** — El error de [persona conocida] que costó [cifra] en [sector]. *Ej: El absurdo error de Vaynerchuk que costó 10M€.*
   → *A big name's costly mistake:* the mistake [known person] made that cost [figure] in [sector].
4. **Gran resultado misterioso** — [Resultado enorme] haciendo ¿QUÉ? *Ej: ¿Ganó 100.000 seguidores haciendo QUÉ?*
   → *Mystery behind a big result:* [huge result] by doing WHAT?
5. **Resultado inmediato** — Este [recurso simple] consiguió [gran resultado] en [tiempo corto]. *Ej: Este prompt de 3 líneas escribió mi página de ventas en 3 minutos.*
   → *Immediate result:* this [simple resource] produced [big result] in [short time].
6. **Amenaza emergente** — ¿[Nueva tendencia] acabará con [sector]? *Ej: ¿La IA acabará con los copywriters?*
   → *Emerging threat:* will [new trend] kill [sector]?
7. **Truco poco conocido** — ¿Sabías que [herramienta] puede hacer [resultado inesperado]? *Ej: ¿Sabías que Gmail podía hacer esto?*
   → *Little-known trick:* did you know [tool] can do [unexpected result]?
8. **La gran mentira** — Las mayores mentiras sobre [tema]. *Ej: Las mayores mentiras sobre email marketing.*
   → *The big lie:* the biggest lies about [topic].
9. **Método obsoleto** — Por qué [método tradicional] está muerto. *Ej: Por qué LinkedIn está muerto.*
   → *Obsolete method:* why [traditional method] is dead.
10. **Mini rant** — Mini rant: malas formas de [conseguir resultado]. *Ej: Mini rant: las ideas más torpes para destacar en LinkedIn.*
    → *Mini rant:* bad ways to [get result].
11. **Estrategia simple, gran resultado** — Esta [idea simple] puede conseguir [resultado tangible]. *Ej: Esta chorrada te ahorra 1200€ en la renta.*
    → *Simple move, big result:* this [simple idea] can get you [tangible result].
12. **Olvida lo que sabes** — Olvídate de tener un [recurso común] "mejor". *Ej: Olvídate de tener una herramienta de email "mejor".*
    → *Forget what you know:* forget having a "better" [common resource].
13. **Menos es más** — No necesitas [gran supuesto]. Solo necesitas [algo alcanzable]. *Ej: No necesitas 10.000 suscriptores. Solo 1.000.*
    → *Less is more:* you don't need [big assumption] — just [something attainable]. **(antithesis: see the warning above)**
14. **Consejo contrarian** — La mayoría de consejos sobre [tema] son basura. *Ej: La mayoría de consejos sobre tu perfil de LinkedIn son basura.*
    → *Contrarian take:* most advice about [topic] is garbage.
15. **Mirada por dentro** — Mira [sistema/recurso] por dentro. *Ej: Mira mis plantillas de emails que llevan 3 años vendiendo.*
    → *Look inside:* here's [system or asset], from the inside.
16. **Llamada directa a un perfil** — Solo para [arquetipo concreto]. *Ej: Solo para coaches que venden por más de 1.000€.*
    → *Direct call to one profile:* only for [specific archetype].
17. **Error oculto** — ¿Está tu [elemento habitual] matando tu [resultado]? *Ej: ¿Están tus asuntos dañando tus conversiones?*
    → *Hidden mistake:* is your [everyday element] killing your [result]?
18. **Curiosidad sobre ingresos** — ¿Cuánto debería ganar [perfil] haciendo [actividad]? *Ej: ¿Cuánto debería ganar un ghostwriter para un CEO?*
    → *Income curiosity:* how much should [profile] earn doing [activity]?
19. **La verdad sobre** — La verdad sobre [táctica del sector]. *Ej: La verdad sobre Substack.*
    → *The truth about:* the truth about [industry tactic].
20. **Anatomía de un sistema** — La anatomía de [sistema exitoso]. *Ej: La anatomía de un embudo de 6 cifras.*
    → *Anatomy of a system:* the anatomy of [successful system].
21. **Misterio de éxito inesperado** — [Resultado grande]... ¿sin [mecanismo esperado]? *Ej: 100.000 seguidores... ¿sin redes sociales?*
    → *Unexpected-success mystery:* [big result]… without [the expected mechanism]?
22. **Secretos que nadie te contó** — [Número] cosas que tu gurú de [tema] nunca te contó. *Ej: 8 cosas que tu gurú de LinkedIn nunca te contó.*
    → *Secrets nobody told you:* [number] things your [topic] guru never mentioned.
23. **Comparación extraña** — ¿En qué se parece [cosa aleatoria] a [tema]? *Ej: ¿En qué se parece hacer la compra a tener una cita?*
    → *Odd comparison:* what does [random thing] have in common with [topic]?
24. **Tendencia que funciona ahora** — [Número] [formatos] que funcionan en [plataforma] ahora. *Ej: 5 miniaturas que lo petan en YouTube ahora.*
    → *What's working now:* [number] [formats] working on [platform] right now.
25. **Confesión directa** — Confesiones de [identidad vulnerable]. *Ej: Confesiones de un adicto a las Doritos.*
    → *Direct confession:* confessions of [a vulnerable identity].
26. **Relación amor-odio** — Mi relación de amor-odio con [tema popular]. *Ej: Mi amor-odio con la automatización de DMs.*
    → *Love-hate:* my love-hate relationship with [popular topic].
27. **Dilema reconocible** — ¿Debería seguir con [conducta ideal] o dejarlo? *Ej: ¿Sigo publicando en LinkedIn o lo doy por muerto?*
    → *Recognizable dilemma:* should I keep [ideal behavior] or quit it?
28. **Reescritura en directo** — Vamos a reescribir este [elemento mal hecho]. *Ej: Vamos a reescribir este lamentable correo de bienvenida.*
    → *Live rewrite:* let's rewrite this [badly done thing].
29. **Despiece de un caso** — Destripamos [resultado] de [persona/caso]. *Ej: Destripamos cómo Martina vendió 15.000€ con 217 personas.*
    → *Case teardown:* let's take apart how [person/case] got [result].
30. **El error invisible** — El error silencioso que destruye tu [resultado]. *Ej: El "error invisible" que destruye tu reputación en LinkedIn.*
    → *The invisible mistake:* the silent mistake destroying your [result].
31. **Fuente inesperada** — [Fuente inesperada] revela las claves para [resultado]. *Ej: Una panadera de 97 años revela la clave para escribir ganchos.*
    → *Unexpected source:* [unlikely source] reveals the key to [result].
32. **Esperando que salga bien** — ¿Sigues [conducta arriesgada], esperando que salga bien? *Ej: ¿Sigues enviando emails sin autenticar tu dominio?*
    → *Hoping it works out:* still [risky behavior], hoping it works out?
33. **Primer hito** — Cómo conseguí mi primer [hito] como [perfil]. *Ej: Cómo facturé mi primer euro como creador independiente.*
    → *First milestone:* how I got my first [milestone] as [profile].
34. **Interés implícito** — Como te interesa [resultado concreto]... *Ej: Como te interesan los ingresos pasivos...*
    → *Implied interest:* since you care about [concrete result]…
35. **Secreto rápido** — Secreto rápido de [tema] ([beneficio extra]). *Ej: Secreto rápido de viralidad sin prueba y error.*
    → *Quick secret:* a quick [topic] secret ([extra benefit]).
36. **Vieja forma de hacerlo** — ¿Sigues haciendo [acción] a la vieja usanza? *Ej: ¿Sigues llevando tu contabilidad a la vieja usanza?*
    → *The old way:* still doing [action] the old way?
37. **Reto rápido** — Reto de [tiempo corto] para [resultado valioso]. *Ej: Reto de 7 minutos para escribir un gancho imposible de ignorar.*
    → *Quick challenge:* a [short time] challenge to [valuable result].
38. **De odiar a dominar** — Cómo dejar de odiar [tarea necesaria]. *Ej: Cómo dejar de odiar la prospección en frío.*
    → *From hating to owning:* how to stop hating [necessary task].
39. **Reencuadre positivo** — ¿[Situación negativa]? Bien. *Ej: ¿Todavía nadie comenta tus posts? Bien.*
    → *Positive reframe:* [negative situation]? Good.
40. **Pequeño paso, gran resultado** — [Pequeña acción] → [gran resultado]. *Ej: Quité 3 palabras de mi página → 2.000€ más en ventas.*
    → *Small step, big result:* [small action] → [big result].
41. **Acceso entre bastidores** — ¿Quieres ver [activo interno]? *Ej: ¿Quieres ver las aperturas y ventas de cada email de mi lanzamiento?*
    → *Backstage access:* want to see [internal asset]?
42. **Resultado con método inesperado** — [Persona] consiguió [resultado] con [método inesperado]. *Ej: Este fontanero jubilado gana 900€/mes con Etsy en 20 min/día.*
    → *Unexpected method:* [person] got [result] using [unexpected method].
43. **Dura verdad del sector** — [Producto popular] es una gran estafa. *Ej: Las bebidas con electrolitos son una gran estafa.*
    → *Hard industry truth:* [popular product] is a scam.
44. **Cambio de estatus** — [Algo poco valorado] es el nuevo [algo muy valorado]. *Ej: Los negocios personales son los nuevos unicornios.*
    → *Status shift:* [something undervalued] is the new [something prized].
45. **Revelación del dolor** — ¿Tu [elemento clave] no funciona? Este es el motivo. *Ej: ¿Tu página de registro no funciona? Este es el motivo.*
    → *Naming the pain:* your [key element] isn't working? Here's why.
46. **Advertencia FOMO** — Ignora esto y [consecuencia negativa]. *Ej: Ignora esto y serás invisible.*
    → *FOMO warning:* ignore this and [negative consequence].
47. **Activo basado en marco probado** — El [marco conocido] convertido en [activo concreto]. *Ej: El método de Isra Bravo convertido en una Skill de Claude.*
    → *Proven framework as an asset:* [known method], turned into [concrete asset].
48. **Quiero ayudarte con** — ¿Quieres ayuda para [resultado deseado]? *Ej: ¿Quieres ayuda para convertir tu experiencia en un negocio?*
    → *Offer of help:* want help getting [desired result]?
49. **Captura de influencia** — Engañé a [autoridad] para conseguir [resultado inesperado]. *Ej: Engañé a Isra Bravo para regalarme su lista de email.*
    → *Borrowed authority:* I got [authority figure] to hand me [unexpected result].
50. **Cuestionar la sabiduría convencional** — ¿De verdad importa tanto [consejo común]? *Ej: ¿De verdad importa tanto escribir un buen gancho?*
    → *Questioning conventional wisdom:* does [common advice] really matter that much?
51. **Resultado sin coste habitual** — No, [resultado] no tiene por qué implicar [dolor habitual]. *Ej: No, montar un negocio no exige levantarte a las 5:00.*
    → *Result without the usual cost:* no, [result] doesn't have to mean [usual pain].
52. **Lo que aprendí pagando caro** — Pagué [cantidad] por [recurso] pero esto aprendí, gratis. *Ej: Pagué 3.000$ por un mentor pero esto aprendí, gratis.*
    → *What I paid to learn:* I paid [amount] for [resource] — here's the lesson, free.
53. **Algo hizo clic** — [Lucha]... hasta que algo hizo clic. *Ej: Discutíamos cada día... hasta que algo hizo clic.*
    → *Something clicked:* [struggle]… until something clicked.
54. **Cómo empezaría hoy** — Cómo empezaría hoy si [situación actual no existiera]. *Ej: Cómo empezaría hoy si no tuviera audiencia.*
    → *How I'd start today:* how I'd start over if [current advantage] didn't exist.
55. **Mensaje frustrante** — "[Frustración]... [situación reconocible]". *Ej: "Madre mía... mi alcance en LinkedIn se hunde".*
    → *The frustrated message:* "[frustration]… [recognizable situation]".
56. **Stop a un cliché** — Deja de intentar [consejo común], por favor. *Ej: Deja de ir de duro en tus emails, por favor.*
    → *Stop the cliché:* please stop trying to [common advice].
57. **Autoridad + historia** — [Persona conocida] hizo [acción] y pasó esto. *Ej: Mago More me mandó un WhatsApp y pasó esto.*
    → *Authority + story:* [known person] did [action], and this happened.
58. **Revelación de ROI** — Esto cambió mi [métrica] en [cifra] en [plazo]. *Ej: Esto subió mis aperturas un 18% de la noche a la mañana.*
    → *ROI reveal:* this moved my [metric] by [figure] in [timeframe].
59. **Problema entre corchetes** — [Inserta aquí [problema común del lector]]. *Ej: [Inserta aquí otro post escrito por IA que nadie revisó].*
    → *Bracketed problem:* [insert [the reader's familiar problem] here].
60. **Ecuación simple** — 1 [cambio] = más/mejor [resultado]. *Ej: 1 ajuste en la última línea = el doble de respuestas.*
    → *Simple equation:* one [change] = more/better [result].
61. **Me equivoqué** — Me equivoqué sobre [creencia popular]. *Ej: Me equivoqué sobre Substack.*
    → *I was wrong:* I was wrong about [popular belief].
62. **Despiece de éxito atípico** — Cómo [elemento] consiguió [resultado] en [tiempo] (y no fue casualidad). *Ej: Cómo este correo generó 50.000$ en 24h (y no fue casualidad).*
    → *Outlier teardown:* how [thing] got [result] in [time] (and it wasn't luck).
63. **Error costoso** — [Error poco visible] te está costando [recurso]. *Ej: No molestar a tus clientes tras comprar te está costando devoluciones.*
    → *Costly mistake:* [low-visibility mistake] is costing you [resource].
64. **Una sola cosa** — Todos los [grupo exitoso] hacen una sola cosa. *Ej: Todos los buenos inversores hacen una sola cosa.*
    → *The one thing:* every [successful group] does one single thing.
65. **Sí, puedes** — Sí, puedes [algo inesperado]. *Ej: Sí, puedes enviar más de un correo al día.*
    → *Yes, you can:* yes, you can [something they assume is off-limits].
66. **Deja de ser X y conviértete en Y** — Deja de ser [identidad actual] y conviértete en [identidad poderosa]. *Ej: Deja de ser "director de ventas" y dirige tu vida.*
    → *Stop being X, become Y:* stop being [current identity] and become [powerful identity]. **(antithesis: see the warning above)**
67. **Método ensayo-error** — [Número] [acciones] después... [número] aprendizajes esenciales. *Ej: 10.000 emails después... 10 aprendizajes.*
    → *Trial and error:* [number] [actions] later… [number] lessons that mattered.
68. **Recurso tangible** — [Tipo de recurso]: [número] pasos para [resultado]. *Ej: Vídeo: 4 pasos para 1.000 seguidores en Substack.*
    → *Tangible resource:* [resource type]: [number] steps to [result].
69. **No hagas esto** — No "[consejo convencional]" en [año]. *Ej: No "sigas tu pasión" en 2026.*
    → *Don't do this:* don't "[conventional advice]" in [year].
70. **Si eres X, prueba Y** — Si eres [arquetipo], prueba este [método]. *Ej: Si eres médico, prueba esta idea de marketing por carta.*
    → *If you're X, try Y:* if you're [archetype], try this [method].
71. **Algo raro que funciona** — [Número] hábitos raros de [fuente] para [resultado]. *Ej: 3 hábitos raros de los Amish para escribir mejores correos.*
    → *Weird but it works:* [number] odd habits from [source] for [result].
72. **El mejor desconocido** — El mejor [elemento] del que nunca has oído hablar. *Ej: El mejor copywriter de España del que nunca has oído.*
    → *The best you've never heard of:* the best [thing] nobody talks about.
73. **Plantilla con resultado rápido** — Esta plantilla hace que [proceso] sea [mejora]. *Ej: Esta plantilla hace escribir Notes 3 veces más rápido.*
    → *Template with a fast win:* this template makes [process] [improvement].
74. **Valor comprimido** — Mi [sistema complejo] explicado en [formato breve]. *Ej: Mi sistema de tráfico viral en 150 palabras.*
    → *Compressed value:* my [complex system], explained in [short format].
75. **La verdad inesperada** — ¿Y si [resultado deseado] no fuera el verdadero objetivo? *Ej: ¿Y si vender más no fuera el objetivo?*
    → *The unexpected truth:* what if [desired result] wasn't the real goal?

## Checklist before choosing a hook

- Understood in under a second?
- Speaks to the right reader?
- Opens a clear tension?
- Promises only what the issue delivers (no hype)?
- Leaves a question open (doesn't reveal the whole answer)?
- Sounds human, not corporate?
- Reads well on mobile?
