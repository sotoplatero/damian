# Quality checklist — the final pass

Run before handing any draft (or polished issue) back to the author. If an item fails, go back and fix it
first — this is a feedback loop, not a report.

The list is **split by who can honestly check it.** The writer certifies what it can verify about its own
work; the rest goes to the `editor` agent, which reads the finished text cold. Two things are genuinely
impossible to self-assess: whether the prose still sounds like the author (you just chose every word), and
how often a device repeats across the whole piece (counting, not impression). Those are the editor's.

## What the writer certifies

### Substance
- [ ] **One single focus.** The issue promises one thing and delivers it.
- [ ] **The hook grabs.** The first two sentences make you want to keep reading.
- [ ] **The reader takes something away.** An idea, lesson, or tool.
- [ ] **The reader is the hero.** They finish the issue seeing *themselves* transformed, not just admiring
      the author. Even a first-person story reads as the reader's mirror. (No mechanical hero's-journey
      mold — see WRITING-CRAFT §13.)

### Truth
- [ ] **Every factual claim is verified.** Nothing invented.
- [ ] **Every fact, quote, example, and anecdote of the AUTHOR'S is in their material.** If any was
      invented to make the angle fit → cut it.
- [ ] **Every outside claim traces to the brief's approved sources.** Anything else is
      `[[fact?: ...]]` or gone.
- [ ] **Real context and reference links** — researched, existing, pointing where claimed.
- [ ] **Links are INLINE on the relevant word** — NO references/"Sources"/footnotes section at the end.
- [ ] **Links are rationed** — at most one per section, ~2–4 across the issue, every one load-bearing
      (`WRITING-CRAFT.md` §11). Counted, not eyeballed.
- [ ] **Names and technical terms are correct.** Numbers have a source.
- [ ] **The `[[...]]` notes add something and are deletable** without breaking the text.

### Craft
- [ ] **Hook in the first 2 sentences** (scene, fact, or tension).
- [ ] **It's a story** (before → what happened → after), not a list.
- [ ] **Title + dek + internal subheads** (one every 2–4 paragraphs) — a skim of subheads alone gives
      the shape.
- [ ] **Rhythm:** sentences of varied length, paragraphs of varied size.
- [ ] **No colon glosses in the body** — no `concepto: explicación` label sentences anywhere in the
      prose or the subheads (`ANTI-SLOP.md` § The colon gloss).
- [ ] **The piece doesn't restart at every heading.** Each section picks up the thread the previous one
      left; read the seams with the subheads covered (`STRUCTURE.md` §6 and §7).
- [ ] **`[[enrich: ...]]` notes seeded** where the author's own example would strengthen the text.
- [ ] **Short paragraphs**, scannable on mobile. **Show, don't tell.**
- [ ] **Deliberate colloquialisms respected**; only slips fixed.

### Structure (long pieces — `STRUCTURE.md`)
- [ ] **Every section in the brief's outline is present**, carrying the beat it was assigned.
- [ ] **The seams pass ran:** loops closed, callback landed, no orphan references, no two sections
      opening the same way.
- [ ] **Word count against the tier — reported, not chased.** Short with every beat delivered and every
      loop paid is *finished*; short because a beat is thin gets that beat named, never padded around.

### Form
- [ ] **Subject < ~50 characters, one focus.** 3 variants offered, most concrete marked.
- [ ] **Preheader set, extends the subject** (never repeats it).
- [ ] **One CTA, clear.**
- [ ] **Right length** — no padding to fill.

## What the `editor` certifies

Handed off per the `editor` agent spec, with `draft.md`, `brief.md`, and `voice/profile.md`. It
returns a pass/fail verdict with quoted evidence; **Must fix** items are resolved before the author sees
the piece.

- [ ] **Promise kept.** The tension the hook opens is closed in the text; the subject/dek/title promise
      exactly what the body delivers. An unpaid loop is clickbait with the author's name on it.
- [ ] **Tic census, counted across the whole issue.** One-word pauses, trailing ellipses, tricolons,
      aphorisms, mid-sentence dash density, "no es X, es Y" antithesis, rhetorical-question openings,
      announced effects, unproven adjectives. Once, earned, is fine; twice is a finding; once per section
      is a tic (`ANTI-SLOP.md` § frequency rule).
- [ ] **Zero AI noise** — full sweep against `ANTI-SLOP.md` (profile-documented signatures excepted).
- [ ] **Voice fidelity (the positive check).** Measured against the profile's voice bank and real archive
      samples: where does the text stop sounding like the author and start sounding like competent neutral
      prose? A passage can pass every anti-slop ban and still not be theirs.
- [ ] **Nothing announced that isn't then shown.** No "let me be honest", "this made me reflect deeply",
      "and that changed everything" standing in for the honesty, the reflection, or the change.
- [ ] **On a polish pass: the author's hand untouched.** Findings that land on their sentences are shown
      to them as suggestions, never applied.

## Closing the loop

- [ ] **Journal updated** (`voice/journal.md`): what the author changed from the draft and why — so
      next issue hits their voice better.
- [ ] **Resonance of the previous issue noted** if known (opens, replies, winning subject) and used to
      inform this one's angle and subject.
