# Journal — learning log for {NEWSLETTER_NAME}

<!--
Newest entries first. Entry format and maintenance rules live in
.cervantes/engine/MEMORY-SCHEMA.md. Cervantes logs here: edit diffs
(.baseline.md vs edited/published), explicit corrections from chat, and
resonance (opens, replies, winning subjects). Signals get carried into
profile.md and bump its voice version.
-->
