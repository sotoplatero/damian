# Editorial profile — {NEWSLETTER_NAME}

Voice version: v0.0

<!--
Cervantes' single source of truth about the author. Every skill reads it before
writing a word. Seeded by onboarding (v0.0 → v0.1); maintained continuously per
.cervantes/engine/MEMORY-SCHEMA.md. The author may edit anything here by hand.
v0.0 means UNSEEDED: never write in the author's name until seeding completes.
-->

## Basic config

- **Newsletter:** {NEWSLETTER_NAME}
- **Author:** {AUTHOR_NAME}
- **URL:** {NEWSLETTER_URL}
- **Platform:** {PLATFORM}
- **Language:** {LANGUAGE}   <!-- detected from the published newsletter; ALL content is written in it -->
- **Niche / topics:** {TOPICS}
- **Audience & what they come for:** {AUDIENCE}
- **Reader address:** {ADDRESS}   <!-- tú / usted / you / formal -->
- **Typical length:** {LENGTH_TIER}   <!-- short ~600–900 / standard ~1000–1500 / deep ~1800–2500+ words; sets the section budget per .cervantes/engine/STRUCTURE.md §1 -->
- **Emojis & caps:** {EMOJI_CAPS}
- **Loanwords:** {LOANWORDS}   <!-- raw or glossed -->
- **Cadence:** {CADENCE}
- **Polish intensity:** {POLISH_LEVEL}   <!-- light / standard / deep -->
- **Off-limits topics:** {OFF_LIMITS}

## Voice fingerprint

<!-- Filled ONLY from observed real text (archive/sample). Each row cites a short example. -->

| Dimension | Observed | Example (quoted) |
|---|---|---|
| Person & stance | {…} | {…} |
| Sentence rhythm | {…} | {…} |
| Paragraph size | {…} | {…} |
| Lexicon | {…} | {…} |
| Signature phrases | {…} | {…} |
| Punctuation habits | {…} | {…} |
| Humor & tone | {…} | {…} |
| Typical openings | {…} | {…} |
| Recurring moves / sections | {…} | {…} |
| Closing style | {…} | {…} |

## Hook-formula shortlist

<!-- Per .cervantes/engine/HOOK-FORMULAS.md § Narrowing: number + name + why it fits this voice. -->

- {#N Name — why}

## Documented signatures (anti-slop exceptions)

<!-- Patterns from .cervantes/engine/ANTI-SLOP.md that ARE this author's real voice, each with a quoted example from published text. Empty = no exceptions. -->

## Standing preferences (from chat)

<!-- Dated instructions given in conversation. Re-read before every issue. -->

## Things I NEVER do when writing as you

<!-- Hard constraints from explicit corrections, with dates. -->

## Your phrases & turns (voice bank)

<!-- Quotes from real published text only. -->
